R8.15 WRITE-BURST HARDENING ADDENDUM
- lifecycle summary cap: 32 rows/observation
- raw projected cluster JSON unchanged
- daily/write burst limits unchanged
- R8.12 projected identity wiring retained

# R8.12 — PROJECTED PROVIDER IDENTITY WIRING

Цель: устранить искусственный `ASSET_IDENTITY_NOT_SEPARATELY_VERIFIED`, когда тот же Deep Check уже имеет отдельный cross-venue identity proof.

Изменение минимальное:
- существующий `publicEvidence.alias_verification.asset_identity` передаётся в projected liquidation adapter;
- adapter принимает proof только если `verified=true` и `canonical_base` точно совпадает с provider base;
- provider symbol registry, timestamp/freshness, nonempty clusters, no truncation и HTX price-anchor gates остаются обязательными;
- Unicode/rebrand/unsafe aliases остаются fail-closed;
- статус `CLOSED_SHADOW` разрешается только при закрытии всех прежних gates плюс отдельного asset identity proof;
- projected map остаётся SHADOW/supporting timing evidence, не становится live signal/probability/guaranteed TP.

Worker SHA R8.12: `c5adceab63349054e3a4f98af10d76fdc2f8c5c96a98b6e791cdf25dc7e7cc62`.
Production main этим readiness-пакетом не меняется.

# R8.7 — EARLY LANE CAPACITY FIT

R8.7 основан на успешном R8.6 controlled run 35334663896.
Цель: ранняя ветка должна не только безопасно defer-иться, а реально исполняться в пределах D1 write-reserve.
Изменения только операционные: максимум persistence targets за цикл 3 -> 2; conservative early write envelope 64 -> 48.
Стратегия, Decision Layer weights и Worker SHA не изменяются. Telegram V3 network остается OFF.

# МОЙ ОТЧЁТ 2 — V3 R8 PREDEPLOY READINESS

Статус: **R8 LOCAL CLEANROOM PASS / NOT DEPLOYED**.

База production не менялась: R9/TZ10.1.
Candidate Worker SHA-256: `72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c`.

R8 включает весь R7 плюс безопасный Telegram delivery layer:
- lifecycle journal может работать при network OFF;
- initial R8 workflow: journal ON, V3 network OFF;
- revalidate/dedup/retry/expiry + confirmed receipt semantics;
- health alerts системные, не торговый сигнал;
- при будущем включении V3 network старый Telegram-output автоматически отключается, исключая duplicate ENTRY.

Локальный clean-room: 86/86 V3 Node PASS + 14/14 static/schema PASS.
Worker/strategy weights 35/30/20/15 не менялись. Auto trading/live probability OFF.

OPEN до CLOSED: Node24 R8, remote D1 controlled integration, production promotion, natural scheduled proof, delivery proof, audit/rollback/recovery, final canonical Version 1.
Continuous collector и production microstructure writer остаются явными PARTIAL, пока не доказаны.

## R8.1 Node24 regression alignment fix
- 2026-09-18: restored the already-proven write-sharding expectation in `liquidation-persistence-budget.test.mjs`.
- Runtime / Worker / strategy are unchanged.
- The obsolete expectation that all 80 unchanged lifecycle rows are rewritten every minute was removed.
- Exact R8.1 Node24 proof remains mandatory before any D1 write.

## R8.6 — D1 budget hardening candidate (2026-09-18)
Основание: R8.5 controlled diagnostic run 35329943201.
Фактическая телеметрия R8.5: pre-sidecars 2589 reads / 79 writes; final pre-post 11853 reads / 184 writes; reservation 12152 reads / 243 writes.
R8.6 не меняет торговую стратегию, веса Decision Layer, Worker logic или Telegram network state.
Изменения ограничены V3 shadow capacity-safety:
- бюджеты раннего persistence и realized-liquidation приведены к фактически измеренным conservative envelopes;
- projected liquidation sidecar делает identity/provider prefilter до тяжёлого чтения scan snapshots;
- при отсутствии закрытой provider identity результат остаётся fail-closed и не трактуется как рыночный сигнал.
Production deploy этим пакетом не выполняется.


## R8.8 adaptive D1 budget
- Per-run burst cap: 16000 reads / 320 writes.
- Daily admission uses finalized measured usage + conservative burst reservation for unfinished runs.
- Early persistence: max 1 candidate/cycle, 3072 reads / 24 writes.
- Downstream reserve remains 4500 reads / 50 writes.
- Priority: early persistence -> realized aggregation -> projected context. Raw factual liquidation events remain upstream, so aggregation may defer fail-closed without losing the source facts.
- Worker/strategy/weights unchanged; Telegram V3 network remains OFF for controlled validation.
