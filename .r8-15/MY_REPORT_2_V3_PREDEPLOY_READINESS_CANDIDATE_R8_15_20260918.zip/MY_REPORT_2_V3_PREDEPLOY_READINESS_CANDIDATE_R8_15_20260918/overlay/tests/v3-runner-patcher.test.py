import importlib.util, pathlib
P=pathlib.Path(__file__).resolve().parents[1]/'tools/patch_cloud_runner_v3.py'
spec=importlib.util.spec_from_file_location('p',P); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fixture='''import { classifyZeroTelegram } from "./telegram-zero-reason.mjs";\n\nconst RUNNER_VERSION = "my-report-2-github-cloud-runner-v4.7.3-telegram-watch70-tree-guard";\n'''+'''const cron = await env.DATA_DB.prepare("SELECT run_id,scheduled_time,started_ts,completed_ts,status,universe_total,scanned,persistence_status,error_text FROM cron_runs WHERE scheduled_time = ?1 ORDER BY started_ts DESC LIMIT 1").bind(started).first();\n'''+'''  assertClosedCron(cron, scan);\n  const telegramObserver = await observeNaturalTelegramDecision(env.DATA_DB);\n'''+'''    enabled: envText("REPORT2_TELEGRAM_OUTPUT_ENABLED", { required: false }),\n  const telegramZeroReason = classifyZeroTelegram({ preBudget:d1PreTelegramBudget, telegramObserver, telegramOutput });\n'''+'''telegram_observer:telegramObserver, discovery_recall_kpi:discoveryRecallKpi, telegram_output:telegramOutput'''
out=m.patch_runner_text(fixture)
for needle in [
    'runV3EarlyPersistenceSidecar','runV3RealizedLiquidationSidecar','runV3LiquidationIntelligenceSidecar',
    'runV3PipelineHealthSidecar','runV3TelegramLifecycleSidecar','runV3TelegramDeliverySidecar',
    'V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.rows_read',
    'V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.rows_written',
    'V3_REALIZED_LIQUIDATION_SIDECAR',
    'v3_realized_liquidation_sidecar:v3RealizedLiquidationSidecar',
    'v3_critical_feed_state:v3CriticalFeedState',
    'v3CriticalFeedState', 'startsWith("CLOSED")',
    'BUDGET_BLOCKED_FAIL_CLOSED','v3_liquidation_sidecar:v3LiquidationSidecar',
    'v3_pipeline_health_sidecar:v3PipelineHealthSidecar','v3_telegram_lifecycle_sidecar:v3TelegramLifecycleSidecar',
    'dispatch_enabled:v3TelegramJournalEnabled','v3TelegramNetworkEnabled','v3_telegram_delivery_sidecar:v3TelegramDeliverySidecar','v3_live_shortlist_count'
]: assert needle in out, needle
assert 'critical_feed_state:"OK"' not in out
assert 'enabled: v3TelegramNetworkEnabled ? "0"' in out
assert m.NEW_RUNNER_VERSION in out
wf='''name: Report 2 Cloud Runner\non:\n  workflow_dispatch:\n    inputs:\n      telegram_report_test:\n        description: "send one compact Telegram report test"\n        required: false\n        type: boolean\n        default: false\n\npermissions:\n  contents: read\n\njobs:\n  x:\n    env:\n      REPORT2_EXPECTED_WORKER_SHA: "'''+'0'*64+'''"\n      REPORT2_TELEGRAM_OUTPUT_ENABLED: "1"\n    steps:\n      - run: cp runner/telegram-output.mjs runtime/telegram-output.mjs\n'''
sha='a'*64
wout=m.patch_workflow_text(wf,sha)
assert sha in wout
assert 'controlled_no_telegram:' in wout
assert 'inputs.controlled_no_telegram == true' in wout
assert "&& '0' || '1'" in wout
assert 'cp src/v3-' not in wout
assert 'REPORT2_V3_TELEGRAM_JOURNAL_ENABLED: "1"' in wout
assert 'REPORT2_V3_TELEGRAM_NETWORK_ENABLED: "0"' in wout
assert wout.count('cp runner/telegram-output.mjs runtime/telegram-output.mjs') == 1
assert m.RUNNER_BLOB_SHA=='064275879c4e23b841907b9b6a25e567e717bd2e'
assert m.WORKFLOW_BLOB_SHA=='b1369dde068c609a715938408f2e23802f9661b8'
print('V3_RUNNER_PATCHER=PASS')
