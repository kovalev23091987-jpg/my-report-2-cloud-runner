import test from "node:test";
import assert from "node:assert/strict";
import {
  classifyProjectedProviderMap,
  buildExtendedLiquidationScan,
  updateProjectedClusterLifecycle,
  buildCrossVenueRealizedVector,
  buildModelledPressureProxy,
} from "../src/v3-liquidation-intelligence.mjs";

const NOW = 2_000_000_000_000;
const record = {
  provider: "ByKaranteli LiqMap Public API",
  provider_symbol: "BTC",
  asset_identity_verified: true,
  projected_map_status: "OBSERVATION_ONLY_IDENTITY_UNVERIFIED",
  projected_freshness: "CURRENT",
  projected_source_age_sec: 120,
  provider_current_price: 100,
  source_health: {
    provider_symbol_registry_exact_match: true,
    projected_scan_truncated: false,
    projected_cluster_output_truncated: false,
  },
  projected_clusters: [
    { side:"SHORT_LIQUIDATION_ABOVE", level_price:105, raw_size:100, source_unit:"USD_NOTIONAL_PROVIDER", explicit_major:false, source_ts:NOW },
    { side:"SHORT_LIQUIDATION_ABOVE", level_price:130, raw_size:1000, source_unit:"USD_NOTIONAL_PROVIDER", explicit_major:true, source_ts:NOW },
    { side:"SHORT_LIQUIDATION_ABOVE", level_price:170, raw_size:5000, source_unit:"USD_NOTIONAL_PROVIDER", explicit_major:true, source_ts:NOW },
    { side:"LONG_LIQUIDATION_BELOW", level_price:95, raw_size:90, source_unit:"USD_NOTIONAL_PROVIDER", explicit_major:false, source_ts:NOW },
    { side:"LONG_LIQUIDATION_BELOW", level_price:70, raw_size:900, source_unit:"USD_NOTIONAL_PROVIDER", explicit_major:true, source_ts:NOW },
    { side:"LONG_LIQUIDATION_BELOW", level_price:45, raw_size:4500, source_unit:"USD_NOTIONAL_PROVIDER", explicit_major:true, source_ts:NOW },
  ],
};

const elig = classifyProjectedProviderMap(record,{htx_contract:"BTC-USDT",htx_current_price:100});
assert.equal(elig.status,"CLOSED_SHADOW");
assert.equal(elig.type,"PROJECTED_PROVIDER_MAP");
assert.equal(elig.factual_user_positions,false);
assert.equal(elig.decision_eligible,false);

const sameTickerOnly = classifyProjectedProviderMap({...record,asset_identity_verified:false},{htx_contract:"BTC-USDT",htx_current_price:100});
assert.equal(sameTickerOnly.status,"NOT_CLOSED");
assert.ok(sameTickerOnly.reasons.includes("ASSET_IDENTITY_NOT_SEPARATELY_VERIFIED"));

const sourceError = classifyProjectedProviderMap({...record,projected_map_status:"SOURCE_ERROR"},{htx_contract:"BTC-USDT",htx_current_price:100});
assert.equal(sourceError.status,"NOT_CLOSED");
assert.ok(sourceError.reasons.includes("PROJECTED_SOURCE_STATUS_NOT_USABLE"));

const unicode = classifyProjectedProviderMap({...record,provider_symbol:"牛来"},{htx_contract:"牛来-USDT",htx_current_price:100});
assert.equal(unicode.status,"NOT_CLOSED");
assert.equal(unicode.identity_status,"IDENTITY_UNRESOLVED");

const notTriggered = buildExtendedLiquidationScan(record,{htx_contract:"BTC-USDT",htx_current_price:100,move_24h_pct:9.9});
assert.equal(notTriggered.status,"NOT_TRIGGERED");

const extended = buildExtendedLiquidationScan(record,{htx_contract:"BTC-USDT",htx_current_price:100,move_24h_pct:12});
assert.equal(extended.status,"CLOSED_SHADOW");
assert.equal(extended.largest_cluster_is_guaranteed_tp,false);
assert.ok(extended.far_huge_clusters.some(c=>Math.abs(c.distance_pct)>=50),"huge far cluster must not be truncated at 20/30/50%");
assert.ok(extended.above.some(c=>c.level_price===170));
assert.ok(extended.below.some(c=>c.level_price===45));

const life = updateProjectedClusterLifecycle(
  {cluster_key:"x",side:"SHORT_LIQUIDATION_ABOVE",level_price:105,strength:100,first_seen_ts:NOW-1000},
  {cluster_key:"x",side:"SHORT_LIQUIDATION_ABOVE",level_price:105,strength:120,last_seen_ts:NOW},
  {previous_price:104,current_price:106,oi_change_pct:-2},
);
assert.equal(life.swept,true);
assert.equal(life.strengthened,true);
assert.equal(life.magnet_after_sweep_assumed,false);

const events = [
  {venue:"BYBIT",ts_exchange:NOW-1000,liquidated_side_normalized:"SHORT",notional_usdt_normalized:100,source_coverage_class:"REALIZED_EVENT_FULL_OR_PROVIDER_DOCUMENTED_ALL"},
  {venue:"GATE",ts_exchange:NOW-900,liquidated_side_normalized:"LONG",notional_usdt_normalized:120,source_coverage_class:"AGGREGATED_EVENT_FEED"},
  {venue:"BINANCE",ts_exchange:NOW-800,liquidated_side_normalized:"UNKNOWN",notional_usdt_normalized:null,source_coverage_class:"PARTIAL_SNAPSHOT"},
];
const vector = buildCrossVenueRealizedVector(events,{now_ts:NOW});
assert.equal(vector.disagreement,true);
assert.equal(vector.auto_average_performed,false);
assert.equal(vector.missing_is_zero,false);

const proxyMissing = buildModelledPressureProxy({current_price:100,oi_value_usdt:1_000_000});
assert.equal(proxyMissing.status,"INSUFFICIENT_FACTUAL_INPUTS");
const proxy = buildModelledPressureProxy({
  current_price:100,oi_value_usdt:1_000_000,factual_margin_metadata:true,
  leverage_tiers:[{leverage:10,maintenance_margin_rate:0.005,oi_share_factual:0.2}],
});
assert.equal(proxy.status,"CLOSED_SHADOW");
assert.equal(proxy.label,"MODELLED_PROXY");
assert.equal(proxy.real_heatmap,false);
assert.equal(proxy.cluster_claim_allowed,false);

test("V3 liquidation intelligence strict class separation and extended scan",()=>assert.equal(true,true));
