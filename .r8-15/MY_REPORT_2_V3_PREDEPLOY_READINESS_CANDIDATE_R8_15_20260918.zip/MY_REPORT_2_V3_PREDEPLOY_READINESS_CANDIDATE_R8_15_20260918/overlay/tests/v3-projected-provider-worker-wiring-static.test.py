from pathlib import Path
p=Path(__file__).resolve().parents[1]/'src'/'worker.js'
s=p.read_text()
need=[
    'asset_identity_proof = null',
    'separateAssetIdentityVerified',
    'projectedStatus = "CLOSED_SHADOW"',
    'asset_identity_proof: publicEvidence?.alias_verification?.asset_identity || null',
    'asset_identity_separately_verified: separateAssetIdentityVerified',
]
for x in need:
    assert x in s, x
assert 'asset_identity_verified: separateAssetIdentityVerified' in s
assert '...(!' not in s
print('V3_PROJECTED_PROVIDER_WORKER_WIRING_STATIC=PASS')
