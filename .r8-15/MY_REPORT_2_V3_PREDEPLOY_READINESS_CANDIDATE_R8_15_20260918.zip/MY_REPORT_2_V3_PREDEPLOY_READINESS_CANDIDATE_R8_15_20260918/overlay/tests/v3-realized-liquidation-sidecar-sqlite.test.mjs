import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {runV3RealizedLiquidationSidecar} from '../src/v3-realized-liquidation-sidecar.mjs';

function sqliteCompat(sql,args){
  const mapped=[];
  const text=String(sql).replace(/\?(\d+)/g,(_m,n)=>{mapped.push(args[Number(n)-1]);return '?';});
  return {sql:text,args:mapped.length?mapped:args};
}
class Stmt{
  constructor(owner,sql,args=[]){this.owner=owner;this.sql=sql;this.args=args;}
  bind(...args){return new Stmt(this.owner,this.sql,args);}
  _compat(){return sqliteCompat(this.sql,this.args);}
  async all(){const q=this._compat();const rows=this.owner.db.prepare(q.sql).all(...q.args);this.owner.record('all',rows.length,0);return {results:rows};}
  async first(){const q=this._compat();const row=this.owner.db.prepare(q.sql).get(...q.args)??null;this.owner.record('first',row?1:0,0);return row;}
  async run(){const q=this._compat();const r=this.owner.db.prepare(q.sql).run(...q.args);this.owner.record('run',0,Number(r.changes||0));return {meta:{changes:Number(r.changes||0)}};}
  _runBatch(){const q=this._compat();const r=this.owner.db.prepare(q.sql).run(...q.args);return {meta:{changes:Number(r.changes||0)},results:[]};}
}
class D1{
  constructor(){this.db=new DatabaseSync(':memory:');this.usage={requests:0,rows_read:0,rows_written:0,unknown_ops:0};}
  prepare(sql){return new Stmt(this,sql);}
  record(_op,rr,rw){this.usage.requests+=1;this.usage.rows_read+=rr;this.usage.rows_written+=rw;}
  async batch(stmts){const out=[];this.db.exec('BEGIN');try{for(const s of stmts){if(/^\s*SELECT/i.test(s.sql)){const q=s._compat();const rs=this.db.prepare(q.sql).all(...q.args);this.record('batch',rs.length,0);out.push({results:rs,meta:{changes:0}});}else{const r=s._runBatch();this.record('batch',0,Number(r.meta.changes||0));out.push(r);}}this.db.exec('COMMIT');return out;}catch(e){this.db.exec('ROLLBACK');throw e;}}
  usageSnapshot(){return JSON.parse(JSON.stringify(this.usage));}
}
const NOW=1_800_000_000_000;
function stage0(){return JSON.stringify({schema:'stage0-compact-v2',timestamp:NOW,contracts:[['RAY-USDT',2.0,1000000,100,200000,0.0001,8,1,'CLOSED',false,false,0,0],['BTC-USDT',60000,100000000,1000,10000000,0.0001,8,1,'CLOSED',false,false,0,0]]});}

test('realized sidecar persists compact aggregates and density but no raw duplication',async()=>{
  const db=new D1();
  db.db.exec(`
    CREATE TABLE scan_runs(ts INTEGER,stage0_coverage_pct REAL,errors INTEGER,stale INTEGER,payload_json TEXT);
    CREATE TABLE liquidation_events(source TEXT NOT NULL,event_id TEXT NOT NULL,contract_code TEXT,ts INTEGER,side TEXT,price REAL,volume_contracts REAL,amount_base REAL,notional_usdt REAL,raw_json TEXT NOT NULL,PRIMARY KEY(source,event_id));
    CREATE TABLE v3_realized_liquidation_aggregate(contract_code TEXT NOT NULL,window_name TEXT NOT NULL,end_ts INTEGER NOT NULL,event_count_observed INTEGER NOT NULL DEFAULT 0,known_side_count INTEGER NOT NULL DEFAULT 0,unknown_side_count INTEGER NOT NULL DEFAULT 0,long_liquidation_count INTEGER,short_liquidation_count INTEGER,known_long_liquidation_count INTEGER NOT NULL DEFAULT 0,known_short_liquidation_count INTEGER NOT NULL DEFAULT 0,total_notional_usdt REAL,known_notional_usdt REAL NOT NULL DEFAULT 0,long_notional_usdt REAL,short_notional_usdt REAL,max_single_event_usdt REAL,liquidation_side_imbalance REAL,venue_breadth INTEGER NOT NULL DEFAULT 0,venue_concentration REAL,burst_velocity_events_per_min REAL,burst_acceleration_events_per_min REAL,consecutive_burst_minutes INTEGER,liquidation_to_volume_ratio REAL,price_response_pct REAL,oi_response_pct REAL,flow_response_delta_usdt REAL,side_coverage_closed INTEGER NOT NULL DEFAULT 0,notional_coverage_closed INTEGER NOT NULL DEFAULT 0,coverage_classes_json TEXT NOT NULL DEFAULT '[]',venues_json TEXT NOT NULL DEFAULT '[]',persisted_ts INTEGER NOT NULL,shadow_only INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(contract_code,window_name,end_ts));
    CREATE TABLE v3_realized_liquidation_density_5m(contract_code TEXT NOT NULL,venue TEXT NOT NULL,liquidated_side TEXT NOT NULL,bucket_ts INTEGER NOT NULL,price_bucket_center REAL NOT NULL,bucket_size_pct REAL NOT NULL,event_count INTEGER NOT NULL DEFAULT 0,known_notional_usdt REAL NOT NULL DEFAULT 0,unknown_notional_count INTEGER NOT NULL DEFAULT 0,first_event_ts INTEGER,last_event_ts INTEGER,persisted_ts INTEGER NOT NULL,shadow_only INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(contract_code,venue,liquidated_side,bucket_ts,price_bucket_center));
  `);
  db.db.prepare('INSERT INTO scan_runs VALUES(?,?,?,?,?)').run(NOW,100,0,0,stage0());
  const ins=db.db.prepare('INSERT INTO liquidation_events VALUES(?,?,?,?,?,?,?,?,?,?)');
  ins.run('HTX official public liquidation REST','e1','RAY-USDT',NOW-20_000,'LONG_LIQUIDATED',1.98,10,10,1000,'{}');
  ins.run('HTX official public liquidation REST','e2','RAY-USDT',NOW-10_000,'SHORT_LIQUIDATED',2.02,5,5,800,'{}');
  ins.run('HTX official public liquidation REST','e3','RAY-USDT',NOW-5_000,'LONG_LIQUIDATED',2.01,2,2,null,'{}');
  const beforeRaw=db.db.prepare('SELECT COUNT(*) n FROM liquidation_events').get().n;
  const r=await runV3RealizedLiquidationSidecar(db,{current_scan_ts:NOW,source_run_id:'run1',now_ts:NOW});
  assert.equal(r.status,'CLOSED');
  assert.equal(r.raw_events_persisted,0);
  assert.equal(r.contracts_selected,1);
  assert.equal(r.targets[0].aggregate_rows,4);
  assert.ok(r.targets[0].density_rows>=1);
  assert.equal(db.db.prepare('SELECT COUNT(*) n FROM liquidation_events').get().n,beforeRaw);
  const a=db.db.prepare("SELECT * FROM v3_realized_liquidation_aggregate WHERE contract_code='RAY-USDT' AND window_name='1m'").get();
  assert.equal(a.event_count_observed,3);
  assert.equal(a.total_notional_usdt,null,'missing notional must not be fabricated as complete total');
  assert.equal(a.known_notional_usdt,1800);
  assert.equal(a.side_coverage_closed,1);
  assert.equal(a.notional_coverage_closed,0);
  assert.match(a.coverage_classes_json,/PARTIAL_SNAPSHOT/);
});
