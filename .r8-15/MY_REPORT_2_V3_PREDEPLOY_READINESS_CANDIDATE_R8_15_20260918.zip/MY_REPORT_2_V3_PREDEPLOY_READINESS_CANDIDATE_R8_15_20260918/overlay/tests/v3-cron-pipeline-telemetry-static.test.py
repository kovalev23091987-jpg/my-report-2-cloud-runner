from pathlib import Path
w=Path(__file__).resolve().parents[1]/'src/worker.js'
s=w.read_text()
required=[
 'v3_discovery_shortlist_count','v3_live_shortlist_count','v3_live_deep_check_count',
 'v3_live_zero_reason','v3_pipeline_health_status','v3_pipeline_health_reason',
 'v3_live_lane','v3_maintenance_deferred'
]
for x in required:
    assert s.count(x)>=2, x
assert 'WORKER_CRON_ERROR' in s
assert 'boundedDeepCheck.results.filter((row) => row?.execution_status === "FULFILLED").length' in s
# The telemetry is piggy-backed into recordCronRun; it must not introduce a dedicated Worker write call.
assert 'persistV3PipelineHealth' not in s
print('V3_CRON_PIPELINE_TELEMETRY_STATIC=PASS')
