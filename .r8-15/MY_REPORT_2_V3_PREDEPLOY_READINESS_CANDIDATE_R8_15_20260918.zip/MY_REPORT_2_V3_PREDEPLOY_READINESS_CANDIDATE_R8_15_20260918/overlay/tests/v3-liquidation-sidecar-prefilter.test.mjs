import test from 'node:test';
import assert from 'node:assert/strict';
import {runV3LiquidationIntelligenceSidecar} from '../src/v3-liquidation-sidecar.mjs';

class Stmt { constructor(sql,db){this.sql=sql;this.db=db;this.args=[];} bind(...args){this.args=args;return this;} }
class Db {
  constructor(row){this.row=row;this.usage={rows_read:0,rows_written:0,requests:0,unknown_ops:0};this.snapshotQueries=0;}
  prepare(sql){return new Stmt(sql,this);}
  usageSnapshot(){return {...this.usage};}
  async batch(stmts){
    this.usage.requests+=1;
    if(stmts.some(s=>s.sql.includes('FROM scan_runs'))) this.snapshotQueries+=1;
    if(stmts.length===1 && stmts[0].sql.includes('FROM liquidation_shadow_observation')){
      this.usage.rows_read+=1;
      return [{results:[this.row]}];
    }
    throw new Error('UNEXPECTED_QUERY_PATH');
  }
}
const now=2_000_000_000_000;
const row={contract_code:'CASHCAT-USDT',observed_ts:now,provider:'ByKaranteli LiqMap Public API',provider_symbol:'',asset_identity_verified:0,projected_map_status:'SOURCE_UNSUPPORTED',source_age_sec:null,freshness_status:'NOT_CLOSED',projected_clusters_json:'[]',source_health_json:JSON.stringify({provider_symbol_registry_exact_match:false}),errors_json:'[]'};

test('provider-not-closed prefilter avoids expensive scan snapshot reads',async()=>{
  const db=new Db(row);
  const out=await runV3LiquidationIntelligenceSidecar(db,{current_scan_ts:now,now_ts:now,source_run_id:'r'});
  assert.equal(out.status,'CLOSED_OBSERVATION_ONLY_IDENTITY_NOT_CLOSED');
  assert.equal(out.provider_prefilter_short_circuit,true);
  assert.equal(out.persisted,0);
  assert.equal(db.snapshotQueries,0);
  assert.ok(out.targets[0].reasons.includes('ASSET_IDENTITY_NOT_SEPARATELY_VERIFIED'));
});
