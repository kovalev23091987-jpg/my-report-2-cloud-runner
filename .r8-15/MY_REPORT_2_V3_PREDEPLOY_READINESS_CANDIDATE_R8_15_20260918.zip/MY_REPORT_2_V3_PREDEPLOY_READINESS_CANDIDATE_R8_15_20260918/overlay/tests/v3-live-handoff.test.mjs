import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildDiscoveryHandoffEnvelope,
  buildV3LiveHandoffPlan,
  classifyV3LiveHandoffZeroReason,
  assessV3PipelineHealth,
  nextHandoffState,
  V3_HANDOFF_STATE,
} from '../src/v3-live-handoff.mjs';

test('handoff envelope carries exact required V3 fields without choosing direction retroactively', () => {
  const r = buildDiscoveryHandoffEnvelope({
    contract: 'ETHFI-USDT', priority_rank: 2,
    detectors: ['OI_UP', 'RS_BTC'], evidence_ids: ['scan:1', 'oi:1'],
    direction_hint: null,
  }, {
    source_run_id: 'run-1', scan_ts: 1_700_000_000_000, now_ts: 1_700_000_000_100,
    wave_id: 'ETHFI:wave:3', dedup_reentry_key: 'ETHFI:3',
    first_seen_state: { first_seen_ts: 1_699_999_000_000 },
    current_state: 'PRE_IMPULSE_WATCH',
  });
  assert.equal(r.status, 'CLOSED');
  const e = r.envelope;
  assert.equal(e.exact_htx_contract, 'ETHFI-USDT');
  assert.equal(e.base_ticker, 'ETHFI');
  assert.equal(e.source_run_id, 'run-1');
  assert.equal(e.discovery_rank, 2);
  assert.deepEqual(e.detectors, ['OI_UP', 'RS_BTC']);
  assert.deepEqual(e.evidence_ids, ['scan:1', 'oi:1']);
  assert.equal(e.current_state, 'PRE_IMPULSE_WATCH');
  assert.equal(e.direction, null);
  assert.equal(e.wave_id, 'ETHFI:wave:3');
  assert.equal(e.dedup_reentry_key, 'ETHFI:3');
  assert.match(e.handoff_id, /^run-1\|ETHFI-USDT\|ETHFI:wave:3\|ETHFI:3$/);
});

test('Unicode symbol is preserved exactly and guessed non-USDT identity fails closed', () => {
  const good = buildDiscoveryHandoffEnvelope({ contract: '牛来-USDT' }, {
    source_run_id: 'r', scan_ts: 10, now_ts: 11,
  });
  assert.equal(good.status, 'CLOSED');
  assert.equal(good.envelope.exact_htx_contract, '牛来-USDT');
  assert.equal(good.envelope.base_ticker, '牛来');
  const bad = buildDiscoveryHandoffEnvelope({ contract: 'BTCUSDT' }, {
    source_run_id: 'r', scan_ts: 10, now_ts: 11,
  });
  assert.equal(bad.status, 'IDENTITY_UNRESOLVED');
});

test('fresh live shortlist always outranks maintenance', () => {
  const plan = buildV3LiveHandoffPlan({
    discovery_prefilter: { shortlist: [{contract:'A-USDT'}, {contract:'B-USDT'}] },
    fast_move_watch_cycle: { selected_leases: [] },
    opportunity_journal_plan: { status:'SELECTED_BOUNDED_JOURNAL_MAINTENANCE', selected_contract:'OLD-USDT' },
  });
  assert.equal(plan.lane, 'LIVE_DISCOVERY');
  assert.equal(plan.maintenance_deferred, true);
  assert.equal(plan.live_shortlist_count, 2);
});

test('exact due Fast-Move lease outranks maintenance and binds exact contract', () => {
  const plan = buildV3LiveHandoffPlan({
    discovery_prefilter: { shortlist: [{contract:'A-USDT'}] },
    fast_move_watch_cycle: { selected_leases: [{contract:'A-USDT'}] },
    opportunity_journal_plan: { status:'SELECTED_BOUNDED_JOURNAL_MAINTENANCE', selected_contract:'OLD-USDT' },
  });
  assert.equal(plan.lane, 'LIVE_FAST_MOVE_RECHECK');
  assert.equal(plan.require_exact_contract, true);
  assert.equal(plan.required_contract, 'A-USDT');
});

test('maintenance runs only when no live target exists', () => {
  const plan = buildV3LiveHandoffPlan({
    discovery_prefilter: { shortlist: [] },
    fast_move_watch_cycle: { selected_leases: [] },
    opportunity_journal_plan: { status:'SELECTED_BOUNDED_JOURNAL_MAINTENANCE', selected_contract:'OLD-USDT' },
  });
  assert.equal(plan.lane, 'MAINTENANCE');
  assert.equal(plan.required_contract, 'OLD-USDT');
});

test('eligible live with zero deep checks and no mapped reason degrades pipeline', () => {
  const plan = buildV3LiveHandoffPlan({ discovery_prefilter:{shortlist:[{contract:'A-USDT'}]} });
  const deep = { status:'NO_READY_TARGETS', plan:{counts:{selected:0},scope_status:'CONFIRMED_SET_SUPPLIED',blocked:[]} };
  const reason = classifyV3LiveHandoffZeroReason({handoff_plan:plan,bounded_deep_check:deep});
  assert.equal(reason, 'LIVE_HANDOFF_UNMAPPED_FAIL_CLOSED');
  assert.equal(assessV3PipelineHealth({handoff_plan:plan,bounded_deep_check:deep,zero_reason:reason}).status, 'DEGRADED_PIPELINE');
});

test('cooldown is an explicit valid zero reason, not a silent drop', () => {
  const plan = buildV3LiveHandoffPlan({ discovery_prefilter:{shortlist:[{contract:'A-USDT'}]} });
  const deep = { status:'NO_READY_TARGETS', plan:{counts:{selected:0},scope_status:'CONFIRMED_SET_SUPPLIED',blocked:[{reason:'COOLDOWN'}]} };
  const reason = classifyV3LiveHandoffZeroReason({handoff_plan:plan,bounded_deep_check:deep});
  assert.equal(reason, 'COOLDOWN_ACTIVE');
  assert.equal(assessV3PipelineHealth({handoff_plan:plan,bounded_deep_check:deep,zero_reason:reason}).status, 'HEALTHY_NO_IDEA');
});

test('journal state machine is retry-safe and terminally exactly-once', () => {
  assert.equal(nextHandoffState({current:V3_HANDOFF_STATE.PENDING,event:'CLAIM'}), V3_HANDOFF_STATE.CLAIMED);
  assert.equal(nextHandoffState({current:V3_HANDOFF_STATE.CLAIMED,event:'FAIL',retryable:true}), V3_HANDOFF_STATE.FAILED_RETRYABLE);
  assert.equal(nextHandoffState({current:V3_HANDOFF_STATE.FAILED_RETRYABLE,event:'CLAIM'}), V3_HANDOFF_STATE.CLAIMED);
  assert.equal(nextHandoffState({current:V3_HANDOFF_STATE.CLAIMED,event:'COMPLETE'}), V3_HANDOFF_STATE.COMPLETED);
  assert.equal(nextHandoffState({current:V3_HANDOFF_STATE.COMPLETED,event:'CLAIM'}), V3_HANDOFF_STATE.COMPLETED);
});
