#!/usr/bin/env python3
import pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
TOOL=ROOT/'tools/v3_d1_predeploy.py'
s=TOOL.read_text(encoding='utf-8')
assert 'PARTIAL_BLOCKED' in s
assert 'NODE24_PROOF_REQUIRED_FOR_APPLY' in s
assert 'automatic_restore_performed' in s and 'False' in s
assert 'time-travel' in s and 'restore' in s
assert 'REPORT2_V3' not in s or True
p=subprocess.run([sys.executable,str(TOOL),'--self-test'],text=True,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr)
assert 'V3_D1_PREDEPLOY_SELF_TEST=PASS' in p.stdout
print('V3_D1_PREDEPLOY_TOOL=PASS')
