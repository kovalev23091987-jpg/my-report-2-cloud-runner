import sqlite3, pathlib
root=pathlib.Path(__file__).resolve().parents[1]
sql=(root/'migrations/20260917_v3_live_handoff_shadow.sql').read_text()
db=sqlite3.connect(':memory:')
db.executescript(sql)
# Wiring migration is applied after the already-existing production scheduler/run-log schemas.
db.executescript((root/'migrations/report2_deep_check_scheduler_state.sql').read_text())
db.executescript((root/'migrations/report2_deep_check_run_log.sql').read_text())
db.executescript((root/'migrations/20260917_v3_live_handoff_wiring_shadow.sql').read_text())
cols={r[1] for r in db.execute('pragma table_info(v3_discovery_deep_handoff_shadow)')}
required={'handoff_id','logical_key','source_run_id','scan_ts','contract_code','base_ticker','discovery_rank','detectors_json','evidence_ids_json','first_seen_state_json','current_state_json','direction','wave_id','dedup_reentry_key','state','attempt_count','lease_owner','lease_started_ts','lease_expires_ts','zero_reason','deep_check_run_id','last_error','created_ts','updated_ts','completed_ts','shadow_only'}
assert required <= cols, required-cols
row=('h1','k1','run1',100,'ETHFI-USDT','ETHFI',1,'[]','[]',None,None,None,'w1','r1','PENDING',0,None,None,None,None,None,None,100,100,None,1)
db.execute('insert into v3_discovery_deep_handoff_shadow values ('+','.join(['?']*len(row))+')',row)
try:
    db.execute('insert into v3_discovery_deep_handoff_shadow values ('+','.join(['?']*len(row))+')',row)
    raise AssertionError('duplicate handoff must fail')
except sqlite3.IntegrityError:
    pass
# New wave/reentry is a distinct logical handoff.
row2=('h2','k2','run2',200,'ETHFI-USDT','ETHFI',1,'[]','[]',None,None,None,'w2','r2','PENDING',0,None,None,None,None,None,None,200,200,None,1)
db.execute('insert into v3_discovery_deep_handoff_shadow values ('+','.join(['?']*len(row2))+')',row2)
assert db.execute('select count(*) from v3_discovery_deep_handoff_shadow').fetchone()[0] == 2
indexes={r[1] for r in db.execute("select type,name from sqlite_master where type='index'")}
assert 'idx_v3_handoff_pending' in indexes and 'idx_v3_handoff_contract' in indexes and 'idx_v3_handoff_wave' in indexes
print('V3_LIVE_HANDOFF_D1=PASS')

# Trigger proof: the already-counted scheduler INSERT/UPDATE automatically mirrors
# handoff CLAIMED -> COMPLETED without any extra Worker query.
db.execute("""insert into deep_check_scheduler_state(
 contract_code,last_started_ts,last_completed_ts,last_status,last_run_id,last_sufficiency,last_error,updated_ts,
 v3_handoff_id,v3_handoff_logical_key,v3_scan_ts,v3_base_ticker,v3_discovery_rank,v3_detectors_json,v3_evidence_ids_json,
 v3_first_seen_state_json,v3_current_state_json,v3_direction,v3_wave_id,v3_dedup_reentry_key)
 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
 ('RAY-USDT',1000,None,'RUNNING','scan-run-1',None,None,1000,'vh1','vk1',900,'RAY',2,'["oi"]','[]',None,None,None,'wave-1','re-1'))
r=db.execute("select state,attempt_count,source_run_id,contract_code,wave_id from v3_discovery_deep_handoff_shadow where handoff_id='vh1'").fetchone()
assert r==('CLAIMED',1,'scan-run-1','RAY-USDT','wave-1'), r
db.execute("update deep_check_scheduler_state set last_completed_ts=2000,last_status='COMPLETED',updated_ts=2000 where contract_code='RAY-USDT'")
r=db.execute("select state,deep_check_run_id,completed_ts from v3_discovery_deep_handoff_shadow where handoff_id='vh1'").fetchone()
assert r==('COMPLETED','scan-run-1',2000), r
print('V3_LIVE_HANDOFF_TRIGGER_WIRING=PASS')
