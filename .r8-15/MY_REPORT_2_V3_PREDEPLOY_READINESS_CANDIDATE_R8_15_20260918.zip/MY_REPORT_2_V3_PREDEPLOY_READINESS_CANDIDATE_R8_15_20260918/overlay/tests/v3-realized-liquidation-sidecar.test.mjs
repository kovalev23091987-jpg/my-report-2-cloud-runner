import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizePersistedHtxLiquidationEvent,chooseRealizedContracts,V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET} from '../src/v3-realized-liquidation-sidecar.mjs';

test('persisted HTX factual liquidation event normalizes without inventing coverage',()=>{
  const e=normalizePersistedHtxLiquidationEvent({source:'HTX official public liquidation REST',event_id:'e1',contract_code:'RAY-USDT',ts:1000,side:'LONG_LIQUIDATED',price:1.2,volume_contracts:3,notional_usdt:null},{received_ts:1100});
  assert.equal(e.venue,'HTX');
  assert.equal(e.contract,'RAY-USDT');
  assert.equal(e.liquidated_side_normalized,'LONG');
  assert.equal(e.notional_usdt_normalized,null);
  assert.equal(e.source_coverage_class,'PARTIAL_SNAPSHOT');
  assert.equal(e.identity_status,'CLOSED');
  assert.equal(e.shadow_only,true);
});

test('unknown side stays UNKNOWN and missing event identity is rejected',()=>{
  const e=normalizePersistedHtxLiquidationEvent({event_id:'e2',contract_code:'RAY-USDT',ts:2000,side:'OTHER',price:1,notional_usdt:10});
  assert.equal(e.liquidated_side_normalized,'UNKNOWN');
  assert.equal(normalizePersistedHtxLiquidationEvent({contract_code:'RAY-USDT',ts:2000}),null);
});

test('contract selection is bounded by recency then event count',()=>{
  const events=[
    {contract:'A-USDT',ts_exchange:100,source_event_id:'a1'},
    {contract:'A-USDT',ts_exchange:200,source_event_id:'a2'},
    {contract:'B-USDT',ts_exchange:300,source_event_id:'b1'},
    {contract:'C-USDT',ts_exchange:250,source_event_id:'c1'},
  ];
  const picked=chooseRealizedContracts(events,{max_contracts:2});
  assert.deepEqual(picked.map(x=>x.contract),['B-USDT','C-USDT']);
  assert.ok(picked.length<=V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.max_contracts);
});
