import test from 'node:test';
import assert from 'node:assert/strict';
import {collectCrossVenueLiquidationIntelligence} from '../src/liquidation-intelligence.mjs';

const NOW=Date.parse('2026-09-13T09:00:00Z');
const response=(data,status=200,headers={})=>({ok:status>=200&&status<300,status,headers:{get(n){return headers[String(n).toLowerCase()]??null;}},async json(){return data;}});
const projected={generatedAt:'2026-09-13T08:55:00Z',symbol:'BTC',current_price:100,venues:['Bybit','Binance'],projected_levels:[
  {price:95,side:'long',notional_usd:100000,major:true},
  {price:105,side:'short',notional_usd:120000,major:true},
]};
const realized={generatedAt:'2026-09-13T08:57:00Z',by_exchange:[{exchange:'Bybit',symbol:'BTCUSDT',long_usd:1000,short_usd:500}]};
const coverage={generatedAt:'2026-09-13T08:58:00Z',liquidations:[{venue:'Bybit',kind:'full',events_24h:123,last_record:'2026-09-13T08:57:30Z'}]};
const symbols={generatedAt:'2026-09-13T08:58:30Z',symbols:[{symbol:'BTCUSDT',lastPrice:100}]};
const fetchImpl=async(url)=>{
  if(url.includes('liqmap')) return response(projected);
  if(url.includes('liquidations')) return response(realized);
  if(url.includes('coverage')) return response(coverage);
  if(url.includes('symbols')) return response(symbols);
  throw new Error('unexpected url '+url);
};

test('separate cross-venue asset proof closes projected provider identity in shadow only',async()=>{
  const out=await collectCrossVenueLiquidationIntelligence({
    contract_code:'BTC-USDT',api_key:'free-key',now_ts:NOW,fetch_impl:fetchImpl,
    asset_identity_proof:{verified:true,method:'HTX_CANONICAL_PLUS_BYBIT_BINANCE_EXACT_BASE',canonical_base:'BTC',corroborators:['BYBIT_LINEAR_PERP','BINANCE_USDT_PERP']},
  });
  assert.equal(out.projected_map_status,'CLOSED_SHADOW');
  assert.equal(out.asset_identity_verified,true);
  assert.equal(out.asset_identity_verification_method,'HTX_CANONICAL_PLUS_BYBIT_BINANCE_EXACT_BASE');
  assert.equal(out.source_health.provider_symbol_registry_exact_match,true);
  assert.equal(out.source_health.asset_identity_separately_verified,true);
  assert.equal(out.projected_freshness,'CURRENT');
  assert.ok(out.projected_clusters.length>0);
  assert.ok(out.projected_clusters.every(x=>x.asset_identity_verified===true));
  assert.ok(out.projected_clusters.every(x=>!x.uncertainty.includes('ASSET_IDENTITY_NOT_SEPARATELY_VERIFIED')));
  assert.equal(out.safety.live_signal_generated,false);
  assert.equal(out.safety.trading_execution,false);
});

test('mismatched or absent separate proof remains fail-closed',async()=>{
  const mismatch=await collectCrossVenueLiquidationIntelligence({
    contract_code:'BTC-USDT',api_key:'free-key',now_ts:NOW,fetch_impl:fetchImpl,
    asset_identity_proof:{verified:true,method:'TEST',canonical_base:'ETH',corroborators:['X']},
  });
  assert.equal(mismatch.projected_map_status,'OBSERVATION_ONLY_IDENTITY_UNVERIFIED');
  assert.equal(mismatch.asset_identity_verified,false);
  const absent=await collectCrossVenueLiquidationIntelligence({contract_code:'BTC-USDT',api_key:'free-key',now_ts:NOW,fetch_impl:fetchImpl});
  assert.equal(absent.projected_map_status,'OBSERVATION_ONLY_IDENTITY_UNVERIFIED');
  assert.equal(absent.asset_identity_verified,false);
});
