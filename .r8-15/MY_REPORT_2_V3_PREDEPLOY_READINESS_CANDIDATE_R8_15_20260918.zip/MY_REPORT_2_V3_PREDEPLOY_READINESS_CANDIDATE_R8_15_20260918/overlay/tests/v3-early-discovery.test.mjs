import test from "node:test";
import assert from "node:assert/strict";
import {
  robustNormalize,
  parseStage0CompactPayload,
  buildEarlyObservation,
  advanceEarlyCandidateMemory,
  earlyCandidatePersistenceRows,
} from "../src/v3-early-discovery.mjs";

const START = 2_000_000_000_000;
function payload(ts, rows) {
  return {
    schema: "stage0-compact-v2",
    timestamp: ts,
    contracts: rows.map((r) => [
      r.contract, r.price, r.turnover, r.oi, r.oi * r.price,
      r.funding, 8, 1, "CLOSED", false, false, 0, 0,
    ]),
  };
}

function series({ direction = 1, points = 40, target = "ALT-USDT", futureShock = false } = {}) {
  const out = [];
  for (let i = 0; i < points; i += 1) {
    const ts = START + i * 5 * 60_000;
    const build = i >= points - 3;
    const price = 100 * (1 + direction * 0.00025 * i + (build ? direction * 0.004 * (i - (points - 4)) : 0));
    const oi = 1000 * (1 + 0.0004 * i + (build ? 0.012 * (i - (points - 4)) : 0));
    const funding = direction > 0
      ? -0.00005 - (build ? 0.00003 * (i - (points - 4)) : 0)
      : 0.00005 + (build ? 0.00003 * (i - (points - 4)) : 0);
    const turnover = 1_000_000 * (1 + 0.001 * i + (build ? 0.035 * (i - (points - 4)) : 0));
    const btc = 100 * (1 + 0.00005 * i);
    const eth = 100 * (1 + 0.00003 * i);
    out.push(payload(ts, [
      { contract: target, price, turnover, oi, funding },
      { contract: "BTC-USDT", price: btc, turnover: 10_000_000, oi: 10000, funding: 0 },
      { contract: "ETH-USDT", price: eth, turnover: 8_000_000, oi: 9000, funding: 0 },
    ]));
  }
  if (futureShock) {
    out.push(payload(START + (points + 10) * 5 * 60_000, [
      { contract: target, price: direction > 0 ? 999 : 1, turnover: 99_000_000, oi: 99999, funding: direction > 0 ? -0.01 : 0.01 },
      { contract: "BTC-USDT", price: 1, turnover: 1, oi: 1, funding: 0 },
      { contract: "ETH-USDT", price: 1, turnover: 1, oi: 1, funding: 0 },
    ]));
  }
  return out;
}

assert.equal(robustNormalize(1, [1,2,3]).status, "INSUFFICIENT_HISTORY");
assert.equal(parseStage0CompactPayload("not json").status, "PAYLOAD_INVALID");

const longSeries = series({ direction: 1 });
const now = longSeries.at(-1).timestamp;
const longObs = buildEarlyObservation({ contract: "ALT-USDT", snapshots: longSeries, now_ts: now });
assert.equal(longObs.status, "CLOSED");
assert.equal(longObs.direction_hint, "LONG");
assert.ok(longObs.long_evidence_domain_count >= 3);
assert.equal(longObs.final_entry, false);
assert.equal(longObs.probability, null);
assert.equal(longObs.shadow_only, true);

const shortSeries = series({ direction: -1 });
const shortObs = buildEarlyObservation({ contract: "ALT-USDT", snapshots: shortSeries, now_ts: shortSeries.at(-1).timestamp });
assert.equal(shortObs.direction_hint, "SHORT");
assert.ok(shortObs.short_evidence_domain_count >= 3);

// No look-ahead: a future shock must not change the observation at the same current timestamp.
const withFuture = series({ direction: 1, futureShock: true });
const noLookAheadObs = buildEarlyObservation({ contract: "ALT-USDT", snapshots: withFuture, now_ts: now });
assert.equal(noLookAheadObs.current.price, longObs.current.price);
assert.equal(noLookAheadObs.direction_hint, longObs.direction_hint);

// One isolated weak domain cannot create a directional watch.
const weak = structuredClone(longObs);
weak.evidence = [{ domain: "OI_ACCELERATION", side: "BOTH", status: "CLOSED" }];
weak.long_evidence_domains = ["OI_ACCELERATION"];
weak.short_evidence_domains = ["OI_ACCELERATION"];
weak.long_evidence_domain_count = 1;
weak.short_evidence_domain_count = 1;
weak.direction_hint = null;
weak.direction_state = "DIRECTION_NOT_CLOSED";
const weakMem = advanceEarlyCandidateMemory({ observation: weak });
assert.equal(weakMem.candidate.lifecycle_stage, "DISCOVERY");
assert.equal(weakMem.candidate.direction_hint, null);

// Multi-domain evidence must persist across cycles before PRE_IMPULSE_WATCH.
const first = advanceEarlyCandidateMemory({ observation: longObs });
assert.equal(first.candidate.lifecycle_stage, "DISCOVERY");
assert.equal(first.candidate.support_streak, 1);
const nextObs = { ...longObs, observation_ts: longObs.observation_ts + 5 * 60_000, current: { ...longObs.current, price: longObs.current.price * 1.001, oi_contracts: longObs.current.oi_contracts * 1.002 } };
const second = advanceEarlyCandidateMemory({ prior: first.candidate, observation: nextObs });
assert.equal(second.candidate.lifecycle_stage, "PRE_IMPULSE_WATCH");
assert.equal(second.candidate.first_seen_ts, first.candidate.first_seen_ts);
assert.equal(second.candidate.first_seen_price, first.candidate.first_seen_price);
assert.equal(second.candidate.wave_id, first.candidate.wave_id);
assert.equal(second.candidate.support_streak, 2);
assert.equal(second.candidate.remaining_edge.threshold_applied, false);

// Explicit new-wave input creates a distinct wave; it is never inferred from price distance alone.
const third = advanceEarlyCandidateMemory({ prior: second.candidate, observation: nextObs, new_wave: true });
assert.notEqual(third.candidate.wave_id, second.candidate.wave_id);
assert.equal(third.candidate.generation, second.candidate.generation + 1);

const rows = earlyCandidatePersistenceRows(longObs, first.candidate);
assert.equal(rows.status, "CLOSED");
assert.equal(rows.feature.shadow_only, 1);
assert.equal(rows.candidate.shadow_only, 1);
assert.ok(!Object.hasOwn(rows.feature, "probability"));

test("V3 early discovery self-normalized first-seen shadow layer", () => assert.equal(true, true));

test('feature fusion adds independent shadow evidence but context-only basis never counts directionally',()=>{
  const t0=1_900_000_000_000;
  const snaps=[];
  for(let i=0;i<30;i++){
    const ts=t0+i*300000;
    const p=100+i*0.03;
    const row=['ABC-USDT',p,1_000_000+i*1000,1000+i,100000,0.00005,1,5,'CLOSED',false,false,0,0];
    const btc=['BTC-USDT',50000+i*2,10_000_000,10000,500000000,0.00001,8,5,'CLOSED',false,false,0,0];
    const eth=['ETH-USDT',3000+i*0.1,8_000_000,8000,100000000,0.00001,8,5,'CLOSED',false,false,0,0];
    snaps.push({schema:'stage0-compact-v2',timestamp:ts,contracts:[row,btc,eth]});
  }
  const now=t0+29*300000;
  const fusion={version:'v3-early-feature-fusion-shadow-v1',status:'CLOSED',features:{
    price:{status:'CLOSED',breakout_attempt:true,failure:false,windows:{'5m':{change_pct:0.4}},acceleration_5m_vs_15m_pct_per_min:0.05},
    volume:{status:'CLOSED',relative_volume:{status:'CLOSED',percentile:0.9,robust_z:1.2},relative_trade_count:{percentile:0.8},volume_acceleration_vs_recent15m:1.4},
    orderflow:{status:'PARTIAL',absorption:true,delta:-50,cvd_change:-20},
    relative_strength:{status:'CLOSED',btc_1h_pct_points:1.2,eth_1h_pct_points:1.0,down_market_resilience:true},
    basis:{status:'CLOSED',basis_pct:0.3,dislocation_abs_pct:0.3,convergence:false,divergence:true},
    orderbook:{status:'CLOSED',imbalance:0.25,spread_pct:0.03,slippage_buy_bps:4},
    positioning:{status:'CLOSED',account_trajectory_consensus:'RISING_CONSENSUS',position_trajectory_consensus:'RISING_CONSENSUS',median_account_delta:0.1,median_position_delta:0.12},
    liquidation:{status:'PARTIAL'}
  }};
  const out=buildEarlyObservation({contract:'ABC-USDT',snapshots:snaps,now_ts:now,feature_fusion:fusion});
  assert.equal(out.final_entry,false);
  assert.equal(out.probability,null);
  assert.equal(out.shadow_only,true);
  assert.ok(out.long_evidence_domains.includes('PRICE_STATE_TRANSITION'));
  assert.ok(out.long_evidence_domains.includes('RELATIVE_STRENGTH'));
  assert.ok(out.long_evidence_domains.includes('EXECUTION_BOOK_SUPPORT'));
  assert.ok(out.long_evidence_domains.includes('POSITIONING_TRAJECTORY'));
  assert.equal(out.long_evidence_domains.includes('BASIS_CONTEXT'),false);
  assert.equal(out.long_evidence_domains.includes('ORDERFLOW_ABSORPTION'),false);
  assert.equal(out.direction_hint,'LONG');
});
