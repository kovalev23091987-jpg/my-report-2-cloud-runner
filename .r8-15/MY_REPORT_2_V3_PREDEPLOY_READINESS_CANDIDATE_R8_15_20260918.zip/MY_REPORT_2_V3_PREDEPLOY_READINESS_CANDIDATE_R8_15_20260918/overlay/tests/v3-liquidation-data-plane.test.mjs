import test from "node:test";
import assert from "node:assert/strict";
import {
  COVERAGE_CLASS,
  IDENTITY_STATUS,
  buildVenueIdentity,
  parseBybitAllLiquidation,
  parseGatePublicLiquidates,
  parseBinanceUsdmForceOrder,
  normalizeHtxLiquidationTapeEvent,
  okxLiquidationAdapterStatus,
  dedupeNormalizedEvents,
  aggregateRealizedLiquidations,
  buildRealizedDensityMap,
  createCollectorHealth,
  collectorConnected,
  collectorObservedEvent,
  collectorDisconnected,
  finalizeCollectorHealth,
  modelledLiquidationProxyStatus,
} from "../src/v3-liquidation-data-plane.mjs";

const NOW = 2_000_000_000_000;
const bybitIdentity = buildVenueIdentity({htx_contract:"BTC-USDT",venue:"BYBIT",venue_symbol:"BTCUSDT",verified:true});
assert.equal(bybitIdentity.identity_status, IDENTITY_STATUS.CLOSED);

const bybit = parseBybitAllLiquidation({topic:"allLiquidation.BTCUSDT",type:"snapshot",ts:NOW,data:[
  {T:NOW-100,s:"BTCUSDT",S:"Buy",v:"2",p:"50000"},
  {T:NOW-50,s:"BTCUSDT",S:"Sell",v:"1",p:"51000"},
]}, {identity:bybitIdentity,received_ts:NOW});
assert.equal(bybit.status,"CLOSED");
assert.equal(bybit.coverage_class,COVERAGE_CLASS.FULL_PROVIDER_DOCUMENTED_ALL);
assert.deepEqual(bybit.events.map(e=>e.liquidated_side_normalized),["LONG","SHORT"]);
assert.equal(bybit.events[0].price_semantics,"BANKRUPTCY_PRICE");
assert.equal(bybit.events[0].notional_usdt_normalized,100000);

const bybitUnverified = buildVenueIdentity({htx_contract:"BTC-USDT",venue:"BYBIT",venue_symbol:"BTCUSDT",verified:false});
assert.equal(parseBybitAllLiquidation({topic:"allLiquidation.BTCUSDT",type:"snapshot",data:[]},{identity:bybitUnverified}).status,"IDENTITY_UNRESOLVED");

const gateIdentity = buildVenueIdentity({htx_contract:"BTC-USDT",venue:"GATE",venue_symbol:"BTC_USDT",verified:true,multiplier:0.0001});
const gate = parseGatePublicLiquidates({channel:"futures.public_liquidates",event:"update",time_ms:NOW,result:[
  {price:"50000",size:"-10",time:NOW-200,contract:"BTC_USDT"},
  {price:"51000",size:"5",time:NOW-100,contract:"BTC_USDT"},
]}, {identity:gateIdentity,received_ts:NOW});
assert.equal(gate.coverage_class,COVERAGE_CLASS.AGGREGATED_EVENT_FEED);
assert.deepEqual(gate.events.map(e=>e.liquidated_side_normalized),["LONG","SHORT"]);
assert.equal(gate.events[0].qty_unit,"CONTRACTS");
assert.equal(gate.events[0].notional_usdt_normalized,50);

const gateNoMultiplier = parseGatePublicLiquidates({channel:"futures.public_liquidates",event:"update",result:[{price:"50000",size:"-10",time:NOW-100,contract:"BTC_USDT"}]},{identity:{...gateIdentity,multiplier:null},received_ts:NOW,quanto_multiplier:null});
assert.equal(gateNoMultiplier.events[0].notional_usdt_normalized,null,"missing multiplier must not be fabricated as zero or one");

const binanceIdentity = buildVenueIdentity({htx_contract:"BTC-USDT",venue:"BINANCE",venue_symbol:"BTCUSDT",verified:true});
const binance = parseBinanceUsdmForceOrder({e:"forceOrder",E:NOW,o:{s:"BTCUSDT",S:"SELL",q:"0.5",ap:"50000",T:NOW-300}},{identity:binanceIdentity,received_ts:NOW});
assert.equal(binance.status,"CLOSED_PARTIAL_COVERAGE");
assert.equal(binance.coverage_class,COVERAGE_CLASS.PARTIAL_SNAPSHOT);
assert.equal(binance.events[0].liquidated_side_normalized,"LONG");
assert.match(binance.source_semantics,/missing events are UNKNOWN/i);

const htxIdentity = buildVenueIdentity({htx_contract:"BTC-USDT",venue:"HTX",venue_symbol:"BTC-USDT",verified:true});
const htx = normalizeHtxLiquidationTapeEvent({event_id:"h1",contract_code:"BTC-USDT",side:"SHORT_LIQUIDATED",price:52000,volume_contracts:3,notional_usdt:156000,created_at:NOW-400,source:"HTX official public liquidation REST"},{identity:htxIdentity,received_ts:NOW});
assert.equal(htx.events[0].liquidated_side_normalized,"SHORT");
assert.equal(htx.events[0].notional_usdt_normalized,156000);

assert.equal(okxLiquidationAdapterStatus().status,"SOURCE_UNVERIFIED_CURRENT_CHANNEL");
assert.equal(modelledLiquidationProxyStatus().label,"MODELLED_PROXY");
assert.equal(modelledLiquidationProxyStatus().directional_decision_eligible,false);

const duped = dedupeNormalizedEvents([...bybit.events, bybit.events[0], ...gate.events, ...binance.events, ...htx.events]);
assert.equal(duped.length,6);
const agg = aggregateRealizedLiquidations(duped,{now_ts:NOW,windows:["1m","5m"]});
assert.equal(agg.projected_provider_map_included,false);
assert.equal(agg.modelled_proxy_included,false);
assert.equal(agg.windows["1m"].event_count_observed,6);
assert.equal(agg.windows["1m"].side_coverage_closed,true);
assert.equal(agg.windows["1m"].venue_breadth,4);

const missingNotionalEvent = {...bybit.events[0],source_event_id:"missing-notional",notional_usdt_normalized:null};
const partialAgg = aggregateRealizedLiquidations([missingNotionalEvent],{now_ts:NOW,windows:["1m"]});
assert.equal(partialAgg.windows["1m"].total_notional_usdt,null);
assert.equal(partialAgg.windows["1m"].known_notional_usdt,0);
assert.equal(partialAgg.windows["1m"].notional_coverage_closed,false);

const density = buildRealizedDensityMap(duped,{now_ts:NOW,reference_price:50000,bucket_size_pct:0.25});
assert.equal(density.status,"CLOSED");
assert.equal(density.future_heatmap,false);
assert.equal(density.projected_provider_map_included,false);
assert.ok(density.buckets.length>0);

let health = createCollectorHealth({venue:"BYBIT",expected_symbols:["BTC-USDT","ETH-USDT"],now_ts:NOW-1000});
health = collectorConnected(health,{now_ts:NOW-900});
health = collectorObservedEvent(health,bybit.events[0],{now_ts:NOW});
assert.equal(finalizeCollectorHealth(health,{now_ts:NOW+1000,stale_after_sec:5}).stale_state,"CURRENT");
assert.equal(finalizeCollectorHealth(health,{now_ts:NOW+10000,stale_after_sec:5}).stale_state,"STALE");
health = collectorDisconnected(health,{now_ts:NOW+11000});
assert.equal(finalizeCollectorHealth(health,{now_ts:NOW+11000}).stale_state,"DISCONNECTED");

test("V3 liquidation data plane fail-closed normalization",()=>{
  assert.equal(true,true);
});

test('V3 realized aggregation carries burst and market response only when context coverage is factual',()=>{
  const events=[
    {...bybit.events[0],source_event_id:'ctx1',ts_exchange:NOW-50_000},
    {...bybit.events[1],source_event_id:'ctx2',ts_exchange:NOW-20_000},
  ];
  const market_context={
    price_series:[{ts:NOW-60_000,price:100},{ts:NOW,price:101}],
    oi_series:[{ts:NOW-60_000,oi:1000},{ts:NOW,oi:1020}],
    flow_series:[{ts:NOW-50_000,delta:-100,coverage_closed:true},{ts:NOW-20_000,delta:50,coverage_closed:true}],
    volume_series:[{ts:NOW-50_000,notional_usdt:1_000_000,coverage_closed:true},{ts:NOW-20_000,notional_usdt:1_000_000,coverage_closed:true}],
  };
  const a=aggregateRealizedLiquidations(events,{now_ts:NOW,windows:['1m'],market_context}).windows['1m'];
  assert.equal(a.event_count_observed,2);
  assert.ok(a.burst_velocity_events_per_min>0);
  assert.equal(a.consecutive_burst_minutes,2);
  assert.equal(Number(a.price_response_pct.toFixed(6)),1);
  assert.equal(Number(a.oi_response_pct.toFixed(6)),2);
  assert.equal(a.flow_response_delta_usdt,-50);
  assert.ok(a.liquidation_to_volume_ratio>0);
  const partial=aggregateRealizedLiquidations(events,{now_ts:NOW,windows:['1m'],market_context:{volume_series:[{ts:NOW-10_000,notional_usdt:null,coverage_closed:false}],flow_series:[{ts:NOW-10_000,delta:0,coverage_closed:false}]}}).windows['1m'];
  assert.equal(partial.liquidation_to_volume_ratio,null);
  assert.equal(partial.flow_response_delta_usdt,null);
});
