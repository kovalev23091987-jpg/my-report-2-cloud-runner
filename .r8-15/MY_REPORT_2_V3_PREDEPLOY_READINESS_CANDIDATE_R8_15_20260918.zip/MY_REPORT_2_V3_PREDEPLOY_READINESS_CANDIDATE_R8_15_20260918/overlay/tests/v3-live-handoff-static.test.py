from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
worker=(ROOT/'src/worker.js').read_text(encoding='utf-8')
module=(ROOT/'src/v3-live-handoff.mjs').read_text(encoding='utf-8')
required_module={
 'plan':'export function buildV3LiveHandoffPlan',
 'zero':'export function classifyV3LiveHandoffZeroReason',
 'health':'export function assessV3PipelineHealth',
 'envelope':'export function buildDiscoveryHandoffEnvelope',
 'exact_identity':'parseExactHtxUsdtContract',
 'live':'LIVE_DISCOVERY',
 'fast':'LIVE_FAST_MOVE_RECHECK',
 'maintenance':'MAINTENANCE',
 'degraded':'DEGRADED_PIPELINE',
 'healthy':'HEALTHY_NO_IDEA',
}
missing=[k for k,v in required_module.items() if v not in module]
assert not missing, missing
assert 'from "./v3-live-handoff.mjs"' in worker
assert 'liveHandoffPlan' in worker
assert '"v3_live_handoff_health"' in worker
assert 'liveHandoffPlan\n                ?.require_exact_contract' in worker
assert 'liveHandoffPlan\n                ?.required_contract' in worker
# worker must not retain a second divergent helper implementation
assert 'function buildV3LiveHandoffPlan' not in worker
assert 'function classifyV3LiveHandoffZeroReason' not in worker
assert 'function assessV3PipelineHealth' not in worker
print('V3_LIVE_HANDOFF_STATIC=PASS')
