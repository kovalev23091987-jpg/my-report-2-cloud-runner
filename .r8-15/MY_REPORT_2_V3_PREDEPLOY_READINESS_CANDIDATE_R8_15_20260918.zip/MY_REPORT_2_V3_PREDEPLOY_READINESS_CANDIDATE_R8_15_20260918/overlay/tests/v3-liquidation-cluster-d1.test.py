from pathlib import Path
import sqlite3
root=Path(__file__).resolve().parents[1];sql=(root/'migrations/20260917_v3_data_plane_shadow.sql').read_text();con=sqlite3.connect(':memory:');con.executescript(sql);con.executescript(sql)
tables={r[0] for r in con.execute("select name from sqlite_master where type='table'")};assert 'v3_projected_cluster_lifecycle_shadow' in tables
con.execute("insert into v3_projected_cluster_lifecycle_shadow(cluster_key,contract_code,provider,cluster_type,side,level_price,first_seen_ts,last_seen_ts,lifecycle,guaranteed_tp,shadow_only) values('k','RAY-USDT','P','PROJECTED_PROVIDER_MAP','SHORT_LIQUIDATION_ABOVE',110,1,1,'ACTIVE',0,1)")
try:
 con.execute("update v3_projected_cluster_lifecycle_shadow set guaranteed_tp=1 where cluster_key='k'")
 raise AssertionError('guaranteed_tp=1 accepted')
except sqlite3.IntegrityError: pass
print('V3_LIQUIDATION_CLUSTER_D1=PASS')
