from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
sql = (ROOT / "migrations" / "20260917_v3_data_plane_shadow.sql").read_text(encoding="utf-8")
con = sqlite3.connect(":memory:")
con.executescript(sql)
# Idempotent migration.
con.executescript(sql)

tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
required = {
    "v3_source_health_1m",
    "v3_realized_liquidation_aggregate",
    "v3_realized_liquidation_density_5m",
}
assert required <= tables, (required, tables)
cols={r[1] for r in con.execute("pragma table_info(v3_realized_liquidation_aggregate)")}
for c in {"burst_velocity_events_per_min","burst_acceleration_events_per_min","consecutive_burst_minutes","liquidation_to_volume_ratio","price_response_pct","oi_response_pct","flow_response_delta_usdt"}: assert c in cols,c

# Missing/not-closed factual values remain NULL rather than fabricated zero.
con.execute("""
INSERT INTO v3_realized_liquidation_aggregate(
  contract_code,window_name,end_ts,event_count_observed,known_side_count,unknown_side_count,
  known_long_liquidation_count,known_short_liquidation_count,known_notional_usdt,venue_breadth,
  side_coverage_closed,notional_coverage_closed,persisted_ts
) VALUES('BTC-USDT','1m',1000,1,0,1,0,0,0,1,0,0,1000)
""")
row = con.execute("select long_liquidation_count,total_notional_usdt,side_coverage_closed,notional_coverage_closed from v3_realized_liquidation_aggregate").fetchone()
assert row == (None, None, 0, 0), row

# Safety fields cannot be flipped out of shadow-only mode.
try:
    con.execute("insert into v3_source_health_1m(source_id,venue,bucket_ts,health_state,persisted_ts,shadow_only) values('X','X',1,'OK',1,0)")
    raise AssertionError("shadow_only=0 unexpectedly accepted")
except sqlite3.IntegrityError:
    pass

print("V3_DATA_PLANE_D1=PASS")
