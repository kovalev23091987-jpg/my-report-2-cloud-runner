import sqlite3, pathlib
p=pathlib.Path(__file__).resolve().parents[1]/'migrations'/'20260917_v3_telegram_lifecycle_shadow.sql'
sql=p.read_text()
db=sqlite3.connect(':memory:')
db.executescript(sql)
for t in ['v3_user_lifecycle_shadow','v3_telegram_dispatch_shadow','v3_pipeline_health_shadow']:
    assert db.execute("select name from sqlite_master where type='table' and name=?",(t,)).fetchone(), t
# fail closed constraints
try:
    db.execute("insert into v3_user_lifecycle_shadow(contract,direction,wave_id,rules_version,status,reason,observation_ts,updated_ts,shadow_only) values(?,?,?,?,?,?,?,?,?)",('A-USDT','BOTH','w','V3','OBSERVE','x',1,1,1))
    raise AssertionError('direction constraint missing')
except sqlite3.IntegrityError: pass
try:
    db.execute("insert into v3_pipeline_health_shadow(namespace,status,reasons_json,changed_ts,last_checked_ts,shadow_only) values(?,?,?,?,?,?)",('PIPELINE','MAGIC','[]',1,1,1))
    raise AssertionError('health constraint missing')
except sqlite3.IntegrityError: pass
print('V3_TELEGRAM_D1=PASS')
