from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
sql = (ROOT / "migrations" / "20260917_v3_early_discovery_shadow.sql").read_text(encoding="utf-8")
con = sqlite3.connect(":memory:")
con.executescript(sql)
con.executescript(sql)

tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
required = {"v3_early_feature_snapshot", "v3_early_candidate_wave", "v3_early_outcome_journal"}
assert required <= tables, (required, tables)

cols = {r[1] for r in con.execute("pragma table_info(v3_early_candidate_wave)")}
required_cols = {
    "first_seen_relative_strength_json","first_seen_volume_json","first_seen_liquidation_json",
    "first_seen_orderflow_json","first_seen_execution_state","move_before_first_seen",
    "elapsed_since_first_seen_sec","direction_state"
}
assert required_cols <= cols, (required_cols-cols)

outcome_cols = {r[1] for r in con.execute("pragma table_info(v3_early_outcome_journal)")}
required_outcome = {
    "rules_version","decision_without_filter_json","decision_with_filter_json","first_seen_context_json",
    "entry_condition_json","invalidation_json","regime","liquidity_bucket","realized_r","model_r",
    "lost_rr","prevented_bad_entry","missed_good_entry","late_entry_avoided","early_alert_useful"
}
assert required_outcome <= outcome_cols, (required_outcome-outcome_cols)

con.execute("""
insert into v3_early_feature_snapshot(
 contract_code,ts_bucket,observed_ts,rules_version,direction_hint,direction_state,
 long_evidence_domain_count,short_evidence_domain_count,early_detection_quality_0_100,
 feature_json,evidence_json,shadow_only
) values('ALT-USDT',1,1,'v3',NULL,'DIRECTION_NOT_CLOSED',1,1,55,'{}','[]',1)
""")
row = con.execute("select direction_hint,shadow_only from v3_early_feature_snapshot").fetchone()
assert row == (None, 1), row

try:
    con.execute("insert into v3_early_candidate_wave(wave_id,contract_code,generation,first_seen_ts,first_seen_detectors_json,lifecycle_stage,support_streak,early_detection_quality_0_100,remaining_edge_json,evidence_refs_json,last_seen_ts,shadow_only) values('x','ALT-USDT',1,1,'[]','DISCOVERY',0,10,'{}','[]',1,0)")
    raise AssertionError("shadow_only=0 unexpectedly accepted")
except sqlite3.IntegrityError:
    pass

print("V3_EARLY_DISCOVERY_D1=PASS")
