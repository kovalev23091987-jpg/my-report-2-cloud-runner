from pathlib import Path
import sqlite3
root=Path(__file__).resolve().parents[1]
sql=(root/'migrations/20260917_v3_telegram_lifecycle_shadow.sql').read_text()
con=sqlite3.connect(':memory:');con.executescript(sql);con.executescript(sql)
tables={r[0] for r in con.execute("select name from sqlite_master where type='table'")}
assert {'v3_pipeline_health_shadow','v3_pipeline_health_event_shadow'}<=tables
con.execute("insert into v3_pipeline_health_shadow(namespace,status,reasons_json,changed_ts,last_checked_ts,shadow_only) values('PIPELINE','HEALTHY_NO_IDEA','[]',1,1,1)")
con.execute("insert into v3_pipeline_health_event_shadow(event_id,transition,from_status,to_status,reasons_json,state,created_ts,updated_ts,shadow_only) values('e1','DEGRADED','HEALTHY_NO_IDEA','DEGRADED_PIPELINE','[]','PENDING',2,2,1)")
try:
 con.execute("insert into v3_pipeline_health_event_shadow(event_id,transition,from_status,to_status,reasons_json,state,created_ts,updated_ts,shadow_only) values('e2','DEGRADED','HEALTHY_NO_IDEA','DEGRADED_PIPELINE','[]','PENDING',2,2,0)")
 raise AssertionError('shadow_only=0 accepted')
except sqlite3.IntegrityError: pass
print('V3_PIPELINE_HEALTH_D1=PASS')
