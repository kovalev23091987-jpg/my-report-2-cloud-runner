#!/usr/bin/env python3
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
worker=(root/'src/worker.js').read_text()
mod=(root/'src/v3-live-handoff.mjs').read_text()
mig=(root/'migrations/20260917_v3_live_handoff_wiring_shadow.sql').read_text()
assert 'buildDiscoveryHandoffEnvelope' in worker
assert 'v3_handoff_id' in worker and 'v3_dedup_reentry_key' in worker
assert 'v3_discovery_deep_handoff_shadow' not in worker, 'hot path must not add direct journal D1 queries'
assert 'trg_v3_handoff_scheduler_insert_claim' in mig
assert 'trg_v3_handoff_scheduler_update_claim' in mig
assert 'trg_v3_handoff_scheduler_finalize' in mig
assert "state = CASE WHEN NEW.last_status='COMPLETED' THEN 'COMPLETED' ELSE 'FAILED_RETRYABLE' END" in mig
m=re.search(r'CONSERVATIVE_DEEP_CHECK_D1_QUERY_BUDGET\s*=\s*(\d+)',worker); assert m and int(m.group(1))==48
m=re.search(r'D1_FREE_QUERY_LIMIT\s*=\s*(\d+)',worker); assert m and int(m.group(1))==50
assert "LIVE_HANDOFF_UNMAPPED_FAIL_CLOSED" in mod
print('V3_LIVE_HANDOFF_WIRING_STATIC=PASS extra_worker_queries=0 d1_peak=48/50')
