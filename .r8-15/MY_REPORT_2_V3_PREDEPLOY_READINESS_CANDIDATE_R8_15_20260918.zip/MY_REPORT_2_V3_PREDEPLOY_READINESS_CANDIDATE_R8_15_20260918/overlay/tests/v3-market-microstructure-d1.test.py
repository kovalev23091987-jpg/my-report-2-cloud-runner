import sqlite3, pathlib
sql=pathlib.Path(__file__).parents[1]/'migrations/20260917_v3_data_plane_shadow.sql'
db=sqlite3.connect(':memory:');db.executescript(sql.read_text())
cols={r[1] for r in db.execute('pragma table_info(v3_market_microstructure_1m)')}
need={'contract_code','venue','bucket_ts','taker_buy_usdt','taker_sell_usdt','delta_usdt','trade_notional_coverage_closed','top20_bid_usdt','top20_ask_usdt','book_gap_detected','coverage_json'}
assert need<=cols,(need-cols)
assert db.execute("select sql from sqlite_master where type='table' and name='v3_market_microstructure_1m'").fetchone()
print('V3_MARKET_MICROSTRUCTURE_D1=PASS')
