from pathlib import Path
root=Path(__file__).resolve().parents[1]
text=(root/'cloudflare/v3-liquidation-collector-do.mjs').read_text()
toml=(root/'cloudflare/wrangler.v3-collector-probe.toml.template').read_text()
assert 'CONTINUOUS_MODE_FORBIDDEN_UNTIL_COST_ENDURANCE_PROOF' in text
assert "X-Gate-Size-Decimal" in text
assert 'setAlarm' in text and 'deleteAlarm' in text
assert 'production_enabled:false' in text
assert 'PROBE_ROUTE_NOT_FOUND' in text
assert 'DURABLE_OBJECT_BINDING_MISSING' in text
assert 'PROBE_AUTH_REQUIRED' in text
assert 'PROBE_KEY_NOT_CONFIGURED' in text
assert 'v3-liquidation-probe' in text
assert 'getByName' in text
assert 'x-report2-v3-probe-key' in text
assert 'V3_PROBE_KEY' in text
assert 'production routes' in toml.lower()
assert 'new_sqlite_classes' in toml
assert 'V3_PROBE_KEY' in toml
print('V3_COLLECTOR_DO_STATIC=PASS')
