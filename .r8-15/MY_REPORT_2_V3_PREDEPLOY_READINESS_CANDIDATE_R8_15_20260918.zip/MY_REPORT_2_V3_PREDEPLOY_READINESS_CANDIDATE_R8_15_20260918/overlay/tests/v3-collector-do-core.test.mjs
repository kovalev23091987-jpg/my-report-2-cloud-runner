import test from 'node:test';
import assert from 'node:assert/strict';
import {buildDurableCollectorProbeConfig,initialDurableProbeState,durableProbeTransition,normalizeDurableCollectorFrame,V3_DO_PROBE_MAX_RUNTIME_MS} from '../src/v3-collector-do-core.mjs';
import {buildVenueIdentity} from '../src/v3-liquidation-data-plane.mjs';
const by=buildVenueIdentity({htx_contract:'BTC-USDT',venue:'BYBIT',venue_symbol:'BTCUSDT',verified:true});
const gate=buildVenueIdentity({htx_contract:'BTC-USDT',venue:'GATE',venue_symbol:'BTC_USDT',verified:true,multiplier:0.0001});

test('bounded probe refuses continuous-length runtime and accepts audited Binance market route',()=>{
  assert.equal(buildDurableCollectorProbeConfig({venue:'BYBIT',requested_runtime_ms:V3_DO_PROBE_MAX_RUNTIME_MS+1}).status,'PROBE_DURATION_EXCEEDS_BOUND');
  const bn=buildDurableCollectorProbeConfig({venue:'BINANCE',htx_contracts:['BTC-USDT'],identity_by_contract:{'BTC-USDT':buildVenueIdentity({htx_contract:'BTC-USDT',venue:'BINANCE',venue_symbol:'BTCUSDT',verified:true})},requested_runtime_ms:60000});
  assert.equal(bn.status,'CLOSED');
  assert.equal(bn.probe_status,'READY');
  assert.equal(bn.plan.url,'wss://fstream.binance.com/market/stream');
  assert.deepEqual(bn.plan.subscriptions,['btcusdt@forceOrder']);
});

test('Bybit probe normalizes per-symbol message with closed identity',()=>{
  const cfg=buildDurableCollectorProbeConfig({venue:'BYBIT',htx_contracts:['BTC-USDT'],identity_by_contract:{'BTC-USDT':by},requested_runtime_ms:60000,now_ts:1000});
  assert.equal(cfg.probe_status,'READY');
  const out=normalizeDurableCollectorFrame({config:cfg,received_ts:1200,message:{topic:'allLiquidation.BTCUSDT',type:'snapshot',data:[{T:1100,s:'BTCUSDT',S:'Buy',v:'2',p:'50000'}]}});
  assert.equal(out.status,'CLOSED');assert.equal(out.events.length,1);assert.equal(out.events[0].liquidated_side_normalized,'LONG');
});

test('Gate probe requires decimal-header capability and keeps factual multiplier',()=>{
  const blocked=buildDurableCollectorProbeConfig({venue:'GATE',htx_contracts:['BTC-USDT'],identity_by_contract:{'BTC-USDT':gate},requested_runtime_ms:60000,websocket_header_capable:false});
  assert.equal(blocked.status,'GATE_DECIMAL_HEADER_REQUIRED');
  const cfg=buildDurableCollectorProbeConfig({venue:'GATE',htx_contracts:['BTC-USDT'],identity_by_contract:{'BTC-USDT':gate},requested_runtime_ms:60000,websocket_header_capable:true,now_ts:1000});
  const out=normalizeDurableCollectorFrame({config:cfg,received_ts:1200,message:{channel:'futures.public_liquidates',event:'update',result:[{contract:'BTC_USDT',price:'60000',size:'-10.5',time:1100}]}});
  assert.ok(Math.abs(out.events[0].notional_usdt_normalized-63)<1e-9);
  assert.equal(out.events[0].source_coverage_class,'AGGREGATED_EVENT_FEED');
});

test('state reconnects with bounded alarm and stop produces explicit endurance verdict',()=>{
  const cfg=buildDurableCollectorProbeConfig({venue:'BYBIT',htx_contracts:['BTC-USDT'],identity_by_contract:{'BTC-USDT':by},requested_runtime_ms:60000,now_ts:1000});
  let s=initialDurableProbeState(cfg);s=durableProbeTransition(s,{type:'CONNECTED',now_ts:1000});
  s=durableProbeTransition(s,{type:'MESSAGE',now_ts:1200,exchange_ts:1100,normalized_events:1});
  s=durableProbeTransition(s,{type:'DISCONNECTED',now_ts:2000,error:'test'});
  assert.equal(s.next_action,'RECONNECT');assert.ok(s.next_action_ts<=cfg.stop_ts);
  s=durableProbeTransition(s,{type:'STOP',now_ts:61000,min_messages:1});
  assert.equal(s.status,'STOPPED');assert.equal(s.probe_result.status,'CLOSED');
});
