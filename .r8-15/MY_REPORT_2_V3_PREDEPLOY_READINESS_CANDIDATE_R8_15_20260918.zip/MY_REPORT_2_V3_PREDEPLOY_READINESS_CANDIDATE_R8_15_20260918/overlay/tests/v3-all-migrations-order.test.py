#!/usr/bin/env python3
from pathlib import Path
import sqlite3
root=Path(__file__).resolve().parents[1]
db=sqlite3.connect(':memory:')
# cron_runs already exists in R9 production; create its authoritative base shape for additive V3 ALTER tests.
db.execute('''CREATE TABLE cron_runs (run_id TEXT PRIMARY KEY, scheduled_time INTEGER, started_ts INTEGER, completed_ts INTEGER, status TEXT, universe_total INTEGER, scanned INTEGER, persistence_status TEXT, error_text TEXT)''')
order=[
 'migrations/report2_deep_check_scheduler_state.sql',
 'migrations/report2_deep_check_run_log.sql',
 'migrations/20260917_v3_live_handoff_shadow.sql',
 'migrations/20260917_v3_live_handoff_wiring_shadow.sql',
 'migrations/20260917_v3_data_plane_shadow.sql',
 'migrations/20260917_v3_early_discovery_shadow.sql',
 'migrations/20260917_v3_telegram_lifecycle_shadow.sql',
 'migrations/20260917_v3_cron_pipeline_telemetry_shadow.sql',
]
for rel in order:
    db.executescript((root/rel).read_text())
required_tables={
 'v3_discovery_deep_handoff_shadow','v3_early_feature_snapshot','v3_early_candidate_wave',
 'v3_early_outcome_journal','v3_user_lifecycle_shadow','v3_telegram_dispatch_shadow',
 'v3_pipeline_health_shadow'
}
# Data-plane table names are asserted by its dedicated test; pull all v3 tables for audit.
tables={r[0] for r in db.execute("select name from sqlite_master where type='table'")}
assert required_tables <= tables, required_tables-tables
triggers={r[0] for r in db.execute("select name from sqlite_master where type='trigger'")}
assert {'trg_v3_handoff_scheduler_insert_claim','trg_v3_handoff_scheduler_update_claim','trg_v3_handoff_scheduler_finalize'} <= triggers
# Verify additive columns exist on inherited tables after wiring.
sched={r[1] for r in db.execute('pragma table_info(deep_check_scheduler_state)')}
log={r[1] for r in db.execute('pragma table_info(deep_check_run_log)')}
for col in ('v3_handoff_id','v3_scan_ts','v3_discovery_rank','v3_wave_id','v3_dedup_reentry_key'):
    assert col in sched and col in log, col
cron={r[1] for r in db.execute('pragma table_info(cron_runs)')}
for col in ('v3_discovery_shortlist_count','v3_live_shortlist_count','v3_live_deep_check_count','v3_live_zero_reason','v3_pipeline_health_status','v3_pipeline_health_reason','v3_live_lane','v3_maintenance_deferred'):
    assert col in cron, col
print('V3_ALL_MIGRATIONS_ORDER=PASS')
