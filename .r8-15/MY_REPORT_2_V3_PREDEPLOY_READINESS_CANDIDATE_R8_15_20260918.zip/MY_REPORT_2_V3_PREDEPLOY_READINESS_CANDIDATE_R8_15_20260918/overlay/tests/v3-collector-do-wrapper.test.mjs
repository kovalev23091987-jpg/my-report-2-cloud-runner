import test from 'node:test';
import assert from 'node:assert/strict';
import {V3LiquidationCollectorProbe} from '../cloudflare/v3-liquidation-collector-do.mjs';
import {buildVenueIdentity} from '../src/v3-liquidation-data-plane.mjs';

class FakeStorage {
  constructor(){this.map=new Map();this.alarm=null;}
  async put(k,v){this.map.set(k,structuredClone(v));}
  async get(k){const v=this.map.get(k);return v===undefined?undefined:structuredClone(v);}
  async setAlarm(ts){this.alarm=Number(ts);}
  async deleteAlarm(){this.alarm=null;}
}
class FakeCtx {
  constructor(){this.storage=new FakeStorage();this.pending=[];}
  waitUntil(p){const q=Promise.resolve(p);this.pending.push(q);return q;}
  async drain(){await Promise.allSettled(this.pending.splice(0));}
}
class FakeSocket {
  constructor(){this.listeners=new Map();this.sent=[];this.accepted=false;this.closed=false;}
  accept(){this.accepted=true;}
  send(v){this.sent.push(v);}
  addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,[]);this.listeners.get(type).push(fn);}
  close(){this.closed=true;}
  emit(type,payload={}){for(const fn of this.listeners.get(type)||[])fn(payload);}
}
function bybitBody(extra={}){
  return {
    venue:'BYBIT',requested_runtime_ms:60_000,htx_contracts:['BTC-USDT'],
    identity_by_contract:{'BTC-USDT':buildVenueIdentity({htx_contract:'BTC-USDT',venue:'BYBIT',venue_symbol:'BTCUSDT',verified:true})},
    ...extra,
  };
}

async function responseJson(r){return JSON.parse(await r.text());}

test('wrapper forbids continuous mode before touching storage',async()=>{
  const ctx=new FakeCtx();const obj=new V3LiquidationCollectorProbe(ctx,{});
  const r=await obj.fetch(new Request('https://probe/start',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(bybitBody({continuous:true}))}));
  assert.equal(r.status,409);assert.equal((await responseJson(r)).status,'CONTINUOUS_MODE_FORBIDDEN_UNTIL_COST_ENDURANCE_PROOF');
  assert.equal(ctx.storage.map.size,0);
});

test('start persists bounded config/state, subscribes, status reads back, stop is explicit',async()=>{
  const ctx=new FakeCtx();const obj=new V3LiquidationCollectorProbe(ctx,{});const ws=new FakeSocket();
  obj.openSocket=async()=>ws;
  const r=await obj.fetch(new Request('https://probe/start',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(bybitBody())}));
  assert.equal(r.status,200);const body=await responseJson(r);assert.equal(body.status,'PROBE_STARTED');assert.equal(body.production_enabled,false);
  assert.equal(ws.sent.length,1);assert.match(ws.sent[0],/allLiquidation\.BTCUSDT/);
  const state=await ctx.storage.get('v3_probe_state');assert.equal(state.status,'RUNNING');assert.equal(state.production_enabled,false);assert.ok(ctx.storage.alarm>0);
  const sr=await obj.fetch(new Request('https://probe/status'));const status=await responseJson(sr);assert.equal(status.state.status,'RUNNING');assert.equal(status.production_enabled,false);
  const stop=await obj.fetch(new Request('https://probe/stop',{method:'POST'}));assert.equal((await responseJson(stop)).status,'STOPPED');
  const stopped=await ctx.storage.get('v3_probe_state');assert.equal(stopped.status,'STOPPED');assert.equal(ctx.storage.alarm,null);assert.equal(ws.closed,true);
});

test('disconnect schedules bounded reconnect and alarm never exceeds stop time',async()=>{
  const ctx=new FakeCtx();const obj=new V3LiquidationCollectorProbe(ctx,{});const ws=new FakeSocket();obj.openSocket=async()=>ws;
  await obj.fetch(new Request('https://probe/start',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(bybitBody())}));
  await obj.onSocketEnd('DISCONNECTED','TEST_CLOSE');
  const state=await ctx.storage.get('v3_probe_state');assert.equal(state.status,'RECONNECT_WAIT');assert.equal(state.next_action,'RECONNECT');assert.ok(state.next_action_ts<=state.stop_ts);assert.equal(ctx.storage.alarm,state.next_action_ts);
});

import workerDefault from '../cloudflare/v3-liquidation-collector-do.mjs';

test('default router is secret-gated before DO binding',async()=>{
  const noSecret=await workerDefault.fetch(new Request('https://probe/v3-liquidation-probe/bybit/status'),{});
  assert.equal(noSecret.status,503);assert.equal((await responseJson(noSecret)).status,'PROBE_KEY_NOT_CONFIGURED');
  let called=0;
  const env={V3_PROBE_KEY:'correct-secret',LIQ_PROBE:{getByName(name){return {async fetch(req){called++;return new Response(JSON.stringify({name,path:new URL(req.url).pathname}),{headers:{'content-type':'application/json'}});}};}}};
  const bad=await workerDefault.fetch(new Request('https://probe/v3-liquidation-probe/bybit/status',{headers:{'x-report2-v3-probe-key':'wrong'}}),env);
  assert.equal(bad.status,403);assert.equal(called,0);
  const good=await workerDefault.fetch(new Request('https://probe/v3-liquidation-probe/bybit/status',{headers:{'x-report2-v3-probe-key':'correct-secret'}}),env);
  assert.equal(good.status,200);const body=await responseJson(good);assert.equal(body.name,'v3-liquidation-probe:BYBIT');assert.equal(body.path,'/status');assert.equal(called,1);
});
