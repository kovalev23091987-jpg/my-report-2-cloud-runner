import assert from 'node:assert/strict';
import {V3_EARLY_SIDECAR_BUDGET} from '../src/v3-early-sidecar.mjs';
import {V3_EARLY_MAX_PERSIST_CANDIDATES_PER_CYCLE} from '../src/v3-early-persistence-runtime.mjs';
const runs=288;
const baseline={reads:936864,writes:12672}; // measured natural run #154 projection
const safety={reads:3500000,writes:70000};
const worst={reads:baseline.reads+V3_EARLY_SIDECAR_BUDGET.rows_read*runs,writes:baseline.writes+V3_EARLY_SIDECAR_BUDGET.rows_written*runs};
assert.ok(worst.reads<safety.reads);
assert.ok(worst.writes<safety.writes);
const reservation={reads:Math.floor(3500000/288),writes:Math.floor(70000/288)};
assert.equal(V3_EARLY_MAX_PERSIST_CANDIDATES_PER_CYCLE,1);
assert.equal(V3_EARLY_SIDECAR_BUDGET.rows_written,24);
// R8.8 uses an adaptive 320-write burst cap while preserving the 70k/day admission ceiling.
// R8.7 observed 187 writes before sidecars; one bounded early candidate + downstream reserve must fit.
assert.ok(187+V3_EARLY_SIDECAR_BUDGET.rows_written+50<=320);
assert.ok(V3_EARLY_SIDECAR_BUDGET.rows_read+64<reservation.reads);
assert.ok(V3_EARLY_SIDECAR_BUDGET.rows_written+41<reservation.writes);
console.log('V3_EARLY_SIDECAR_BUDGET=PASS',JSON.stringify({baseline,worst,safety,reservation,sidecar:V3_EARLY_SIDECAR_BUDGET}));
