from pathlib import Path
root=Path(__file__).resolve().parents[1]
for rel in ["src/worker.js","src/liquidation-intelligence.mjs"]:
    s=(root/rel).read_text()
    assert "const MAX_LIFECYCLE_STATE_ROWS = 32;" in s, rel
    assert "const MAX_LIFECYCLE_STATE_ROWS = 80;" not in s, rel
print("R8_15_CLUSTER_STATE_BURST_CAP_STATIC=PASS")
