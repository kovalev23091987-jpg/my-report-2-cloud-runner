import test from 'node:test';
import assert from 'node:assert/strict';
import {buildOutcomeTasks,resolveEarlyOutcome,V3_EARLY_MAX_D1_STATEMENTS_PER_CANDIDATE} from '../src/v3-early-persistence-runtime.mjs';

const c={wave_id:'EDW:RAY:1000:G1',contract_code:'RAY-USDT',first_seen_ts:1000,direction_hint:'LONG'};
const tasks=buildOutcomeTasks(c);
assert.deepEqual(tasks.map(x=>x.horizon_hours),[1,4,12,24]);
assert.equal(new Set(tasks.map(x=>x.outcome_id)).size,4);
const t=tasks[0];
const path=[{ts:t.target_ts-1000,price:110},{ts:t.target_ts,price:108}];
const out=resolveEarlyOutcome({task:t,first_seen_price:100,price_path:path,computed_ts:t.target_ts+1});
assert.equal(out.status,'CLOSED');
assert.equal(Math.round(out.outcome.raw_return_pct),8);
assert.equal(Math.round(out.outcome.mfe_pct),10);
assert.equal(Math.round(out.outcome.mae_pct),8);
assert.equal(out.outcome.probability,null);
const shortOut=resolveEarlyOutcome({task:{...t,direction_hint:'SHORT'},first_seen_price:100,price_path:[{ts:t.target_ts,price:90}]});
assert.equal(Math.round(shortOut.outcome.directional_return_pct),10);
assert.ok(V3_EARLY_MAX_D1_STATEMENTS_PER_CANDIDATE<=3);
test('V3 early persistence outcome tasks are bounded and non-probabilistic',()=>assert.equal(true,true));

class FakeStmt { constructor(sql){this.sql=sql;this.args=[];} bind(...args){this.args=args;return this;} }
class FakeDb { constructor(){this.statements=[];} prepare(sql){const s=new FakeStmt(sql);this.statements.push(s);return s;} async batch(stmts){return stmts.map(()=>({meta:{changes:1}}));} }
const obs={status:'CLOSED',contract:'RAY-USDT',observation_ts:300000,rules_version:'x',direction_hint:'LONG',direction_state:'LONG_EARLY',long_evidence_domain_count:3,short_evidence_domain_count:0,early_detection_quality_0_100:55,windows:{},acceleration:{},self_normalized:{},relative_strength:{},evidence:[]};
const cand={...c,generation:1,first_seen_price:1,first_seen_oi:2,first_seen_funding:-0.0001,first_seen_detectors:[],lifecycle_stage:'DISCOVERY',support_streak:1,move_since_first_seen:0,oi_change_since_first_seen:0,early_detection_quality_0_100:55,remaining_edge:{status:'NOT_VALIDATED_SHADOW'},evidence_refs:[],last_seen_ts:300000};
const {persistEarlyCandidateShadow}=await import('../src/v3-early-persistence-runtime.mjs');
const db=new FakeDb();
const persisted=await persistEarlyCandidateShadow(db,{observation:obs,candidate:cand,new_wave_opened:true});
assert.equal(persisted.status,'CLOSED');
assert.equal(persisted.statements,3);
assert.equal(db.statements.length,3);
assert.ok(db.statements[0].sql.includes('v3_early_feature_snapshot'));
assert.ok(db.statements[1].sql.includes('v3_early_candidate_wave'));
assert.ok(db.statements[2].sql.includes('v3_early_outcome_journal'));
