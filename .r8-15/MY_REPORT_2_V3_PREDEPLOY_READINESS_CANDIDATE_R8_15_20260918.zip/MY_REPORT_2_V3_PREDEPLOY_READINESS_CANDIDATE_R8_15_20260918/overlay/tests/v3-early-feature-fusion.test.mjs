import test from 'node:test';import assert from 'node:assert/strict';import {buildEarlyFeatureFusion} from '../src/v3-early-feature-fusion.mjs';
const NOW=2_000_000_000_000;const step=5*60_000;
function series(n,fn){return Array.from({length:n},(_,i)=>fn(i,NOW-(n-1-i)*step));}
test('feature fusion computes broad factual families without probability',()=>{
 const price=series(30,(i,ts)=>({ts,price:100+i*.1,open:100+i*.1-.05,high:100+i*.1+.1,low:100+i*.1-.1,close:100+i*.1}));
 const oi=series(30,(i,ts)=>({ts,oi:1000+i*5}));
 const funding=series(30,(i,ts)=>({ts,venue:i%2?'HTX':'BYBIT',rate:-0.0002-i*0.000001,interval_hours:1}));
 const vol=series(30,(i,ts)=>({ts,spot_volume:100+i,futures_volume:200+i*3,trade_count:1000+i*5}));
 const flow=series(30,(i,ts)=>({ts,taker_buy:100,taker_sell:90,delta:10,cvd:i*10,coverage_closed:true}));
 const basis=series(5,(i,ts)=>({ts,mark:103+i*.1,index:102.8+i*.1,spot:102.7+i*.1}));
 const book=series(5,(i,ts)=>({ts,bid:102.9,ask:103.0,top1_bid_usdt:10000,top1_ask_usdt:9000,top20_bid_usdt:100000+i*1000,top20_ask_usdt:90000,slippage_buy_bps:4,slippage_sell_bps:5,exit_liquidity_usdt:180000,coverage_closed:true}));
 const pos=[{ts:NOW-1000,venue:'HTX',top_account_ratio:1.1,top_position_ratio:1.2},{ts:NOW-1000,venue:'BYBIT',top_account_ratio:1.05,top_position_ratio:1.25}];
 const r=buildEarlyFeatureFusion({now_ts:NOW,price_series:price,oi_series:oi,funding_series:funding,volume_series:vol,orderflow_series:flow,basis_series:basis,orderbook_series:book,positioning_series:pos,relative_strength:{coverage_closed:true,btc_1h_pct_points:1,eth_1h_pct_points:.8,down_market_resilience:true},liquidation_context:{coverage_closed:true,count:4,notional_usdt:100000,burst_velocity:2,burst_acceleration:1}});
 assert.equal(r.status,'CLOSED');assert.equal(r.probability,null);assert.equal(r.final_entry,false);assert.equal(r.no_lookahead,true);assert.ok(r.closed_domain_count>=8);assert.equal(r.features.orderbook.status,'CLOSED');assert.equal(r.features.funding.consensus,'SIGN_CONSENSUS');
});
test('future points are ignored and missing domains stay explicit',()=>{
 const r=buildEarlyFeatureFusion({now_ts:NOW,price_series:[{ts:NOW-1000,price:100,open:99,high:101,low:98,close:100},{ts:NOW+1000,price:1000,open:1000,high:1000,low:1000,close:1000}]});
 assert.equal(r.features.price.current_price,100);assert.equal(r.features.oi.status,'NO_DATA');assert.equal(r.features.orderflow.status,'NO_DATA');assert.equal(r.probability,null);
});
test('orderflow never claims CLOSED when trade coverage is incomplete',()=>{
 const r=buildEarlyFeatureFusion({now_ts:NOW,price_series:[{ts:NOW-300000,price:100,open:100,high:101,low:99,close:100},{ts:NOW,price:100,open:100,high:101,low:99,close:100}],orderflow_series:[{ts:NOW,taker_buy:80,taker_sell:100,delta:-20,cvd:-20,coverage_closed:false}]});
 assert.equal(r.features.orderflow.status,'PARTIAL');assert.equal(r.features.orderflow.aggressive_sell_without_price_decline,false);
});
