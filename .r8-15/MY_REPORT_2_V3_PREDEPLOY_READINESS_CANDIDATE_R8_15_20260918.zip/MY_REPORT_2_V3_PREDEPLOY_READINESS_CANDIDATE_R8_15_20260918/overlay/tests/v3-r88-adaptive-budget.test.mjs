import assert from 'node:assert/strict';
import {V3_EARLY_SIDECAR_BUDGET} from '../src/v3-early-sidecar.mjs';
import {V3_EARLY_MAX_PERSIST_CANDIDATES_PER_CYCLE} from '../src/v3-early-persistence-runtime.mjs';
import {R88_BURST_RESERVATION,buildR88BurstReservation,buildR88DailyAdmissionView,enforceR88RunBudget} from '../src/v3-adaptive-budget.mjs';

assert.equal(V3_EARLY_MAX_PERSIST_CANDIDATES_PER_CYCLE,1);
assert.equal(V3_EARLY_SIDECAR_BUDGET.rows_read,3072);
assert.equal(V3_EARLY_SIDECAR_BUDGET.rows_written,24);
assert.deepEqual(R88_BURST_RESERVATION,{rows_read:16000,rows_written:320});

const nominal={ok:true,status:'CLOSED',rows_read:12152,rows_written:243,daily_limits:{rows_read:3500000,rows_written:70000}};
const burst=buildR88BurstReservation(nominal);
assert.equal(burst.ok,true); assert.equal(burst.rows_written,320); assert.equal(burst.nominal_rows_written,243);
const daily={ok:true,status:'DAY_USAGE_CLOSED',run_count:50,reserved_rows_read:607600,reserved_rows_written:12150,measured_rows_read:174187,measured_rows_written:4511,unknown_ops:0,unfinished_count:3};
const view=buildR88DailyAdmissionView(daily,burst);
assert.equal(view.reserved_rows_written,4511+3*320);
assert.equal(view.raw_reserved_rows_written,12150);

// R8.7 live worst observed pre-sidecar write pressure: 187 writes.
// One bounded early candidate + Telegram/downstream reserve must fit the burst cap.
const measuredBeforeEarly={rows_read:2652,rows_written:187};
const downstream={rows_read:4500,rows_written:50};
assert.ok(measuredBeforeEarly.rows_read+V3_EARLY_SIDECAR_BUDGET.rows_read+downstream.rows_read<=burst.rows_read);
assert.ok(measuredBeforeEarly.rows_written+V3_EARLY_SIDECAR_BUDGET.rows_written+downstream.rows_written<=burst.rows_written);

const db={usageSnapshot(){return {rows_read:12000,rows_written:300,requests:40,unknown_ops:0,targets:{}};}};
const report=enforceR88RunBudget(db,{reservation:burst,dayAdmission:{allowed:true,status:'CLOSED'}});
assert.equal(report.run_headroom.rows_written,20);
assert.throws(()=>enforceR88RunBudget({usageSnapshot(){return {rows_read:1,rows_written:321,requests:1,unknown_ops:0,targets:{}};}},{reservation:burst,dayAdmission:{allowed:true,status:'CLOSED'}}),/BURST_CAP_EXCEEDED/);
console.log('R8_8_ADAPTIVE_D1_BUDGET=PASS');
