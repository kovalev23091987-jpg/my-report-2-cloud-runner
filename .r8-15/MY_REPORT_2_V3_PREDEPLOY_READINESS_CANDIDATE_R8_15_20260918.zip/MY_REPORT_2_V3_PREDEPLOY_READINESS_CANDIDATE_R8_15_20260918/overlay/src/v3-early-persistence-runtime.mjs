import { V3_EARLY_DISCOVERY_VERSION, earlyCandidatePersistenceRows } from './v3-early-discovery.mjs';

export const V3_EARLY_PERSISTENCE_VERSION = 'v3-early-persistence-shadow-v1';
export const V3_OUTCOME_HORIZONS_HOURS = Object.freeze([1,4,12,24]);
export const V3_EARLY_MAX_PERSIST_CANDIDATES_PER_CYCLE = 1;
export const V3_EARLY_MAX_D1_STATEMENTS_PER_CANDIDATE = 3;

function text(v){ return v==null?'':String(v).trim(); }
function finite(v){ if(v==null||v==='') return null; const n=Number(v); return Number.isFinite(n)?n:null; }
function json(v,fallback){ try{return JSON.stringify(v??fallback);}catch{return JSON.stringify(fallback);} }

export function buildOutcomeTasks(candidate){
  if(!candidate?.wave_id || !candidate?.contract_code || finite(candidate?.first_seen_ts)===null) return [];
  const first=Number(candidate.first_seen_ts);
  return V3_OUTCOME_HORIZONS_HOURS.map(h=>({
    outcome_id:`${candidate.wave_id}:H${h}`,
    wave_id:candidate.wave_id,
    contract_code:candidate.contract_code,
    direction_hint:['LONG','SHORT'].includes(candidate.direction_hint)?candidate.direction_hint:null,
    first_seen_ts:first,
    horizon_hours:h,
    target_ts:first+h*60*60*1000,
    outcome_status:'PENDING',
    rules_version:V3_EARLY_DISCOVERY_VERSION,
    first_seen_context:{
      first_seen_ts:first,
      first_seen_price:finite(candidate.first_seen_price),
      first_seen_oi:finite(candidate.first_seen_oi),
      first_seen_funding:finite(candidate.first_seen_funding),
      first_seen_detectors:Array.isArray(candidate.first_seen_detectors)?candidate.first_seen_detectors:[],
      move_before_first_seen:finite(candidate.move_before_first_seen),
      lifecycle_stage:text(candidate.lifecycle_stage)||'DISCOVERY',
    },
    decision_without_filter:null,
    decision_with_filter:null,
    entry_condition:null,
    invalidation:null,
    regime:null,
    liquidity_bucket:null,
    shadow_only:1,
  }));
}

export function decodeEarlyCandidateRow(row){
  if(!row || typeof row!=='object') return null;
  const parse=(x,fb)=>{try{return JSON.parse(String(x??''));}catch{return fb;}};
  return {
    ...row,
    first_seen_detectors:parse(row.first_seen_detectors_json,[]),
    first_seen_relative_strength_state:parse(row.first_seen_relative_strength_json,null),
    first_seen_volume_state:parse(row.first_seen_volume_json,null),
    first_seen_liquidation_state:parse(row.first_seen_liquidation_json,{status:'NOT_CHECKED'}),
    first_seen_orderflow_state:parse(row.first_seen_orderflow_json,{status:'NOT_CHECKED'}),
    remaining_edge:parse(row.remaining_edge_json,{}),
    evidence_refs:parse(row.evidence_refs_json,[]),
    shadow_only:true,
  };
}

export async function loadLatestEarlyCandidate(db, contract){
  if(!db?.prepare) return {status:'SOURCE_UNSUPPORTED',candidate:null};
  const c=text(contract); if(!c) return {status:'INVALID_INPUT',candidate:null};
  try{
    const row=await db.prepare(`SELECT * FROM v3_early_candidate_wave WHERE contract_code=?1 ORDER BY generation DESC, last_seen_ts DESC LIMIT 1`).bind(c).first();
    if(!row) return {status:'NOT_FOUND',candidate:null};
    return {status:'CLOSED',candidate:decodeEarlyCandidateRow(row)};
  }catch(error){
    return {status:/no such table/i.test(String(error?.message||error))?'MIGRATION_REQUIRED':'PARTIAL',candidate:null,error:String(error?.message||error)};
  }
}

export async function persistEarlyCandidateShadow(db,{observation,candidate,new_wave_opened=false,rules_version=V3_EARLY_DISCOVERY_VERSION}={}){
  if(!db?.prepare||!db?.batch) return {status:'SOURCE_UNSUPPORTED',statements:0};
  const rows=earlyCandidatePersistenceRows(observation,candidate,{rules_version});
  if(rows.status!=='CLOSED') return {status:'NOT_CLOSED',statements:0};
  const f=rows.feature,c=rows.candidate;
  const statements=[
    db.prepare(`INSERT INTO v3_early_feature_snapshot(
      contract_code,ts_bucket,observed_ts,rules_version,direction_hint,direction_state,
      long_evidence_domain_count,short_evidence_domain_count,early_detection_quality_0_100,
      feature_json,evidence_json,shadow_only)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,1)
      ON CONFLICT(contract_code,ts_bucket) DO UPDATE SET
       observed_ts=excluded.observed_ts,rules_version=excluded.rules_version,
       direction_hint=excluded.direction_hint,direction_state=excluded.direction_state,
       long_evidence_domain_count=excluded.long_evidence_domain_count,
       short_evidence_domain_count=excluded.short_evidence_domain_count,
       early_detection_quality_0_100=excluded.early_detection_quality_0_100,
       feature_json=excluded.feature_json,evidence_json=excluded.evidence_json,shadow_only=1`)
      .bind(f.contract_code,f.ts_bucket,f.observed_ts,f.rules_version,f.direction_hint,f.direction_state,
        f.long_evidence_domain_count,f.short_evidence_domain_count,f.early_detection_quality_0_100,f.feature_json,f.evidence_json),
    db.prepare(`INSERT INTO v3_early_candidate_wave(
      wave_id,contract_code,generation,first_seen_ts,first_seen_price,first_seen_oi,first_seen_funding,
      first_seen_detectors_json,first_seen_relative_strength_json,first_seen_volume_json,
      first_seen_liquidation_json,first_seen_orderflow_json,first_seen_execution_state,move_before_first_seen,
      lifecycle_stage,direction_hint,direction_state,support_streak,move_since_first_seen,
      oi_change_since_first_seen,elapsed_since_first_seen_sec,early_detection_quality_0_100,
      remaining_edge_json,evidence_refs_json,last_seen_ts,shadow_only)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22,?23,?24,?25,1)
      ON CONFLICT(wave_id) DO UPDATE SET
       lifecycle_stage=excluded.lifecycle_stage,direction_hint=excluded.direction_hint,
       direction_state=excluded.direction_state,support_streak=excluded.support_streak,
       move_since_first_seen=excluded.move_since_first_seen,
       oi_change_since_first_seen=excluded.oi_change_since_first_seen,
       elapsed_since_first_seen_sec=excluded.elapsed_since_first_seen_sec,
       early_detection_quality_0_100=excluded.early_detection_quality_0_100,
       remaining_edge_json=excluded.remaining_edge_json,evidence_refs_json=excluded.evidence_refs_json,
       last_seen_ts=excluded.last_seen_ts,shadow_only=1`)
      .bind(c.wave_id,c.contract_code,c.generation,c.first_seen_ts,c.first_seen_price,c.first_seen_oi,c.first_seen_funding,
        c.first_seen_detectors_json,c.first_seen_relative_strength_json,c.first_seen_volume_json,
        c.first_seen_liquidation_json,c.first_seen_orderflow_json,c.first_seen_execution_state,c.move_before_first_seen,
        c.lifecycle_stage,c.direction_hint,c.direction_state,c.support_streak,c.move_since_first_seen,
        c.oi_change_since_first_seen,c.elapsed_since_first_seen_sec,c.early_detection_quality_0_100,
        c.remaining_edge_json,c.evidence_refs_json,c.last_seen_ts),
  ];
  if(new_wave_opened===true){
    const tasks=buildOutcomeTasks(candidate);
    if(tasks.length){
      statements.push(db.prepare(`INSERT OR IGNORE INTO v3_early_outcome_journal(
        outcome_id,wave_id,contract_code,direction_hint,first_seen_ts,horizon_hours,target_ts,outcome_status,
        rules_version,decision_without_filter_json,decision_with_filter_json,first_seen_context_json,
        entry_condition_json,invalidation_json,regime,liquidity_bucket,shadow_only)
        VALUES
        (?1,?2,?3,?4,?5,?6,?7,'PENDING',?8,?9,?10,?11,?12,?13,?14,?15,1),
        (?16,?17,?18,?19,?20,?21,?22,'PENDING',?23,?24,?25,?26,?27,?28,?29,?30,1),
        (?31,?32,?33,?34,?35,?36,?37,'PENDING',?38,?39,?40,?41,?42,?43,?44,?45,1),
        (?46,?47,?48,?49,?50,?51,?52,'PENDING',?53,?54,?55,?56,?57,?58,?59,?60,1)`)
        .bind(...tasks.flatMap(t=>[
          t.outcome_id,t.wave_id,t.contract_code,t.direction_hint,t.first_seen_ts,t.horizon_hours,t.target_ts,
          t.rules_version,json(t.decision_without_filter,null),json(t.decision_with_filter,null),json(t.first_seen_context,{}),
          json(t.entry_condition,null),json(t.invalidation,null),t.regime,t.liquidity_bucket
        ])));
    }
  }
  if(statements.length>V3_EARLY_MAX_D1_STATEMENTS_PER_CANDIDATE) throw new Error('V3_EARLY_D1_STATEMENT_CAP_EXCEEDED');
  try{
    const result=await db.batch(statements);
    return {status:'CLOSED',statements:statements.length,acks:(Array.isArray(result)?result:[]).map(r=>Number(r?.meta?.changes??r?.changes??0)),shadow_only:true};
  }catch(error){
    return {status:/no such table/i.test(String(error?.message||error))?'MIGRATION_REQUIRED':'PARTIAL',statements:statements.length,error:String(error?.message||error),shadow_only:true};
  }
}

export function resolveEarlyOutcome({task,first_seen_price,price_path=[],computed_ts=Date.now()}={}){
  const first=finite(first_seen_price);
  if(!task||first===null||first<=0) return {status:'NOT_CLOSED',reason:'FIRST_SEEN_PRICE_MISSING'};
  const rows=(Array.isArray(price_path)?price_path:[]).map(r=>({ts:finite(r?.ts),price:finite(r?.price)})).filter(r=>r.ts!==null&&r.price!==null&&r.price>0&&r.ts<=Number(task.target_ts)).sort((a,b)=>a.ts-b.ts);
  if(!rows.length || rows.at(-1).ts < Number(task.target_ts)-15*60_000) return {status:'INSUFFICIENT',reason:'TARGET_PRICE_NOT_COVERED'};
  const rets=rows.map(r=>((r.price/first)-1)*100);
  const raw=rets.at(-1);
  const dir=task.direction_hint==='SHORT'?-raw:task.direction_hint==='LONG'?raw:null;
  const directionalSeries=task.direction_hint==='SHORT'?rets.map(x=>-x):task.direction_hint==='LONG'?rets:null;
  return {
    status:'CLOSED',
    outcome:{
      outcome_id:task.outcome_id,
      outcome_status:'CLOSED',
      raw_return_pct:raw,
      directional_return_pct:dir,
      mfe_pct:directionalSeries?Math.max(...directionalSeries):null,
      mae_pct:directionalSeries?Math.min(...directionalSeries):null,
      computed_ts:Number(computed_ts),
      probability:null,
      validated_signal:false,
      shadow_only:true,
    }
  };
}
