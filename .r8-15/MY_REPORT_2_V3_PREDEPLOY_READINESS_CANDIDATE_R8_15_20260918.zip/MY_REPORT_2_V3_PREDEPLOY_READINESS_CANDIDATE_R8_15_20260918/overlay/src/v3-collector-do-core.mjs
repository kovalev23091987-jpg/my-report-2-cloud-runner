import {
  buildCollectorPlan,
  buildCollectorSubscribeFrames,
  createCollectorHealth,
  collectorHealthTransition,
  normalizeCollectorMessage,
  reconnectDelayMs,
  assessEnduranceProof,
} from './v3-collector-runtime.mjs';

export const V3_DO_PROBE_VERSION='v3-liquidation-do-bounded-probe-v1';
export const V3_DO_PROBE_MAX_RUNTIME_MS=12*60_000;
export const V3_DO_PROBE_MIN_RUNTIME_MS=30_000;

function text(v){return v==null?'':String(v).trim();}
function finite(v){if(v==null||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null;}
function upper(v){return text(v).toUpperCase();}

export function buildDurableCollectorProbeConfig({
  venue,htx_contracts=[],identity_by_contract={},source_url_override=null,websocket_header_capable=false,
  requested_runtime_ms=5*60_000,now_ts=Date.now(),gate_multiplier_by_symbol={},
}={}){
  const runtime=Math.trunc(finite(requested_runtime_ms)??0);
  if(runtime<V3_DO_PROBE_MIN_RUNTIME_MS) return {status:'PROBE_DURATION_TOO_SHORT',production_enabled:false};
  if(runtime>V3_DO_PROBE_MAX_RUNTIME_MS) return {status:'PROBE_DURATION_EXCEEDS_BOUND',max_runtime_ms:V3_DO_PROBE_MAX_RUNTIME_MS,production_enabled:false};
  const plan=buildCollectorPlan({venue,htx_contracts,identity_by_contract,source_url_override,websocket_header_capable});
  if(!['CLOSED','PARTIAL'].includes(plan?.status)) return {...plan,probe_status:'NOT_CLOSED',production_enabled:false};
  if(plan.venue==='GATE' && plan.size_precision_status!=='CLOSED'){
    return {...plan,status:'GATE_DECIMAL_HEADER_REQUIRED',probe_status:'NOT_CLOSED',production_enabled:false};
  }
  const started=Math.trunc(finite(now_ts)??Date.now());
  const bySymbol={};
  for(const identity of Object.values(identity_by_contract||{})){
    if(identity?.identity_status==='CLOSED' && upper(identity?.venue)===plan.venue && text(identity?.venue_symbol)) bySymbol[upper(identity.venue_symbol)]=identity;
  }
  return {
    version:V3_DO_PROBE_VERSION,status:plan.status,probe_status:'READY',plan,
    started_ts:started,stop_ts:started+runtime,requested_runtime_ms:runtime,
    identity_by_symbol:bySymbol,gate_multiplier_by_symbol:{...(gate_multiplier_by_symbol||{})},
    production_enabled:false,continuous_mode:false,shadow_only:true,
  };
}

function splitFrameBySymbol(venue,message){
  const v=upper(venue), msg=message&&typeof message==='object'?message:{};
  if(v==='BYBIT'){
    const groups=new Map();
    for(const row of Array.isArray(msg.data)?msg.data:[]){const s=upper(row?.s);if(!s)continue;if(!groups.has(s))groups.set(s,[]);groups.get(s).push(row);}
    return [...groups.entries()].map(([symbol,data])=>({symbol,message:{...msg,data}}));
  }
  if(v==='GATE'){
    const groups=new Map();
    for(const row of Array.isArray(msg.result)?msg.result:[]){const s=upper(row?.contract);if(!s)continue;if(!groups.has(s))groups.set(s,[]);groups.get(s).push(row);}
    return [...groups.entries()].map(([symbol,result])=>({symbol,message:{...msg,result}}));
  }
  if(v==='BINANCE'){
    const payload=msg?.data&&typeof msg.data==='object'?msg.data:msg;
    const symbol=upper(payload?.o?.s);
    return symbol?[{symbol,message:payload}]:[];
  }
  return [];
}

export function normalizeDurableCollectorFrame({config,message,received_ts=Date.now()}={}){
  const venue=upper(config?.plan?.venue), identities=config?.identity_by_symbol||{};
  const chunks=splitFrameBySymbol(venue,message);
  if(!chunks.length) return {status:'SOURCE_SCHEMA_UNVERIFIED',events:[],errors:['NO_SYMBOL_ROWS'],normalized_count:0,dropped_count:1};
  const events=[],errors=[];
  let dropped=0;
  for(const chunk of chunks){
    const identity=identities[chunk.symbol];
    if(!identity){errors.push(`IDENTITY_UNRESOLVED:${chunk.symbol}`);dropped+=1;continue;}
    const mult=config?.gate_multiplier_by_symbol?.[chunk.symbol] ?? identity?.multiplier ?? null;
    const out=normalizeCollectorMessage({venue,message:chunk.message,identity,received_ts,gate_multiplier:mult,gate_decimal_header_closed:venue!=='GATE'||config?.plan?.size_precision_status==='CLOSED'});
    events.push(...(out?.events||[]));errors.push(...(out?.errors||[]));
    if(!Array.isArray(out?.events)||out.events.length===0)dropped+=1;
  }
  return {status:events.length?(errors.length?'PARTIAL':'CLOSED'):'NOT_CLOSED',events,errors,normalized_count:events.length,dropped_count:dropped};
}

export function initialDurableProbeState(config){
  return {version:V3_DO_PROBE_VERSION,status:'READY',venue:config?.plan?.venue||null,started_ts:config?.started_ts??null,stop_ts:config?.stop_ts??null,
    reconnect_attempt:0,next_action:'CONNECT',next_action_ts:config?.started_ts??null,health:createCollectorHealth({venue:config?.plan?.venue,now_ts:config?.started_ts}),
    probe_result:null,production_enabled:false,shadow_only:true};
}

export function durableProbeTransition(state,event={}){
  const s={...(state||{})}, type=upper(event?.type), now=Math.trunc(finite(event?.now_ts)??Date.now());
  if(type==='CONNECTED'){
    s.health=collectorHealthTransition(s.health,{type:s.reconnect_attempt>0?'RECONNECTED':'CONNECTED',now_ts:now});
    s.status='RUNNING';s.next_action='STOP';s.next_action_ts=s.stop_ts;s.reconnect_attempt=Math.max(0,Number(s.reconnect_attempt||0));
  }else if(type==='MESSAGE'){
    s.health=collectorHealthTransition(s.health,{type:'MESSAGE',now_ts:now,exchange_ts:event.exchange_ts,normalized_events:event.normalized_events,dropped:event.dropped,parse_errors:event.parse_errors,schema_errors:event.schema_errors,identity_errors:event.identity_errors});
  }else if(type==='ERROR'){
    s.health=collectorHealthTransition(s.health,{type:'ERROR',now_ts:now,error:event.error,parse_error:event.parse_error,schema_error:event.schema_error,identity_error:event.identity_error,rate_limit:event.rate_limit});
  }else if(type==='DISCONNECTED'){
    s.health=collectorHealthTransition(s.health,{type:'DISCONNECTED',now_ts:now,error:event.error});
    if(now>=Number(s.stop_ts||0)){s.status='STOPPING';s.next_action='STOP';s.next_action_ts=now;}
    else {s.reconnect_attempt=Math.min(20,Number(s.reconnect_attempt||0)+1);s.status='RECONNECT_WAIT';s.next_action='RECONNECT';s.next_action_ts=Math.min(Number(s.stop_ts),now+reconnectDelayMs(s.reconnect_attempt,{base_ms:1000,max_ms:30_000}));}
  }else if(type==='STOP'){
    s.status='STOPPED';s.next_action='NONE';s.next_action_ts=null;
    s.probe_result=assessEnduranceProof({health:s.health,started_ts:s.started_ts,completed_ts:now,required_duration_ms:Math.max(1,Number(s.stop_ts||now)-Number(s.started_ts||now)),min_messages:Number(event.min_messages??1),max_reconnects:Number(event.max_reconnects??12),max_event_gap_ms:Number(event.max_event_gap_ms??60_000)});
  }
  return s;
}

export function buildProbeSubscribeFrames(config){return buildCollectorSubscribeFrames(config?.plan||{});}
