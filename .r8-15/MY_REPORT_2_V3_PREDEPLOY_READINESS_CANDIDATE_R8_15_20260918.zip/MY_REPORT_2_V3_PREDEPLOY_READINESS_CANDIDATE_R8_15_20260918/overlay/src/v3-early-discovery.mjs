import { buildEarlyFeatureFusion } from './v3-early-feature-fusion.mjs';
export const V3_EARLY_DISCOVERY_VERSION = "v3-early-discovery-shadow-v1";
export const V3_EARLY_MODE = "SHADOW_ONLY_NO_FINAL_DECISION";

const HORIZON_MS = Object.freeze({
  "5m": 5 * 60_000,
  "15m": 15 * 60_000,
  "1h": 60 * 60_000,
  "4h": 4 * 60 * 60_000,
  "12h": 12 * 60 * 60_000,
  "24h": 24 * 60 * 60_000,
});

const EARLY_STAGES = new Set(["DISCOVERY", "PRE_IMPULSE_WATCH"]);
const DOWNSTREAM_STAGES = new Set([
  "ENTRY_CANDIDATE", "ENTRY_TRIGGER", "IMPULSE", "RELOAD_BASE", "RELOAD_WATCH",
  "EXIT_CANDIDATE", "EXIT", "EDGE_SPENT", "EXCLUDE",
]);

function finite(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function text(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

function pct(now, prior) {
  const a = finite(now), b = finite(prior);
  if (a === null || b === null || b === 0) return null;
  return ((a / b) - 1) * 100;
}

function median(values) {
  const a = values.filter(Number.isFinite).slice().sort((x, y) => x - y);
  if (!a.length) return null;
  const mid = Math.floor(a.length / 2);
  return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
}

function percentileRank(values, value) {
  const v = finite(value);
  const a = values.filter(Number.isFinite).slice().sort((x, y) => x - y);
  if (v === null || !a.length) return null;
  let less = 0, equal = 0;
  for (const x of a) {
    if (x < v) less += 1;
    else if (x === v) equal += 1;
  }
  return (less + 0.5 * equal) / a.length;
}

export function robustNormalize(value, history, { min_points = 12 } = {}) {
  const v = finite(value);
  const clean = Array.isArray(history) ? history.map(finite).filter(Number.isFinite) : [];
  if (v === null || clean.length < min_points) {
    return {
      status: "INSUFFICIENT_HISTORY",
      value: v,
      sample_size: clean.length,
      median: null,
      mad: null,
      robust_z: null,
      percentile: null,
    };
  }
  const med = median(clean);
  const mad = median(clean.map((x) => Math.abs(x - med)));
  const z = mad && mad > 0 ? (v - med) / (1.4826 * mad) : null;
  return {
    status: "CLOSED",
    value: v,
    sample_size: clean.length,
    median: med,
    mad,
    robust_z: z,
    percentile: percentileRank(clean, v),
  };
}

export function parseStage0CompactPayload(payload, fallbackTs = null) {
  let obj = payload;
  if (typeof payload === "string") {
    try { obj = JSON.parse(payload); }
    catch { return { status: "PAYLOAD_INVALID", ts: null, rows: new Map() }; }
  }
  if (!obj || obj.schema !== "stage0-compact-v2" || !Array.isArray(obj.contracts)) {
    return { status: "PAYLOAD_UNSUPPORTED", ts: finite(obj?.timestamp ?? fallbackTs), rows: new Map() };
  }
  const ts = finite(obj.timestamp ?? fallbackTs);
  const rows = new Map();
  for (const raw of obj.contracts) {
    if (!Array.isArray(raw) || raw.length < 9) continue;
    const [contract, price, turnover, oiContracts, oiValue, fundingRate, fundingIntervalHours,
      marketAgeSec, dataStatus, longWatch = null, shortWatch = null, longTriggerCount = 0, shortTriggerCount = 0] = raw;
    const c = text(contract);
    if (!c) continue;
    rows.set(c, {
      ts,
      contract: c,
      price: finite(price),
      turnover_24h_usdt: finite(turnover),
      oi_contracts: finite(oiContracts),
      oi_value_usdt: finite(oiValue),
      funding_rate: finite(fundingRate),
      funding_interval_hours: finite(fundingIntervalHours),
      market_age_sec: finite(marketAgeSec),
      data_status: text(dataStatus),
      prior_discovery: {
        long_watch: longWatch === true,
        short_watch: shortWatch === true,
        long_trigger_count: Number.isFinite(Number(longTriggerCount)) ? Number(longTriggerCount) : 0,
        short_trigger_count: Number.isFinite(Number(shortTriggerCount)) ? Number(shortTriggerCount) : 0,
      },
    });
  }
  return { status: "CLOSED", ts, rows };
}

function normalizeSnapshots(snapshots) {
  const out = [];
  for (const raw of Array.isArray(snapshots) ? snapshots : []) {
    const parsed = raw?.rows instanceof Map
      ? raw
      : parseStage0CompactPayload(raw?.payload_json ?? raw?.payload ?? raw, raw?.ts ?? null);
    if (parsed.status !== "CLOSED" || finite(parsed.ts) === null) continue;
    out.push(parsed);
  }
  return out.sort((a, b) => a.ts - b.ts);
}

function contractPoint(parsed, contract) {
  const row = parsed?.rows?.get(contract);
  if (!row) return null;
  if (row.data_status !== "CLOSED" || row.market_age_sec === null || row.market_age_sec > 300) return null;
  if (row.price === null || row.price <= 0) return null;
  return row;
}

function nearestAtOrBefore(points, targetTs, { max_lag_ms = 12 * 60_000 } = {}) {
  let best = null;
  for (const p of points) {
    if (p.ts > targetTs) break;
    if (!best || p.ts > best.ts) best = p;
  }
  if (!best) return null;
  return targetTs - best.ts <= max_lag_ms ? best : null;
}

function pointSeries(parsedSnapshots, contract) {
  const points = [];
  for (const snap of parsedSnapshots) {
    const row = contractPoint(snap, contract);
    if (row) points.push(row);
  }
  return points;
}

function deltaBetween(current, prior) {
  if (!current || !prior) {
    return {
      available: false,
      price_change_pct: null,
      oi_change_pct: null,
      funding_change_pct_points: null,
      turnover_24h_change_pct_proxy: null,
    };
  }
  const fundingDelta = current.funding_rate !== null && prior.funding_rate !== null
    ? (current.funding_rate - prior.funding_rate) * 100
    : null;
  return {
    available: true,
    reference_ts: prior.ts,
    price_change_pct: pct(current.price, prior.price),
    oi_change_pct: pct(current.oi_contracts, prior.oi_contracts),
    funding_change_pct_points: fundingDelta,
    turnover_24h_change_pct_proxy: pct(current.turnover_24h_usdt, prior.turnover_24h_usdt),
  };
}

function consecutiveFiveMinuteDeltas(points) {
  const out = { price: [], oi: [], funding: [], turnover: [], rs_btc: [], rs_eth: [] };
  for (let i = 1; i < points.length; i += 1) {
    const a = points[i - 1], b = points[i];
    const gap = b.ts - a.ts;
    if (gap < 3 * 60_000 || gap > 12 * 60_000) continue;
    const d = deltaBetween(b, a);
    if (d.price_change_pct !== null) out.price.push(d.price_change_pct);
    if (d.oi_change_pct !== null) out.oi.push(d.oi_change_pct);
    if (d.funding_change_pct_points !== null) out.funding.push(d.funding_change_pct_points);
    if (d.turnover_24h_change_pct_proxy !== null) out.turnover.push(d.turnover_24h_change_pct_proxy);
  }
  return out;
}

function benchmarkMove(parsedSnapshots, contract, currentTs, horizonMs) {
  const points = pointSeries(parsedSnapshots, contract);
  const current = nearestAtOrBefore(points, currentTs, { max_lag_ms: 7 * 60_000 });
  const prior = nearestAtOrBefore(points, currentTs - horizonMs, { max_lag_ms: 12 * 60_000 });
  return current && prior ? pct(current.price, prior.price) : null;
}

function evidenceRow(domain, side, status, details = {}) {
  return { domain, side, status, ...details };
}

function normalizedHigh(norm, sign = 1) {
  if (!norm || norm.status !== "CLOSED") return false;
  if (sign > 0) return (norm.percentile !== null && norm.percentile >= 0.80) || (norm.robust_z !== null && norm.robust_z >= 1.0);
  return (norm.percentile !== null && norm.percentile <= 0.20) || (norm.robust_z !== null && norm.robust_z <= -1.0);
}

export function buildEarlyObservation({
  contract,
  snapshots,
  now_ts = Date.now(),
  liquidation_context = null,
  orderflow_context = null,
  feature_fusion = null,
  feature_inputs = null,
} = {}) {
  const c = text(contract);
  const now = finite(now_ts) ?? Date.now();
  const parsed = normalizeSnapshots(snapshots).filter((s) => s.ts <= now);
  const points = pointSeries(parsed, c);
  const current = nearestAtOrBefore(points, now, { max_lag_ms: 7 * 60_000 });
  if (!c || !current) {
    return {
      version: V3_EARLY_DISCOVERY_VERSION,
      mode: V3_EARLY_MODE,
      status: "CURRENT_FACTUAL_SNAPSHOT_NOT_CLOSED",
      contract: c || null,
      direction_hint: null,
      final_entry: false,
      probability: null,
      shadow_only: true,
    };
  }

  const windows = {};
  for (const [label, ms] of Object.entries(HORIZON_MS)) {
    const prior = nearestAtOrBefore(points, current.ts - ms, { max_lag_ms: label === "5m" ? 7 * 60_000 : 15 * 60_000 });
    windows[label] = deltaBetween(current, prior);
  }

  const hist = consecutiveFiveMinuteDeltas(points.filter((p) => p.ts < current.ts));
  const norm = {
    price_5m: robustNormalize(windows["5m"].price_change_pct, hist.price),
    oi_5m: robustNormalize(windows["5m"].oi_change_pct, hist.oi),
    funding_5m: robustNormalize(windows["5m"].funding_change_pct_points, hist.funding),
    turnover_5m_proxy: robustNormalize(windows["5m"].turnover_24h_change_pct_proxy, hist.turnover),
  };

  const btc1h = benchmarkMove(parsed, "BTC-USDT", current.ts, HORIZON_MS["1h"]);
  const eth1h = benchmarkMove(parsed, "ETH-USDT", current.ts, HORIZON_MS["1h"]);
  const btc4h = benchmarkMove(parsed, "BTC-USDT", current.ts, HORIZON_MS["4h"]);
  const eth4h = benchmarkMove(parsed, "ETH-USDT", current.ts, HORIZON_MS["4h"]);
  const rs = {
    btc_1h_pct_points: windows["1h"].price_change_pct !== null && btc1h !== null ? windows["1h"].price_change_pct - btc1h : null,
    eth_1h_pct_points: windows["1h"].price_change_pct !== null && eth1h !== null ? windows["1h"].price_change_pct - eth1h : null,
    btc_4h_pct_points: windows["4h"].price_change_pct !== null && btc4h !== null ? windows["4h"].price_change_pct - btc4h : null,
    eth_4h_pct_points: windows["4h"].price_change_pct !== null && eth4h !== null ? windows["4h"].price_change_pct - eth4h : null,
  };

  const evidence = [];
  const oiPositive = windows["5m"].oi_change_pct !== null && windows["5m"].oi_change_pct > 0 && normalizedHigh(norm.oi_5m, +1);
  if (oiPositive) {
    evidence.push(evidenceRow("OI_ACCELERATION", "BOTH", "CLOSED", { self_percentile: norm.oi_5m.percentile, robust_z: norm.oi_5m.robust_z }));
  }

  const fundingLong = current.funding_rate !== null && current.funding_rate < 0 && windows["1h"].funding_change_pct_points !== null && windows["1h"].funding_change_pct_points < 0;
  const fundingShort = current.funding_rate !== null && current.funding_rate > 0 && windows["1h"].funding_change_pct_points !== null && windows["1h"].funding_change_pct_points > 0;
  if (fundingLong) evidence.push(evidenceRow("FUNDING_TRAJECTORY", "LONG", "CLOSED", { current_rate: current.funding_rate, delta_1h_pct_points: windows["1h"].funding_change_pct_points }));
  if (fundingShort) evidence.push(evidenceRow("FUNDING_TRAJECTORY", "SHORT", "CLOSED", { current_rate: current.funding_rate, delta_1h_pct_points: windows["1h"].funding_change_pct_points }));

  const availableRs1h = [rs.btc_1h_pct_points, rs.eth_1h_pct_points].filter(Number.isFinite);
  const availableRs4h = [rs.btc_4h_pct_points, rs.eth_4h_pct_points].filter(Number.isFinite);
  const rsLong = (availableRs1h.length > 0 && availableRs1h.every((v) => v > 0)) || (availableRs4h.length > 0 && availableRs4h.every((v) => v > 0));
  const rsShort = (availableRs1h.length > 0 && availableRs1h.every((v) => v < 0)) || (availableRs4h.length > 0 && availableRs4h.every((v) => v < 0));
  if (rsLong) evidence.push(evidenceRow("RELATIVE_STRENGTH", "LONG", "CLOSED", rs));
  if (rsShort) evidence.push(evidenceRow("RELATIVE_STRENGTH", "SHORT", "CLOSED", rs));

  const volumeAccel = windows["5m"].turnover_24h_change_pct_proxy !== null && windows["5m"].turnover_24h_change_pct_proxy > 0 && normalizedHigh(norm.turnover_5m_proxy, +1);
  if (volumeAccel) evidence.push(evidenceRow("VOLUME_ACCELERATION_PROXY", "BOTH", "CLOSED", { self_percentile: norm.turnover_5m_proxy.percentile, proxy_note: "rolling_24h_turnover_change_not_interval_volume" }));

  if (orderflow_context?.coverage_closed === true) {
    if (orderflow_context?.aggressive_sell_without_price_decline === true) evidence.push(evidenceRow("ORDERFLOW_ABSORPTION", "LONG", "CLOSED"));
    if (orderflow_context?.aggressive_buy_without_price_progress === true) evidence.push(evidenceRow("ORDERFLOW_EXHAUSTION", "SHORT", "CLOSED"));
  }

  if (liquidation_context?.realized_coverage_closed === true) {
    if (liquidation_context?.short_burst === true) evidence.push(evidenceRow("REALIZED_LIQUIDATION_PRESSURE", "LONG", "CLOSED", { realized_only: true }));
    if (liquidation_context?.long_burst === true) evidence.push(evidenceRow("REALIZED_LIQUIDATION_PRESSURE", "SHORT", "CLOSED", { realized_only: true }));
  }

  const fusion = feature_fusion?.version ? feature_fusion : (feature_inputs ? buildEarlyFeatureFusion({ now_ts: current.ts, ...feature_inputs }) : null);
  if (fusion?.status === 'CLOSED') {
    const ff=fusion.features||{};
    const p5=ff.price?.windows?.['5m']?.change_pct??null;
    const pacc=ff.price?.acceleration_5m_vs_15m_pct_per_min??null;
    if (ff.price?.breakout_attempt===true || (p5!==null&&pacc!==null&&p5>0&&pacc>0)) evidence.push(evidenceRow('PRICE_STATE_TRANSITION','LONG','CLOSED',{breakout_attempt:ff.price.breakout_attempt===true,acceleration:pacc}));
    if (ff.price?.failure===true || (p5!==null&&pacc!==null&&p5<0&&pacc<0)) evidence.push(evidenceRow('PRICE_STATE_TRANSITION','SHORT','CLOSED',{failure:ff.price.failure===true,acceleration:pacc}));

    const vol=ff.volume||{};
    const volHot=vol.relative_volume?.status==='CLOSED'&&((vol.relative_volume.percentile??0)>=0.8||(vol.relative_volume.robust_z??0)>=1);
    if(volHot && (vol.volume_acceleration_vs_recent15m??0)>1) evidence.push(evidenceRow('VOLUME_ACCELERATION','BOTH','CLOSED',{percentile:vol.relative_volume.percentile,acceleration_ratio:vol.volume_acceleration_vs_recent15m,trade_count_percentile:vol.relative_trade_count?.percentile??null}));

    const of=ff.orderflow||{};
    if(of.status==='CLOSED'&&of.absorption===true){
      if(of.delta<0) evidence.push(evidenceRow('ORDERFLOW_ABSORPTION','LONG','CLOSED',{delta:of.delta,cvd_change:of.cvd_change}));
      if(of.delta>0) evidence.push(evidenceRow('ORDERFLOW_ABSORPTION','SHORT','CLOSED',{delta:of.delta,cvd_change:of.cvd_change}));
    }
    if(of.status==='CLOSED'&&of.exhaustion===true){
      if((of.cvd_change??0)>0) evidence.push(evidenceRow('ORDERFLOW_EXHAUSTION','SHORT','CLOSED',{cvd_change:of.cvd_change}));
      if((of.cvd_change??0)<0) evidence.push(evidenceRow('ORDERFLOW_EXHAUSTION','LONG','CLOSED',{cvd_change:of.cvd_change}));
    }

    const rel=ff.relative_strength||{};
    const relLong=[rel.btc_1h_pct_points,rel.eth_1h_pct_points].filter(Number.isFinite);
    const relShort=relLong;
    if(rel.status==='CLOSED'&&((relLong.length&&relLong.every(v=>v>0))||rel.down_market_resilience===true)) evidence.push(evidenceRow('RELATIVE_STRENGTH','LONG','CLOSED',rel));
    if(rel.status==='CLOSED'&&relShort.length&&relShort.every(v=>v<0)) evidence.push(evidenceRow('RELATIVE_STRENGTH','SHORT','CLOSED',rel));

    const book=ff.orderbook||{};
    if(book.status==='CLOSED'&&Number.isFinite(book.imbalance)){
      if(book.imbalance>=0.15) evidence.push(evidenceRow('EXECUTION_BOOK_SUPPORT','LONG','CLOSED',{imbalance:book.imbalance,spread_pct:book.spread_pct,slippage_buy_bps:book.slippage_buy_bps}));
      if(book.imbalance<=-0.15) evidence.push(evidenceRow('EXECUTION_BOOK_SUPPORT','SHORT','CLOSED',{imbalance:book.imbalance,spread_pct:book.spread_pct,slippage_sell_bps:book.slippage_sell_bps}));
    }

    const pos=ff.positioning||{};
    if(pos.status==='CLOSED'){
      if(pos.account_trajectory_consensus==='RISING_CONSENSUS'&&pos.position_trajectory_consensus==='RISING_CONSENSUS') evidence.push(evidenceRow('POSITIONING_TRAJECTORY','LONG','CLOSED',{account_delta:pos.median_account_delta,position_delta:pos.median_position_delta}));
      if(pos.account_trajectory_consensus==='FALLING_CONSENSUS'&&pos.position_trajectory_consensus==='FALLING_CONSENSUS') evidence.push(evidenceRow('POSITIONING_TRAJECTORY','SHORT','CLOSED',{account_delta:pos.median_account_delta,position_delta:pos.median_position_delta}));
    }

    const liq=ff.liquidation||{};
    if(liq.status==='CLOSED'&&Number.isFinite(liq.long_short_imbalance)){
      if(liq.long_short_imbalance<0&&((liq.burst_velocity??0)>0)) evidence.push(evidenceRow('REALIZED_LIQUIDATION_PRESSURE','LONG','CLOSED',{imbalance:liq.long_short_imbalance,burst_velocity:liq.burst_velocity}));
      if(liq.long_short_imbalance>0&&((liq.burst_velocity??0)>0)) evidence.push(evidenceRow('REALIZED_LIQUIDATION_PRESSURE','SHORT','CLOSED',{imbalance:liq.long_short_imbalance,burst_velocity:liq.burst_velocity}));
    }

    if(ff.basis?.status==='CLOSED'&&Number.isFinite(ff.basis.dislocation_abs_pct)) evidence.push(evidenceRow('BASIS_CONTEXT','CONTEXT','CLOSED',{basis_pct:ff.basis.basis_pct,convergence:ff.basis.convergence,divergence:ff.basis.divergence}));
  }

  const uniqueDomains = (side) => [...new Set(evidence.filter((e) => e.side === side || e.side === "BOTH").map((e) => e.domain))];
  const longDomains = uniqueDomains("LONG");
  const shortDomains = uniqueDomains("SHORT");
  const longReady = longDomains.length >= 3;
  const shortReady = shortDomains.length >= 3;
  const directionHint = longReady && !shortReady ? "LONG" : shortReady && !longReady ? "SHORT" : null;
  const directionState = longReady && shortReady ? "BIDIRECTIONAL_REQUIRES_DEEP_RESOLUTION" : directionHint ? `${directionHint}_WATCH` : "DIRECTION_NOT_CLOSED";

  const requiredCurrentFields = [current.price, current.oi_contracts, current.funding_rate, current.turnover_24h_usdt];
  const dataCoverage = requiredCurrentFields.filter((v) => v !== null).length / requiredCurrentFields.length;
  const maxDomains = Math.max(longDomains.length, shortDomains.length);
  const quality = Math.round(100 * (0.55 * dataCoverage + 0.45 * Math.min(1, maxDomains / 5)));

  const price15 = windows["15m"].price_change_pct;
  const price5 = windows["5m"].price_change_pct;
  const oi15 = windows["15m"].oi_change_pct;
  const oi5 = windows["5m"].oi_change_pct;
  const acceleration = {
    price_pct_per_min_delta: price5 !== null && price15 !== null ? (price5 / 5) - (price15 / 15) : null,
    oi_pct_per_min_delta: oi5 !== null && oi15 !== null ? (oi5 / 5) - (oi15 / 15) : null,
  };

  return {
    version: V3_EARLY_DISCOVERY_VERSION,
    mode: V3_EARLY_MODE,
    status: "CLOSED",
    contract: c,
    observation_ts: current.ts,
    current: {
      price: current.price,
      oi_contracts: current.oi_contracts,
      oi_value_usdt: current.oi_value_usdt,
      funding_rate: current.funding_rate,
      funding_interval_hours: current.funding_interval_hours,
      turnover_24h_usdt: current.turnover_24h_usdt,
    },
    windows,
    acceleration,
    self_normalized: norm,
    relative_strength: rs,
    feature_fusion: fusion,
    evidence,
    context_status: {
      liquidation: liquidation_context ? (liquidation_context.realized_coverage_closed === true ? "CLOSED" : "PARTIAL") : "NOT_CHECKED",
      orderflow: orderflow_context ? (orderflow_context.coverage_closed === true ? "CLOSED" : "PARTIAL") : "NOT_CHECKED",
      execution: fusion?.features?.orderbook?.status ?? "NOT_EVALUATED",
      feature_fusion: fusion?.status ?? "NOT_CHECKED",
    },
    long_evidence_domains: longDomains,
    short_evidence_domains: shortDomains,
    long_evidence_domain_count: longDomains.length,
    short_evidence_domain_count: shortDomains.length,
    direction_hint: directionHint,
    direction_state: directionState,
    early_detection_quality_0_100: quality,
    early_detection_quality_semantics: "SHADOW_TELEMETRY_NOT_PROBABILITY_NOT_FINAL_SCORE",
    final_entry: false,
    probability: null,
    validated_signal: false,
    trading_execution: false,
    shadow_only: true,
    no_lookahead: true,
  };
}

function waveId(contract, firstSeenTs, generation) {
  return `EDW:${encodeURIComponent(contract)}:${Math.trunc(firstSeenTs)}:G${Math.trunc(generation)}`;
}

function directionDomainCount(observation) {
  if (observation?.direction_hint === "LONG") return Number(observation?.long_evidence_domain_count || 0);
  if (observation?.direction_hint === "SHORT") return Number(observation?.short_evidence_domain_count || 0);
  return 0;
}

export function advanceEarlyCandidateMemory({ prior = null, observation, new_wave = false, downstream_lifecycle = null } = {}) {
  if (!observation || observation.status !== "CLOSED" || !text(observation.contract)) {
    return { status: "NOT_CLOSED", reason: "OBSERVATION_NOT_CLOSED", candidate: null };
  }
  const now = finite(observation.observation_ts);
  if (now === null) return { status: "NOT_CLOSED", reason: "OBSERVATION_TS_MISSING", candidate: null };

  const priorValid = prior && text(prior.contract_code) === observation.contract && text(prior.wave_id);
  const priorTerminal = priorValid && ["EXIT", "EDGE_SPENT", "EXCLUDE"].includes(text(prior.lifecycle_stage));
  const openNew = !priorValid || new_wave === true || priorTerminal;
  const generation = openNew ? Number(prior?.generation || 0) + 1 : Number(prior?.generation || 1);
  const firstSeenTs = openNew ? now : finite(prior.first_seen_ts);
  const firstSeenPrice = openNew ? finite(observation.current?.price) : finite(prior.first_seen_price);
  const firstSeenOi = openNew ? finite(observation.current?.oi_contracts) : finite(prior.first_seen_oi);
  const firstSeenFunding = openNew ? finite(observation.current?.funding_rate) : finite(prior.first_seen_funding);
  const firstSeenDetectors = openNew
    ? observation.evidence.map((e) => `${e.domain}:${e.side}`).sort()
    : (Array.isArray(prior.first_seen_detectors) ? prior.first_seen_detectors : []);

  const sameDirection = !openNew && observation.direction_hint && observation.direction_hint === prior?.direction_hint;
  const hasMultiDomain = directionDomainCount(observation) >= 3;
  const supportStreak = observation.direction_hint && hasMultiDomain
    ? (sameDirection ? Number(prior?.support_streak || 0) + 1 : 1)
    : 0;

  let lifecycle = supportStreak >= 2 ? "PRE_IMPULSE_WATCH" : "DISCOVERY";
  if (downstream_lifecycle && (EARLY_STAGES.has(downstream_lifecycle) || DOWNSTREAM_STAGES.has(downstream_lifecycle))) {
    lifecycle = downstream_lifecycle;
  }

  const currentPrice = finite(observation.current?.price);
  const currentOi = finite(observation.current?.oi_contracts);
  const moveSince = currentPrice !== null && firstSeenPrice !== null ? pct(currentPrice, firstSeenPrice) : null;
  const oiSince = currentOi !== null && firstSeenOi !== null ? pct(currentOi, firstSeenOi) : null;

  const candidate = {
    contract_code: observation.contract,
    wave_id: openNew ? waveId(observation.contract, firstSeenTs, generation) : prior.wave_id,
    generation,
    first_seen_ts: firstSeenTs,
    first_seen_price: firstSeenPrice,
    first_seen_oi: firstSeenOi,
    first_seen_funding: firstSeenFunding,
    first_seen_detectors: firstSeenDetectors,
    first_seen_relative_strength_state: openNew ? observation.relative_strength : prior?.first_seen_relative_strength_state ?? null,
    first_seen_volume_state: openNew ? observation.self_normalized?.turnover_5m_proxy ?? null : prior?.first_seen_volume_state ?? null,
    first_seen_liquidation_state: openNew ? { status: observation.context_status?.liquidation ?? "NOT_CHECKED" } : prior?.first_seen_liquidation_state ?? { status:"NOT_CHECKED" },
    first_seen_orderflow_state: openNew ? { status: observation.context_status?.orderflow ?? "NOT_CHECKED" } : prior?.first_seen_orderflow_state ?? { status:"NOT_CHECKED" },
    first_seen_execution_state: openNew ? (observation.context_status?.execution ?? "NOT_EVALUATED") : prior?.first_seen_execution_state ?? "NOT_EVALUATED",
    move_before_first_seen: openNew ? finite(observation.windows?.["1h"]?.price_change_pct) : prior?.move_before_first_seen ?? null,
    move_since_first_seen: moveSince,
    oi_change_since_first_seen: oiSince,
    elapsed_since_first_seen_sec: Math.max(0, (now - firstSeenTs) / 1000),
    lifecycle_stage: lifecycle,
    direction_hint: observation.direction_hint,
    direction_state: observation.direction_state,
    support_streak: supportStreak,
    early_detection_quality_0_100: observation.early_detection_quality_0_100,
    remaining_edge: {
      status: "NOT_VALIDATED_SHADOW",
      move_already_spent_pct: moveSince,
      threshold_applied: false,
    },
    evidence_refs: observation.evidence.map((e) => ({ domain: e.domain, side: e.side, status: e.status })),
    last_seen_ts: now,
    last_price: currentPrice,
    last_oi: currentOi,
    last_funding: finite(observation.current?.funding_rate),
    final_entry: false,
    probability: null,
    validated_signal: false,
    trading_execution: false,
    shadow_only: true,
  };
  return { status: "CLOSED", new_wave_opened: openNew, candidate };
}

export function earlyCandidatePersistenceRows(observation, candidate, { rules_version = V3_EARLY_DISCOVERY_VERSION } = {}) {
  if (!observation || observation.status !== "CLOSED" || !candidate) return { status: "NOT_CLOSED", feature: null, candidate: null };
  const bucket = Math.floor(observation.observation_ts / 300000) * 300000;
  return {
    status: "CLOSED",
    feature: {
      contract_code: observation.contract,
      ts_bucket: bucket,
      observed_ts: observation.observation_ts,
      rules_version,
      direction_hint: observation.direction_hint,
      direction_state: observation.direction_state,
      long_evidence_domain_count: observation.long_evidence_domain_count,
      short_evidence_domain_count: observation.short_evidence_domain_count,
      early_detection_quality_0_100: observation.early_detection_quality_0_100,
      feature_json: JSON.stringify({ windows: observation.windows, acceleration: observation.acceleration, self_normalized: observation.self_normalized, relative_strength: observation.relative_strength, feature_fusion: observation.feature_fusion ?? null }),
      evidence_json: JSON.stringify(observation.evidence),
      shadow_only: 1,
    },
    candidate: {
      contract_code: candidate.contract_code,
      wave_id: candidate.wave_id,
      generation: candidate.generation,
      first_seen_ts: candidate.first_seen_ts,
      first_seen_price: candidate.first_seen_price,
      first_seen_oi: candidate.first_seen_oi,
      first_seen_funding: candidate.first_seen_funding,
      first_seen_detectors_json: JSON.stringify(candidate.first_seen_detectors),
      first_seen_relative_strength_json: JSON.stringify(candidate.first_seen_relative_strength_state ?? null),
      first_seen_volume_json: JSON.stringify(candidate.first_seen_volume_state ?? null),
      first_seen_liquidation_json: JSON.stringify(candidate.first_seen_liquidation_state ?? null),
      first_seen_orderflow_json: JSON.stringify(candidate.first_seen_orderflow_state ?? null),
      first_seen_execution_state: candidate.first_seen_execution_state ?? "NOT_EVALUATED",
      move_before_first_seen: candidate.move_before_first_seen ?? null,
      lifecycle_stage: candidate.lifecycle_stage,
      direction_hint: candidate.direction_hint,
      direction_state: candidate.direction_state,
      support_streak: candidate.support_streak,
      move_since_first_seen: candidate.move_since_first_seen,
      oi_change_since_first_seen: candidate.oi_change_since_first_seen,
      elapsed_since_first_seen_sec: candidate.elapsed_since_first_seen_sec,
      early_detection_quality_0_100: candidate.early_detection_quality_0_100,
      remaining_edge_json: JSON.stringify(candidate.remaining_edge),
      evidence_refs_json: JSON.stringify(candidate.evidence_refs),
      last_seen_ts: candidate.last_seen_ts,
      shadow_only: 1,
    },
  };
}
