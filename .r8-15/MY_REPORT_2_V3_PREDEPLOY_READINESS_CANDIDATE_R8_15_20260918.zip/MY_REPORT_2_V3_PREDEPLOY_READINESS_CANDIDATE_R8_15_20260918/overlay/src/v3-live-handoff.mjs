export const V3_LIVE_HANDOFF_VERSION = 'v3-live-handoff-v2';

export const V3_HANDOFF_STATE = Object.freeze({
  PENDING: 'PENDING',
  CLAIMED: 'CLAIMED',
  COMPLETED: 'COMPLETED',
  BLOCKED_FINAL: 'BLOCKED_FINAL',
  FAILED_RETRYABLE: 'FAILED_RETRYABLE',
  EXPIRED: 'EXPIRED',
});

export const V3_ALLOWED_ZERO_REASONS = new Set([
  'BUDGET_BLOCKED',
  'SOURCE_BUDGET_BLOCKED',
  'COOLDOWN_ACTIVE',
  'SOURCE_UNAVAILABLE',
  'DATA_STALE',
  'EXECUTION_VETO',
  'IDENTITY_UNRESOLVED',
  'NO_TECHNICALLY_ELIGIBLE_CANDIDATE',
  'LIVE_HANDOFF_UNMAPPED_FAIL_CLOSED',
]);

function text(v) {
  return v === null || v === undefined ? '' : String(v).trim();
}

function finite(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function integer(v) {
  const n = finite(v);
  return n !== null && Number.isSafeInteger(n) ? n : null;
}

function normalizeDirection(v) {
  const d = text(v).toUpperCase();
  return d === 'LONG' || d === 'SHORT' ? d : null;
}

export function parseExactHtxUsdtContract(contract) {
  const exact = text(contract).normalize('NFC');
  const m = exact.match(/^(.+)-USDT$/u);
  if (!m || !m[1]) return { ok: false, contract: exact || null, base_ticker: null, quote: null };
  return { ok: true, contract: exact, base_ticker: m[1], quote: 'USDT' };
}

function uniqText(values) {
  return [...new Set((Array.isArray(values) ? values : []).map(text).filter(Boolean))];
}

export function buildHandoffLogicalKey({ source_run_id, contract_code, wave_id, dedup_reentry_key } = {}) {
  const run = text(source_run_id);
  const contract = text(contract_code).normalize('NFC');
  const wave = text(wave_id) || 'NO_WAVE';
  const reentry = text(dedup_reentry_key) || 'NO_REENTRY_KEY';
  if (!run || !contract) return null;
  return `${run}|${contract}|${wave}|${reentry}`;
}

export function buildDiscoveryHandoffEnvelope(row, {
  source_run_id,
  scan_ts,
  first_seen_state = null,
  current_state = null,
  wave_id = null,
  dedup_reentry_key = null,
  evidence_ids = null,
  now_ts = Date.now(),
} = {}) {
  const contract = parseExactHtxUsdtContract(row?.contract ?? row?.contract_code);
  const run = text(source_run_id);
  const scanTs = integer(scan_ts);
  const now = integer(now_ts);
  if (!contract.ok) return { status: 'IDENTITY_UNRESOLVED', envelope: null };
  if (!run) return { status: 'SOURCE_RUN_ID_MISSING', envelope: null };
  if (scanTs === null || scanTs <= 0 || now === null || now <= 0 || scanTs > now) {
    return { status: 'SCAN_TS_INVALID', envelope: null };
  }

  const rank = integer(row?.priority_rank ?? row?.rank ?? row?.discovery_rank);
  const detectors = uniqText(
    row?.detectors ?? row?.flags ?? row?.anomaly_flags ?? row?.detector_ids ?? []
  );
  const evidence = uniqText(evidence_ids ?? row?.evidence_ids ?? row?.evidence_refs ?? []);
  const wave = text(wave_id ?? row?.wave_id) || null;
  const reentry = text(
    dedup_reentry_key ?? row?.dedup_reentry_key ?? row?.reentry_key ??
    `${contract.contract}|${wave || 'NO_WAVE'}|${run}`
  );
  const logicalKey = buildHandoffLogicalKey({
    source_run_id: run,
    contract_code: contract.contract,
    wave_id: wave,
    dedup_reentry_key: reentry,
  });

  return {
    status: 'CLOSED',
    envelope: {
      version: V3_LIVE_HANDOFF_VERSION,
      handoff_id: logicalKey,
      logical_key: logicalKey,
      exact_htx_contract: contract.contract,
      base_ticker: contract.base_ticker,
      quote: contract.quote,
      source_run_id: run,
      scan_ts: scanTs,
      discovery_rank: rank,
      detectors,
      evidence_ids: evidence,
      first_seen_state: first_seen_state ?? row?.first_seen_state ?? null,
      current_state: current_state ?? row?.current_state ?? row?.lifecycle_stage ?? null,
      direction: normalizeDirection(row?.direction ?? row?.direction_hint),
      wave_id: wave,
      dedup_reentry_key: reentry,
      created_ts: now,
      shadow_only: true,
    },
  };
}

export function buildV3LiveHandoffPlan({
  discovery_prefilter,
  fast_move_watch_cycle,
  opportunity_journal_plan,
} = {}) {
  const shortlist = Array.isArray(discovery_prefilter?.shortlist)
    ? discovery_prefilter.shortlist
    : [];

  const liveContracts = uniqText(shortlist.map((row) => row?.contract));

  const fastMoveContract = text(
    fast_move_watch_cycle?.selected_leases?.[0]?.contract ||
    fast_move_watch_cycle?.selected_contracts?.[0]
  );

  const maintenanceContract =
    opportunity_journal_plan?.status === 'SELECTED_BOUNDED_JOURNAL_MAINTENANCE'
      ? text(opportunity_journal_plan?.selected_contract)
      : '';

  const maintenanceAvailable = Boolean(maintenanceContract);

  if (fastMoveContract) {
    return {
      version: V3_LIVE_HANDOFF_VERSION,
      lane: 'LIVE_FAST_MOVE_RECHECK',
      live_shortlist_count: liveContracts.length,
      live_contracts: liveContracts,
      require_exact_contract: true,
      required_contract: fastMoveContract,
      maintenance_available: maintenanceAvailable,
      maintenance_deferred: maintenanceAvailable,
      maintenance_contract: maintenanceContract || null,
      reason: 'FAST_MOVE_EXACT_LEASE_HAS_LIVE_PRIORITY',
    };
  }

  if (liveContracts.length) {
    return {
      version: V3_LIVE_HANDOFF_VERSION,
      lane: 'LIVE_DISCOVERY',
      live_shortlist_count: liveContracts.length,
      live_contracts: liveContracts,
      require_exact_contract: false,
      required_contract: null,
      maintenance_available: maintenanceAvailable,
      maintenance_deferred: maintenanceAvailable,
      maintenance_contract: maintenanceContract || null,
      reason: 'DISCOVERY_LIVE_SLOT_RESERVED_BEFORE_MAINTENANCE',
    };
  }

  if (maintenanceAvailable) {
    return {
      version: V3_LIVE_HANDOFF_VERSION,
      lane: 'MAINTENANCE',
      live_shortlist_count: 0,
      live_contracts: [],
      require_exact_contract: true,
      required_contract: maintenanceContract,
      maintenance_available: true,
      maintenance_deferred: false,
      maintenance_contract: maintenanceContract,
      reason: 'NO_LIVE_DISCOVERY_MAINTENANCE_ALLOWED',
    };
  }

  return {
    version: V3_LIVE_HANDOFF_VERSION,
    lane: 'IDLE',
    live_shortlist_count: 0,
    live_contracts: [],
    require_exact_contract: false,
    required_contract: null,
    maintenance_available: false,
    maintenance_deferred: false,
    maintenance_contract: null,
    reason: 'NO_LIVE_OR_MAINTENANCE_TARGET',
  };
}

export function classifyV3LiveHandoffZeroReason({ handoff_plan, bounded_deep_check } = {}) {
  const selected = Number(bounded_deep_check?.plan?.counts?.selected || 0);
  if (selected > 0) return null;

  const liveCount = Number(handoff_plan?.live_shortlist_count || 0);
  const lane = text(handoff_plan?.lane).toUpperCase() || 'IDLE';
  const status = text(bounded_deep_check?.status).toUpperCase();
  const plan = bounded_deep_check?.plan || {};
  const blockedReasons = Array.isArray(plan?.blocked)
    ? plan.blocked.map((row) => text(row?.reason).toUpperCase()).filter(Boolean)
    : [];

  if (liveCount === 0 && lane === 'IDLE') return 'NO_TECHNICALLY_ELIGIBLE_CANDIDATE';
  if (status.includes('BUDGET')) return 'BUDGET_BLOCKED';
  if (status.includes('SOURCE_UNSUPPORTED') || status.includes('SCHEDULER_STATE') || status.includes('SOURCE_UNAVAILABLE')) {
    return 'SOURCE_UNAVAILABLE';
  }
  if (status.includes('STALE')) return 'DATA_STALE';
  if (status.includes('EXECUTION_VETO') || blockedReasons.includes('EXECUTION_VETO')) return 'EXECUTION_VETO';
  if (plan?.scope_status && plan.scope_status !== 'CONFIRMED_SET_SUPPLIED') return 'IDENTITY_UNRESOLVED';
  if (Number(plan?.parameters?.resource_max_per_run ?? 1) <= 0 || plan?.budget?.within_known_external_limit === false) {
    return 'BUDGET_BLOCKED';
  }
  if (
    blockedReasons.length > 0 &&
    blockedReasons.every((reason) => reason === 'COOLDOWN' || reason === 'ACTIVE_LEASE')
  ) return 'COOLDOWN_ACTIVE';
  if (plan?.parameters?.required_contract_status === 'NOT_READY_FAIL_CLOSED') return 'COOLDOWN_ACTIVE';
  if (status === 'NO_READY_TARGETS' && blockedReasons.some((reason) => reason === 'COOLDOWN' || reason === 'ACTIVE_LEASE')) {
    return 'COOLDOWN_ACTIVE';
  }
  if (liveCount > 0) return 'LIVE_HANDOFF_UNMAPPED_FAIL_CLOSED';
  return 'NO_TECHNICALLY_ELIGIBLE_CANDIDATE';
}

export function assessV3PipelineHealth({ handoff_plan, bounded_deep_check, zero_reason } = {}) {
  const lane = text(handoff_plan?.lane).toUpperCase() || 'IDLE';
  const liveCount = Number(handoff_plan?.live_shortlist_count || 0);
  const selected = Number(bounded_deep_check?.plan?.counts?.selected || 0);
  const reason = text(zero_reason).toUpperCase() || null;

  if (lane === 'MAINTENANCE' && liveCount > 0) {
    return { status: 'DEGRADED_PIPELINE', reason: 'MAINTENANCE_STARVED_LIVE' };
  }
  if (liveCount > 0 && selected === 0 && !V3_ALLOWED_ZERO_REASONS.has(reason)) {
    return { status: 'DEGRADED_PIPELINE', reason: 'LIVE_DEEP_CHECK_SILENT_DROP' };
  }
  if (reason === 'LIVE_HANDOFF_UNMAPPED_FAIL_CLOSED') {
    return { status: 'DEGRADED_PIPELINE', reason };
  }
  return {
    status: 'HEALTHY_NO_IDEA',
    reason,
    live_candidate_deep_checked: liveCount > 0 && selected > 0,
    live_candidate_absent: liveCount === 0,
  };
}

export function nextHandoffState({ current, event, retryable = false } = {}) {
  const cur = text(current).toUpperCase();
  const ev = text(event).toUpperCase();
  if (!Object.values(V3_HANDOFF_STATE).includes(cur)) return null;
  if (cur === V3_HANDOFF_STATE.PENDING && ev === 'CLAIM') return V3_HANDOFF_STATE.CLAIMED;
  if (cur === V3_HANDOFF_STATE.FAILED_RETRYABLE && ev === 'CLAIM') return V3_HANDOFF_STATE.CLAIMED;
  if (cur === V3_HANDOFF_STATE.CLAIMED && ev === 'COMPLETE') return V3_HANDOFF_STATE.COMPLETED;
  if (cur === V3_HANDOFF_STATE.CLAIMED && ev === 'BLOCK') return V3_HANDOFF_STATE.BLOCKED_FINAL;
  if (cur === V3_HANDOFF_STATE.CLAIMED && ev === 'FAIL') return retryable ? V3_HANDOFF_STATE.FAILED_RETRYABLE : V3_HANDOFF_STATE.BLOCKED_FINAL;
  if ((cur === V3_HANDOFF_STATE.PENDING || cur === V3_HANDOFF_STATE.CLAIMED || cur === V3_HANDOFF_STATE.FAILED_RETRYABLE) && ev === 'EXPIRE') {
    return V3_HANDOFF_STATE.EXPIRED;
  }
  return cur;
}
