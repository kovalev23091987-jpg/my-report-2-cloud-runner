import {aggregateRealizedLiquidations,buildRealizedDensityMap} from './v3-liquidation-data-plane.mjs';

export const V3_LIQ_PERSIST_VERSION='v3-liquidation-compact-persistence-shadow-v1';
export const V3_LIQ_PERSIST_CAPS=Object.freeze({max_health_rows:8,max_density_buckets_per_contract:12,max_contracts_per_flush:3,windows:['1m','5m','15m','1h','4h','12h','24h']});
function text(v){return v==null?'':String(v).trim();}
function finite(v){if(v==null||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null;}
function json(v,fb){try{return JSON.stringify(v??fb);}catch{return JSON.stringify(fb);}}
function b(v){return v===true?1:0;}
function roundMinute(ts){const n=finite(ts)??Date.now();return Math.floor(n/60_000)*60_000;}

export async function persistCollectorHealthCompact(db,healthRows,{now_ts=Date.now()}={}){
  if(!db?.prepare||!db?.batch)return {status:'SOURCE_UNSUPPORTED',persisted:0};
  const now=Math.trunc(finite(now_ts)??Date.now()),bucket=roundMinute(now);
  const rows=(Array.isArray(healthRows)?healthRows:[]).slice(0,V3_LIQ_PERSIST_CAPS.max_health_rows);
  const stmts=[];
  for(const h of rows){
    const source=text(h?.source_id||h?.source||h?.venue);const venue=text(h?.venue).toUpperCase();if(!source||!venue)continue;
    const expected=Array.isArray(h?.expected_symbols)?h.expected_symbols.length:null;
    const observed=Array.isArray(h?.observed_symbols)?h.observed_symbols.length:null;
    const cov=finite(h?.symbol_coverage_pct)??(expected&&observed!==null?100*observed/expected:null);
    stmts.push(db.prepare(`INSERT INTO v3_source_health_1m(
      source_id,venue,bucket_ts,connected,health_state,last_event_ts,event_gap_sec,venue_latency_ms,
      reconnect_count,dropped_count,parse_error_count,rate_limit_state,symbol_coverage_pct,coverage_class,last_error,persisted_ts,shadow_only)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,1)
      ON CONFLICT(source_id,bucket_ts) DO UPDATE SET connected=excluded.connected,health_state=excluded.health_state,
      last_event_ts=excluded.last_event_ts,event_gap_sec=excluded.event_gap_sec,venue_latency_ms=excluded.venue_latency_ms,
      reconnect_count=excluded.reconnect_count,dropped_count=excluded.dropped_count,parse_error_count=excluded.parse_error_count,
      rate_limit_state=excluded.rate_limit_state,symbol_coverage_pct=excluded.symbol_coverage_pct,
      coverage_class=excluded.coverage_class,last_error=excluded.last_error,persisted_ts=excluded.persisted_ts,shadow_only=1`)
      .bind(source,venue,bucket,b(h?.connected),text(h?.health_state||h?.stale_state||'UNKNOWN'),finite(h?.last_event_ts),finite(h?.event_gap_sec),finite(h?.venue_latency_ms),
        Math.max(0,Number(h?.reconnect_count||0)),Math.max(0,Number(h?.dropped_count??h?.dropped??0)),Math.max(0,Number(h?.parse_error_count??h?.parse_error??0)),
        text(h?.rate_limit_state)||'UNKNOWN',cov,text(h?.coverage_class)||null,text(h?.last_error)||null,now));
  }
  if(!stmts.length)return {status:'CLOSED_NO_HEALTH_ROWS',persisted:0};
  try{await db.batch(stmts);return {status:'CLOSED',persisted:stmts.length,shadow_only:true};}catch(error){return {status:/no such table/i.test(String(error?.message||error))?'MIGRATION_REQUIRED':'PARTIAL',persisted:0,error:String(error?.message||error)};}
}

export async function persistRealizedLiquidationCompact(db,{contract,events,reference_price,market_context={},now_ts=Date.now(),bucket_size_pct=0.25,windows=V3_LIQ_PERSIST_CAPS.windows,density_lookback_ms=null}={}){
  if(!db?.prepare||!db?.batch)return {status:'SOURCE_UNSUPPORTED',persisted:0};
  const c=text(contract);const now=Math.trunc(finite(now_ts)??Date.now());if(!c)return {status:'INVALID_CONTRACT',persisted:0};
  const own=(Array.isArray(events)?events:[]).filter(e=>text(e?.contract)===c);
  const selectedWindows=[...new Set((Array.isArray(windows)?windows:V3_LIQ_PERSIST_CAPS.windows).filter(w=>V3_LIQ_PERSIST_CAPS.windows.includes(w)))];
  const agg=aggregateRealizedLiquidations(own,{now_ts:now,windows:selectedWindows,market_context});
  const density=buildRealizedDensityMap(own,{now_ts:now,lookback_ms:finite(density_lookback_ms)??undefined,reference_price,bucket_size_pct});
  const stmts=[];
  for(const w of selectedWindows){
    const a=agg.windows?.[w];if(!a)continue;
    stmts.push(db.prepare(`INSERT INTO v3_realized_liquidation_aggregate(
      contract_code,window_name,end_ts,event_count_observed,known_side_count,unknown_side_count,
      long_liquidation_count,short_liquidation_count,known_long_liquidation_count,known_short_liquidation_count,
      total_notional_usdt,known_notional_usdt,long_notional_usdt,short_notional_usdt,max_single_event_usdt,
      liquidation_side_imbalance,venue_breadth,venue_concentration,burst_velocity_events_per_min,
      burst_acceleration_events_per_min,consecutive_burst_minutes,liquidation_to_volume_ratio,
      price_response_pct,oi_response_pct,flow_response_delta_usdt,side_coverage_closed,notional_coverage_closed,
      coverage_classes_json,venues_json,persisted_ts,shadow_only)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22,?23,?24,?25,?26,?27,?28,?29,?30,1)
      ON CONFLICT(contract_code,window_name,end_ts) DO UPDATE SET
       event_count_observed=excluded.event_count_observed,known_side_count=excluded.known_side_count,
       unknown_side_count=excluded.unknown_side_count,long_liquidation_count=excluded.long_liquidation_count,
       short_liquidation_count=excluded.short_liquidation_count,known_long_liquidation_count=excluded.known_long_liquidation_count,
       known_short_liquidation_count=excluded.known_short_liquidation_count,total_notional_usdt=excluded.total_notional_usdt,
       known_notional_usdt=excluded.known_notional_usdt,long_notional_usdt=excluded.long_notional_usdt,
       short_notional_usdt=excluded.short_notional_usdt,max_single_event_usdt=excluded.max_single_event_usdt,
       liquidation_side_imbalance=excluded.liquidation_side_imbalance,venue_breadth=excluded.venue_breadth,
       venue_concentration=excluded.venue_concentration,burst_velocity_events_per_min=excluded.burst_velocity_events_per_min,
       burst_acceleration_events_per_min=excluded.burst_acceleration_events_per_min,
       consecutive_burst_minutes=excluded.consecutive_burst_minutes,liquidation_to_volume_ratio=excluded.liquidation_to_volume_ratio,
       price_response_pct=excluded.price_response_pct,oi_response_pct=excluded.oi_response_pct,
       flow_response_delta_usdt=excluded.flow_response_delta_usdt,side_coverage_closed=excluded.side_coverage_closed,
       notional_coverage_closed=excluded.notional_coverage_closed,coverage_classes_json=excluded.coverage_classes_json,
       venues_json=excluded.venues_json,persisted_ts=excluded.persisted_ts,shadow_only=1`)
      .bind(c,w,a.end_ts,a.event_count_observed,a.known_side_count,a.unknown_side_count,a.long_liquidation_count,a.short_liquidation_count,
        a.known_long_liquidation_count,a.known_short_liquidation_count,a.total_notional_usdt,a.known_notional_usdt,a.long_notional_usdt,a.short_notional_usdt,
        a.max_single_event_usdt,a.liquidation_side_imbalance,a.venue_breadth,a.venue_concentration,
        a.burst_velocity_events_per_min,a.burst_acceleration_events_per_min,a.consecutive_burst_minutes,
        a.liquidation_to_volume_ratio,a.price_response_pct,a.oi_response_pct,a.flow_response_delta_usdt,
        b(a.side_coverage_closed),b(a.notional_coverage_closed),json(a.coverage_classes,[]),json(a.venues,[]),now));
  }
  let densityCount=0;
  if(density.status==='CLOSED'){
    const rows=density.buckets.slice(0,V3_LIQ_PERSIST_CAPS.max_density_buckets_per_contract);
    for(const d of rows){densityCount+=1;stmts.push(db.prepare(`INSERT INTO v3_realized_liquidation_density_5m(
      contract_code,venue,liquidated_side,bucket_ts,price_bucket_center,bucket_size_pct,event_count,known_notional_usdt,
      unknown_notional_count,first_event_ts,last_event_ts,persisted_ts,shadow_only)
      VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,1)
      ON CONFLICT(contract_code,venue,liquidated_side,bucket_ts,price_bucket_center) DO UPDATE SET
       event_count=excluded.event_count,known_notional_usdt=excluded.known_notional_usdt,
       unknown_notional_count=excluded.unknown_notional_count,first_event_ts=excluded.first_event_ts,
       last_event_ts=excluded.last_event_ts,persisted_ts=excluded.persisted_ts,shadow_only=1`)
      .bind(c,text(d.venue).toUpperCase()||'UNKNOWN',['LONG','SHORT'].includes(d.side)?d.side:'UNKNOWN',Math.floor(now/300000)*300000,d.price_bucket_center,density.bucket_size_pct,d.count,d.known_notional_usdt,d.unknown_notional_count,d.first_ts,d.last_ts,now));}
  }
  try{await db.batch(stmts);return {status:'CLOSED',aggregate_rows:selectedWindows.length,density_rows:densityCount,persisted:stmts.length,raw_events_persisted:0,future_heatmap:false,shadow_only:true};}
  catch(error){return {status:/no such table/i.test(String(error?.message||error))?'MIGRATION_REQUIRED':'PARTIAL',persisted:0,error:String(error?.message||error)};}
}

export default {persistCollectorHealthCompact,persistRealizedLiquidationCompact,V3_LIQ_PERSIST_CAPS};
