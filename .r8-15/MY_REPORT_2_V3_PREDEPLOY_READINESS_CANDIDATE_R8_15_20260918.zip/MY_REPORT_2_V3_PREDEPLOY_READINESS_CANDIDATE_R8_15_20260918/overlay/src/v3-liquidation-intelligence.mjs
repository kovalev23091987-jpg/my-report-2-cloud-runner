export const V3_LIQUIDATION_INTELLIGENCE_VERSION = "v3-liquidation-intelligence-shadow-v1";

function finite(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
function text(value) { return value === null || value === undefined ? "" : String(value).trim(); }
function pctDistance(level, current) {
  const p = finite(level), c = finite(current);
  return p !== null && c !== null && c > 0 ? ((p / c) - 1) * 100 : null;
}
function exactBase(contract) {
  const m = text(contract).normalize("NFC").toUpperCase().match(/^([A-Z0-9]+)-USDT$/);
  return m ? m[1] : null;
}

export function classifyProjectedProviderMap(record, { htx_contract, htx_current_price = null, max_price_anchor_diff_pct = 5 } = {}) {
  const base = exactBase(htx_contract);
  const providerSymbol = text(record?.provider_symbol).toUpperCase();
  const sourceAge = finite(record?.projected_source_age_sec);
  const providerPrice = finite(record?.provider_current_price);
  const htxPrice = finite(htx_current_price);
  const priceDiff = providerPrice !== null && htxPrice !== null && htxPrice > 0
    ? Math.abs((providerPrice / htxPrice - 1) * 100)
    : null;
  const reasons = [];
  if (!base) reasons.push("HTX_BASE_IDENTITY_UNRESOLVED");
  if (!providerSymbol || providerSymbol !== base) reasons.push("PROVIDER_SYMBOL_EXACT_BASE_MISMATCH");
  if (record?.source_health?.provider_symbol_registry_exact_match !== true) reasons.push("PROVIDER_SYMBOL_REGISTRY_NOT_EXACT");
  if (record?.asset_identity_verified !== true) reasons.push("ASSET_IDENTITY_NOT_SEPARATELY_VERIFIED");
  const sourceStatus = text(record?.projected_map_status).toUpperCase();
  if (sourceStatus && !["OBSERVATION_ONLY_IDENTITY_UNVERIFIED","OBSERVATION_ONLY_ALIAS_UNVERIFIED","CLOSED_SHADOW"].includes(sourceStatus)) {
    reasons.push("PROJECTED_SOURCE_STATUS_NOT_USABLE");
  }
  if (record?.projected_freshness !== "CURRENT" || sourceAge === null) reasons.push("PROJECTED_TIMESTAMP_OR_FRESHNESS_NOT_CLOSED");
  if (!Array.isArray(record?.projected_clusters) || record.projected_clusters.length === 0) reasons.push("PROJECTED_CLUSTERS_EMPTY");
  if (record?.source_health?.projected_scan_truncated === true || record?.source_health?.projected_cluster_output_truncated === true) reasons.push("PROJECTED_PROVIDER_PAYLOAD_TRUNCATED");
  if (priceDiff !== null && priceDiff > max_price_anchor_diff_pct) reasons.push("PROVIDER_PRICE_ANCHOR_DISAGREES_WITH_HTX");
  const identityClosed = reasons.filter((r) => r.includes("IDENTITY") || r.includes("SYMBOL") || r.includes("PRICE_ANCHOR")).length === 0;
  const closed = reasons.length === 0;
  return {
    version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
    type: "PROJECTED_PROVIDER_MAP",
    provider: record?.provider || "ByKaranteli LiqMap Public API",
    status: closed ? "CLOSED_SHADOW" : "NOT_CLOSED",
    identity_scope: "CROSS_VENUE_BASE_USDT_PERPETUAL_CONTEXT_NOT_HTX_EXECUTION_SUBSTITUTE",
    identity_status: identityClosed ? "CLOSED" : "IDENTITY_UNRESOLVED",
    semantics: "PROVIDER_DERIVED_ESTIMATED_LIQUIDATION_PRESSURE_NOT_ACTUAL_USER_POSITIONS",
    timestamp_known: sourceAge !== null,
    freshness_status: record?.projected_freshness ?? null,
    source_age_sec: sourceAge,
    provider_price_anchor_diff_pct: priceDiff,
    cluster_count: Array.isArray(record?.projected_clusters) ? record.projected_clusters.length : 0,
    reasons,
    decision_eligible: false,
    supporting_timing_shadow_only: closed,
    factual_user_positions: false,
    modelled_proxy: false,
    guaranteed_tp: false,
    shadow_only: true,
  };
}

function strengthValue(c) {
  const raw = finite(c?.raw_size);
  const norm = finite(c?.normalized_strength);
  if (raw !== null && raw >= 0) return { value: raw, unit: text(c?.source_unit) || "PROVIDER_RAW_SIZE" };
  if (norm !== null) return { value: norm, unit: "PROVIDER_NORMALIZED_STRENGTH" };
  return { value: null, unit: null };
}

function quantile(values, q) {
  const a = values.filter(Number.isFinite).slice().sort((x, y) => x - y);
  if (!a.length) return null;
  const pos = (a.length - 1) * Math.max(0, Math.min(1, q));
  const lo = Math.floor(pos), hi = Math.ceil(pos);
  return lo === hi ? a[lo] : a[lo] * (hi - pos) + a[hi] * (pos - lo);
}

function compactCluster(c, currentPrice) {
  const strength = strengthValue(c);
  return {
    type: "PROJECTED_PROVIDER_MAP",
    provider: c?.provider || "ByKaranteli LiqMap Public API",
    side: c?.side || "UNKNOWN",
    level_price: finite(c?.level_price),
    price_low: finite(c?.price_low),
    price_high: finite(c?.price_high),
    distance_pct: pctDistance(c?.level_price, currentPrice),
    strength: strength.value,
    strength_unit: strength.unit,
    explicit_major: c?.explicit_major === true,
    leverage_bucket: c?.leverage_bucket ?? null,
    source_ts: finite(c?.source_ts),
    lifecycle: c?.lifecycle || "ACTIVE",
    factual_user_positions: false,
    guaranteed_tp: false,
  };
}

export function buildExtendedLiquidationScan(record, {
  htx_contract,
  htx_current_price,
  move_24h_pct,
  max_output_per_side = 8,
} = {}) {
  const eligibility = classifyProjectedProviderMap(record, { htx_contract, htx_current_price });
  const move = finite(move_24h_pct);
  const current = finite(htx_current_price);
  const activated = move !== null && Math.abs(move) >= 10;
  if (!activated) {
    return {
      version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
      status: "NOT_TRIGGERED",
      trigger: "ABS_24H_MOVE_GTE_10_PCT",
      move_24h_pct: move,
      projected_provider_map_status: eligibility.status,
      above: [], below: [], far_huge_clusters: [], shadow_only: true,
    };
  }
  if (eligibility.status !== "CLOSED_SHADOW" || current === null || current <= 0) {
    return {
      version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
      status: "PROJECTED_PROVIDER_MAP_NOT_CLOSED",
      trigger: "ABS_24H_MOVE_GTE_10_PCT",
      move_24h_pct: move,
      projected_provider_map_status: eligibility.status,
      reasons: eligibility.reasons,
      above: [], below: [], far_huge_clusters: [], shadow_only: true,
    };
  }

  const clusters = record.projected_clusters
    .map((c) => compactCluster(c, current))
    .filter((c) => c.level_price !== null && c.distance_pct !== null && c.distance_pct !== 0);
  const strengths = clusters.map((c) => c.strength).filter(Number.isFinite);
  const p70 = quantile(strengths, 0.70);
  const p90 = quantile(strengths, 0.90);
  const significance = (c) => {
    if (c.explicit_major) return "MAJOR";
    if (c.strength !== null && p90 !== null && c.strength >= p90) return "MAJOR";
    if (c.strength !== null && p70 !== null && c.strength >= p70) return "SIGNIFICANT";
    return "SMALL";
  };
  const annotate = (c) => ({
    ...c,
    significance: significance(c),
    distance_band: Math.abs(c.distance_pct) >= 50 ? "50PCT_PLUS"
      : Math.abs(c.distance_pct) >= 30 ? "30_TO_50PCT"
        : Math.abs(c.distance_pct) >= 20 ? "20_TO_30PCT" : "UNDER_20PCT",
  });
  const relevant = clusters.map(annotate).filter((c) => c.significance !== "SMALL");
  const sortPriority = (a, b) => {
    const sig = { MAJOR: 2, SIGNIFICANT: 1 };
    return (sig[b.significance] - sig[a.significance]) ||
      ((b.strength ?? -Infinity) - (a.strength ?? -Infinity)) ||
      (Math.abs(a.distance_pct) - Math.abs(b.distance_pct));
  };
  const above = relevant.filter((c) => c.distance_pct > 0).sort(sortPriority).slice(0, max_output_per_side);
  const below = relevant.filter((c) => c.distance_pct < 0).sort(sortPriority).slice(0, max_output_per_side);
  const farHuge = relevant
    .filter((c) => c.significance === "MAJOR" && Math.abs(c.distance_pct) >= 20)
    .sort((a, b) => Math.abs(a.distance_pct) - Math.abs(b.distance_pct));

  return {
    version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
    status: "CLOSED_SHADOW",
    trigger: "ABS_24H_MOVE_GTE_10_PCT",
    move_24h_pct: move,
    current_price: current,
    projected_provider_map_status: eligibility.status,
    largest_cluster_is_guaranteed_tp: false,
    distance_is_evidence_of_cluster: false,
    theoretical_leverage_levels_included: false,
    above,
    below,
    far_huge_clusters: farHuge,
    all_significant_count: relevant.length,
    shadow_only: true,
  };
}

export function updateProjectedClusterLifecycle(prior, current, { previous_price = null, current_price = null, oi_change_pct = null } = {}) {
  const before = prior && typeof prior === "object" ? prior : null;
  const now = current && typeof current === "object" ? current : null;
  if (!now || finite(now.level_price) === null) return { status: "NOT_CLOSED", reason: "CURRENT_CLUSTER_INVALID" };
  const level = finite(now.level_price);
  const pp = finite(previous_price), cp = finite(current_price);
  const priorStrength = finite(before?.strength ?? before?.raw_size ?? before?.normalized_strength);
  const currentStrength = finite(now?.strength ?? now?.raw_size ?? now?.normalized_strength);
  const strengthened = priorStrength !== null && currentStrength !== null ? currentStrength > priorStrength : null;
  const weakened = priorStrength !== null && currentStrength !== null ? currentStrength < priorStrength : null;
  const side = now.side || before?.side || "UNKNOWN";
  let touched = false, swept = false;
  if (pp !== null && cp !== null) {
    if (side === "SHORT_LIQUIDATION_ABOVE") {
      touched = Math.max(pp, cp) >= level;
      swept = pp < level && cp >= level;
    } else if (side === "LONG_LIQUIDATION_BELOW") {
      touched = Math.min(pp, cp) <= level;
      swept = pp > level && cp <= level;
    }
  }
  const partiallySwept = touched && !swept;
  const lifecycle = swept ? "SWEPT" : touched ? "TOUCHED" : (now.lifecycle || "ACTIVE");
  return {
    status: "CLOSED",
    type: "PROJECTED_PROVIDER_MAP_CLUSTER_LIFECYCLE",
    cluster_key: now.cluster_key || before?.cluster_key || null,
    first_seen_ts: finite(before?.first_seen_ts) ?? finite(now?.source_ts) ?? null,
    last_seen_ts: finite(now?.last_seen_ts) ?? finite(now?.source_ts) ?? null,
    level_price: level,
    side,
    strengthened,
    weakened,
    touched,
    swept,
    partially_swept: partiallySwept,
    lifecycle,
    price_reaction_pct: pp !== null && cp !== null ? ((cp / pp) - 1) * 100 : null,
    oi_reaction_pct: finite(oi_change_pct),
    magnet_after_sweep_assumed: false,
    guaranteed_tp: false,
  };
}

export function buildCrossVenueRealizedVector(events, { now_ts = Date.now(), window_ms = 5 * 60_000 } = {}) {
  const now = finite(now_ts) ?? Date.now();
  const rows = (Array.isArray(events) ? events : []).filter((e) => {
    const ts = finite(e?.ts_exchange);
    return ts !== null && ts > now - window_ms && ts <= now;
  });
  const venues = new Map();
  for (const e of rows) {
    const venue = text(e?.venue).toUpperCase() || "UNKNOWN";
    const item = venues.get(venue) || { venue, observed_events: 0, known_long_count: 0, known_short_count: 0, unknown_side_count: 0, known_notional_usdt: 0, unknown_notional_count: 0, coverage_classes: new Set() };
    item.observed_events += 1;
    if (e?.liquidated_side_normalized === "LONG") item.known_long_count += 1;
    else if (e?.liquidated_side_normalized === "SHORT") item.known_short_count += 1;
    else item.unknown_side_count += 1;
    const n = finite(e?.notional_usdt_normalized);
    if (n !== null) item.known_notional_usdt += n; else item.unknown_notional_count += 1;
    if (e?.source_coverage_class) item.coverage_classes.add(e.source_coverage_class);
    venues.set(venue, item);
  }
  const vector = [...venues.values()].map((v) => ({ ...v, coverage_classes: [...v.coverage_classes].sort() })).sort((a, b) => a.venue.localeCompare(b.venue));
  const sideBiases = vector.map((v) => {
    if (v.unknown_side_count > 0 || (v.known_long_count === 0 && v.known_short_count === 0)) return { venue: v.venue, bias: "UNKNOWN" };
    if (v.known_long_count > v.known_short_count) return { venue: v.venue, bias: "LONG_LIQUIDATION_DOMINANT" };
    if (v.known_short_count > v.known_long_count) return { venue: v.venue, bias: "SHORT_LIQUIDATION_DOMINANT" };
    return { venue: v.venue, bias: "BALANCED" };
  });
  const knownDirectional = sideBiases.filter((x) => !["UNKNOWN", "BALANCED"].includes(x.bias));
  const disagreement = new Set(knownDirectional.map((x) => x.bias)).size > 1;
  return {
    version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
    type: "CROSS_VENUE_REALIZED_VECTOR",
    as_of_ts: now,
    window_ms,
    venue_breadth: vector.length,
    vector,
    side_biases: sideBiases,
    disagreement,
    consensus: disagreement ? "DISAGREEMENT" : (knownDirectional.length >= 2 ? "SIDE_AGREEMENT_OBSERVED" : "INSUFFICIENT_INDEPENDENT_VENUES"),
    auto_average_performed: false,
    missing_is_zero: false,
    shadow_only: true,
  };
}

export function buildModelledPressureProxy({ current_price, oi_value_usdt, leverage_tiers = [], factual_margin_metadata = false } = {}) {
  const price = finite(current_price), oi = finite(oi_value_usdt);
  const tiers = Array.isArray(leverage_tiers) ? leverage_tiers : [];
  if (price === null || price <= 0 || oi === null || oi <= 0 || factual_margin_metadata !== true || tiers.length === 0) {
    return {
      version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
      type: "MODELLED_LIQUIDATION_PRESSURE_PROXY",
      label: "MODELLED_PROXY",
      status: "INSUFFICIENT_FACTUAL_INPUTS",
      zones: [],
      actual_user_positions: false,
      projected_provider_map: false,
      decision_eligible: false,
      shadow_only: true,
    };
  }
  const zones = [];
  for (const tier of tiers) {
    const leverage = finite(tier?.leverage);
    const maintenance = finite(tier?.maintenance_margin_rate);
    const factualShare = finite(tier?.oi_share_factual);
    if (leverage === null || leverage <= 1 || maintenance === null || maintenance < 0 || factualShare === null || factualShare < 0 || factualShare > 1) continue;
    const grossMove = Math.max(0, (1 / leverage) - maintenance);
    const notional = oi * factualShare;
    zones.push({
      leverage,
      maintenance_margin_rate: maintenance,
      oi_share_factual: factualShare,
      long_pressure_reference_price: price * (1 - grossMove),
      short_pressure_reference_price: price * (1 + grossMove),
      proxy_notional_usdt: notional,
      semantics: "THEORETICAL_MARGIN_PRESSURE_REFERENCE_NOT_REAL_CLUSTER",
    });
  }
  return {
    version: V3_LIQUIDATION_INTELLIGENCE_VERSION,
    type: "MODELLED_LIQUIDATION_PRESSURE_PROXY",
    label: "MODELLED_PROXY",
    status: zones.length ? "CLOSED_SHADOW" : "INSUFFICIENT_FACTUAL_INPUTS",
    zones,
    actual_user_positions: false,
    projected_provider_map: false,
    real_heatmap: false,
    cluster_claim_allowed: false,
    decision_eligible: false,
    shadow_only: true,
  };
}
