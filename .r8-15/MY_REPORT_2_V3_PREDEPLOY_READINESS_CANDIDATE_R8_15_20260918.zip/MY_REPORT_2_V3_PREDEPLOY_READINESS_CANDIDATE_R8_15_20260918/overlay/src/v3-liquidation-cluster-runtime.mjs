import {updateProjectedClusterLifecycle} from './v3-liquidation-intelligence.mjs';

export const V3_CLUSTER_RUNTIME_VERSION='v3-projected-cluster-lifecycle-shadow-v1';
export const V3_CLUSTER_PERSIST_CAP=12;
function text(v){return v==null?'':String(v).trim();}
function finite(v){if(v==null||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null;}
function bit(v){return v===true?1:v===false?0:null;}
function stablePrice(v){const n=finite(v);return n===null?null:Number(n.toPrecision(12)).toString();}
export function buildProjectedClusterKey({provider,contract,side,level_price}={}){
  const p=text(provider),c=text(contract),s=text(side),l=stablePrice(level_price);
  if(!p||!c||!s||!l)return null;
  return `${p}|${c}|${s}|${l}`;
}
export function compactProjectedClustersForPersistence(clusters,{contract,max=V3_CLUSTER_PERSIST_CAP}={}){
  const c=text(contract);if(!c)return [];
  const seen=new Set(),out=[];
  for(const raw of Array.isArray(clusters)?clusters:[]){
    const level=finite(raw?.level_price);if(level===null||level<=0)continue;
    const key=buildProjectedClusterKey({provider:raw?.provider||'ByKaranteli LiqMap Public API',contract:c,side:raw?.side||'UNKNOWN',level_price:level});
    if(!key||seen.has(key))continue;seen.add(key);
    out.push({...raw,cluster_key:key,level_price:level,provider:raw?.provider||'ByKaranteli LiqMap Public API'});
    if(out.length>=Math.max(1,Math.min(V3_CLUSTER_PERSIST_CAP,Number(max)||V3_CLUSTER_PERSIST_CAP)))break;
  }
  return out;
}
export async function persistProjectedClusterLifecycle(db,{contract,clusters,previous_price=null,current_price=null,oi_change_pct=null,now_ts=Date.now()}={}){
  if(!db?.prepare||!db?.batch)return {status:'SOURCE_UNSUPPORTED',persisted:0};
  const current=compactProjectedClustersForPersistence(clusters,{contract});
  if(!current.length)return {status:'CLOSED_NO_CLUSTERS',persisted:0};
  const placeholders=current.map((_,i)=>`?${i+1}`).join(',');
  let prior=[];
  try{
    const rows=await db.prepare(`SELECT * FROM v3_projected_cluster_lifecycle_shadow WHERE cluster_key IN (${placeholders})`).bind(...current.map(x=>x.cluster_key)).all();
    prior=Array.isArray(rows?.results)?rows.results:[];
  }catch(error){return {status:/no such table/i.test(String(error?.message||error))?'MIGRATION_REQUIRED':'PARTIAL',persisted:0,error:String(error?.message||error)};}
  const priorMap=new Map(prior.map(x=>[x.cluster_key,x]));
  const now=Math.trunc(Number(now_ts)||Date.now());
  const lifecycleRows=[];
  for(const row of current){
    const before=priorMap.get(row.cluster_key)||null;
    const life=updateProjectedClusterLifecycle(before,{...row,last_seen_ts:now},{previous_price,current_price,oi_change_pct});
    if(life.status!=='CLOSED')continue;
    lifecycleRows.push({...row,...life,first_seen_ts:life.first_seen_ts??finite(row.source_ts)??now,last_seen_ts:now});
  }
  const stmts=lifecycleRows.map(r=>db.prepare(`INSERT INTO v3_projected_cluster_lifecycle_shadow(
    cluster_key,contract_code,provider,cluster_type,side,level_price,price_low,price_high,strength,strength_unit,
    distance_pct,significance,first_seen_ts,last_seen_ts,strengthened,weakened,touched,swept,partially_swept,invalidated,
    lifecycle,price_reaction_pct,oi_reaction_pct,provider_source_ts,provider_identity_method,guaranteed_tp,shadow_only)
    VALUES(?1,?2,?3,'PROJECTED_PROVIDER_MAP',?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22,?23,'EXACT_LEVEL_PRICE',0,1)
    ON CONFLICT(cluster_key) DO UPDATE SET
      strength=excluded.strength,strength_unit=excluded.strength_unit,distance_pct=excluded.distance_pct,
      significance=excluded.significance,last_seen_ts=excluded.last_seen_ts,strengthened=excluded.strengthened,
      weakened=excluded.weakened,touched=excluded.touched,swept=excluded.swept,partially_swept=excluded.partially_swept,
      invalidated=excluded.invalidated,lifecycle=excluded.lifecycle,price_reaction_pct=excluded.price_reaction_pct,
      oi_reaction_pct=excluded.oi_reaction_pct,provider_source_ts=excluded.provider_source_ts,guaranteed_tp=0,shadow_only=1`)
    .bind(r.cluster_key,text(contract),r.provider,r.side,r.level_price,finite(r.price_low),finite(r.price_high),finite(r.strength),text(r.strength_unit)||null,
      finite(r.distance_pct),text(r.significance)||null,r.first_seen_ts,r.last_seen_ts,bit(r.strengthened),bit(r.weakened),r.touched?1:0,r.swept?1:0,r.partially_swept?1:0,r.invalidated?1:0,
      text(r.lifecycle)||'ACTIVE',finite(r.price_reaction_pct),finite(r.oi_reaction_pct),finite(r.source_ts)));
  if(!stmts.length)return {status:'CLOSED_NO_VALID_LIFECYCLE',persisted:0};
  try{await db.batch(stmts);}catch(error){return {status:'PARTIAL',persisted:0,error:String(error?.message||error)};}
  return {status:'CLOSED',persisted:stmts.length,rows:lifecycleRows.map(r=>({cluster_key:r.cluster_key,lifecycle:r.lifecycle,swept:r.swept,guaranteed_tp:false})),shadow_only:true};
}
export default {buildProjectedClusterKey,compactProjectedClustersForPersistence,persistProjectedClusterLifecycle};
