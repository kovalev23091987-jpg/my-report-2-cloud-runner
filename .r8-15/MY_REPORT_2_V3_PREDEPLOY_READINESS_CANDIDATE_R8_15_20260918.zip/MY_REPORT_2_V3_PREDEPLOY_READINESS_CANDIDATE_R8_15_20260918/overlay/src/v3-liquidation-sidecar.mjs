import {parseStage0CompactPayload} from './v3-early-discovery.mjs';
import {classifyProjectedProviderMap,buildExtendedLiquidationScan} from './v3-liquidation-intelligence.mjs';
import {persistProjectedClusterLifecycle} from './v3-liquidation-cluster-runtime.mjs';

export const V3_LIQUIDATION_SIDECAR_VERSION='v3-liquidation-intelligence-sidecar-shadow-v2-budget-prefilter';
export const V3_LIQUIDATION_SIDECAR_BUDGET=Object.freeze({
  rows_read:3072,
  rows_written:40,
  requests_soft_cap:16,
  max_observations:3,
  max_clusters_per_contract:12,
});
function finite(v){if(v==null||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null;}
function text(v){return v==null?'':String(v).trim();}
function parseJson(v,fb){try{return JSON.parse(v??JSON.stringify(fb));}catch{return fb;}}
function resultRows(x){return Array.isArray(x?.results)?x.results:[];}
function pct(a,b){const x=finite(a),y=finite(b);return x!==null&&y!==null&&x>0?((y/x)-1)*100:null;}
function usageDelta(before,after){if(!before||!after)return null;return {rows_read:Math.max(0,Number(after.rows_read||0)-Number(before.rows_read||0)),rows_written:Math.max(0,Number(after.rows_written||0)-Number(before.rows_written||0)),requests:Math.max(0,Number(after.requests||0)-Number(before.requests||0)),unknown_ops:Math.max(0,Number(after.unknown_ops||0)-Number(before.unknown_ops||0))};}

export function reconstructProjectedObservationRow(row){
  if(!row||!text(row.contract_code))return null;
  return {
    contract_code:text(row.contract_code),
    observed_ts:finite(row.observed_ts),
    provider:text(row.provider)||'ByKaranteli LiqMap Public API',
    provider_symbol:text(row.provider_symbol),
    asset_identity_verified:Number(row.asset_identity_verified||0)===1,
    projected_map_status:text(row.projected_map_status)||'NOT_CLOSED',
    projected_source_age_sec:finite(row.source_age_sec),
    projected_freshness:text(row.freshness_status)||null,
    projected_clusters:parseJson(row.projected_clusters_json,[]),
    source_health:parseJson(row.source_health_json,{}),
    errors:parseJson(row.errors_json,[]),
  };
}

export function buildLiquidationSidecarPlan({current_snapshot,previous_snapshot,baseline_24h_snapshot,observation_rows=[]}={}){
  const current=current_snapshot?.status==='CLOSED'?current_snapshot:null;
  const prev=previous_snapshot?.status==='CLOSED'?previous_snapshot:null;
  const base24=baseline_24h_snapshot?.status==='CLOSED'?baseline_24h_snapshot:null;
  if(!current)return {status:'CURRENT_SNAPSHOT_NOT_CLOSED',targets:[]};
  const targets=[];
  for(const raw of (Array.isArray(observation_rows)?observation_rows:[]).slice(0,V3_LIQUIDATION_SIDECAR_BUDGET.max_observations)){
    const record=reconstructProjectedObservationRow(raw);if(!record)continue;
    const row=current.rows.get(record.contract_code);if(!row)continue;
    const prior=prev?.rows?.get(record.contract_code)||null;
    const old24=base24?.rows?.get(record.contract_code)||null;
    const currentPrice=finite(row.price);
    const previousPrice=finite(prior?.price);
    const move24=pct(old24?.price,currentPrice);
    const oiChange=pct(prior?.oi_value_usdt,row?.oi_value_usdt);
    const eligibility=classifyProjectedProviderMap(record,{htx_contract:record.contract_code,htx_current_price:currentPrice});
    const extended=buildExtendedLiquidationScan(record,{htx_contract:record.contract_code,htx_current_price:currentPrice,move_24h_pct:move24});
    targets.push({contract:record.contract_code,record,current_price:currentPrice,previous_price:previousPrice,move_24h_pct:move24,oi_change_pct:oiChange,eligibility,extended_scan:extended});
  }
  return {status:'CLOSED',targets,observations_seen:(Array.isArray(observation_rows)?observation_rows.length:0)};
}

async function loadObservationRows(db,{current_scan_ts,now_ts}={}){
  const now=Math.trunc(finite(now_ts)??Date.now());
  const currentTs=Math.trunc(finite(current_scan_ts)??now);
  const q=db.prepare(`SELECT contract_code,observed_ts,provider,provider_symbol,asset_identity_verified,projected_map_status,source_age_sec,freshness_status,projected_clusters_json,source_health_json,errors_json FROM liquidation_shadow_observation WHERE observed_ts BETWEEN ?1 AND ?2 ORDER BY observed_ts DESC LIMIT ${V3_LIQUIDATION_SIDECAR_BUDGET.max_observations}`).bind(currentTs-15*60_000,now+60_000);
  const out=await db.batch([q]);
  return {now,currentTs,observations:resultRows(out?.[0])};
}

async function loadSnapshotInputs(db,{currentTs}={}){
  const q=(target,tol)=>db.prepare(`SELECT ts,payload_json FROM scan_runs WHERE ts BETWEEN ?1 AND ?2 AND stage0_coverage_pct>=99.9 AND errors=0 AND stale=0 ORDER BY ABS(ts-?3) ASC LIMIT 1`).bind(target-tol,target+tol,target);
  const out=await db.batch([
    q(currentTs,5*60_000),
    q(currentTs-5*60_000,5*60_000),
    q(currentTs-24*60*60_000,30*60_000),
  ]);
  const one=(i)=>resultRows(out?.[i])?.[0]||null;
  const parse=(r)=>r?parseStage0CompactPayload(r.payload_json,r.ts):null;
  return {current:parse(one(0)),previous:parse(one(1)),baseline24:parse(one(2))};
}

function preclassifyObservationRows(rows=[]){
  const targets=[];
  for(const raw of Array.isArray(rows)?rows:[]){
    const record=reconstructProjectedObservationRow(raw);if(!record)continue;
    const eligibility=classifyProjectedProviderMap(record,{htx_contract:record.contract_code,htx_current_price:null});
    targets.push({contract:record.contract_code,record,eligibility});
  }
  return targets;
}

export async function runV3LiquidationIntelligenceSidecar(db,{current_scan_ts,source_run_id=null,now_ts=Date.now()}={}){
  const base={version:V3_LIQUIDATION_SIDECAR_VERSION,mode:'SHADOW_ONLY',source_run_id:text(source_run_id)||null,probability:null,validated_signal:false,trading_execution:false,guaranteed_tp:false};
  if(!db?.prepare||!db?.batch)return {...base,status:'SOURCE_UNSUPPORTED',persisted:0};
  const before=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;
  let observed;
  try{observed=await loadObservationRows(db,{current_scan_ts,now_ts});}
  catch(error){const msg=String(error?.message||error);return {...base,status:/no such table/i.test(msg)?'MIGRATION_OR_SOURCE_TABLE_REQUIRED':'INPUT_LOAD_PARTIAL',persisted:0,error:msg};}
  const preliminary=preclassifyObservationRows(observed.observations);
  if(!preliminary.length){
    const after=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;
    return {...base,status:'CLOSED_NO_LIQUIDATION_OBSERVATION',observations_seen:0,persisted:0,usage_delta:usageDelta(before,after)};
  }
  if(preliminary.every(x=>x.eligibility.status!=='CLOSED_SHADOW')){
    const after=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;
    const delta=usageDelta(before,after);
    const targets=preliminary.map(x=>({contract:x.contract,status:'PROJECTED_PROVIDER_NOT_CLOSED',reasons:x.eligibility.reasons,extended_scan_status:'NOT_EVALUATED_PROVIDER_NOT_CLOSED',persisted:0}));
    return {...base,status:'CLOSED_OBSERVATION_ONLY_IDENTITY_NOT_CLOSED',observations_seen:preliminary.length,targets,persisted:0,usage_delta:delta,provider_prefilter_short_circuit:true};
  }
  let snapshots;
  try{snapshots=await loadSnapshotInputs(db,{currentTs:observed.currentTs});}
  catch(error){const msg=String(error?.message||error);return {...base,status:'SNAPSHOT_INPUT_LOAD_PARTIAL',persisted:0,error:msg};}
  const plan=buildLiquidationSidecarPlan({current_snapshot:snapshots.current,previous_snapshot:snapshots.previous,baseline_24h_snapshot:snapshots.baseline24,observation_rows:observed.observations});
  if(plan.status!=='CLOSED')return {...base,status:plan.status,persisted:0};
  const results=[];
  for(const t of plan.targets){
    if(t.eligibility.status!=='CLOSED_SHADOW'){
      results.push({contract:t.contract,status:'PROJECTED_PROVIDER_NOT_CLOSED',reasons:t.eligibility.reasons,extended_scan_status:t.extended_scan.status,persisted:0});
      continue;
    }
    const write=await persistProjectedClusterLifecycle(db,{contract:t.contract,clusters:t.record.projected_clusters,previous_price:t.previous_price,current_price:t.current_price,oi_change_pct:t.oi_change_pct,now_ts});
    results.push({contract:t.contract,status:write.status,extended_scan_status:t.extended_scan.status,far_huge_clusters:Array.isArray(t.extended_scan?.far_huge_clusters)?t.extended_scan.far_huge_clusters.length:0,persisted:Number(write.persisted||0),guaranteed_tp:false});
  }
  const after=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;
  const delta=usageDelta(before,after);
  if(delta&&(delta.rows_read>V3_LIQUIDATION_SIDECAR_BUDGET.rows_read||delta.rows_written>V3_LIQUIDATION_SIDECAR_BUDGET.rows_written||delta.unknown_ops>0))return {...base,status:'BUDGET_ENVELOPE_EXCEEDED_FAIL_CLOSED',persisted:results.reduce((n,x)=>n+Number(x.persisted||0),0),usage_delta:delta,targets:results};
  const persisted=results.reduce((n,x)=>n+Number(x.persisted||0),0);
  const blocked=results.filter(x=>x.status==='PROJECTED_PROVIDER_NOT_CLOSED').length;
  return {...base,status:results.length?(blocked===results.length?'CLOSED_OBSERVATION_ONLY_IDENTITY_NOT_CLOSED':'CLOSED'):'CLOSED_NO_LIQUIDATION_OBSERVATION',observations_seen:plan.observations_seen,targets:results,persisted,usage_delta:delta};
}

export default {V3_LIQUIDATION_SIDECAR_VERSION,V3_LIQUIDATION_SIDECAR_BUDGET,reconstructProjectedObservationRow,buildLiquidationSidecarPlan,runV3LiquidationIntelligenceSidecar};
