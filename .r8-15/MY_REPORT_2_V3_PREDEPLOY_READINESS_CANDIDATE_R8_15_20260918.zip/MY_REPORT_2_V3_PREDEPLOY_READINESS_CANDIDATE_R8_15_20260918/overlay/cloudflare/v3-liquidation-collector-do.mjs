import {
  buildDurableCollectorProbeConfig,initialDurableProbeState,durableProbeTransition,
  normalizeDurableCollectorFrame,buildProbeSubscribeFrames,V3_DO_PROBE_MAX_RUNTIME_MS,
} from '../src/v3-collector-do-core.mjs';

const CONFIG_KEY='v3_probe_config';
const STATE_KEY='v3_probe_state';

function jsonResponse(value,status=200){return new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json; charset=utf-8'}});}
function safeJson(text){try{return JSON.parse(String(text));}catch{return null;}}

export class V3LiquidationCollectorProbe {
  constructor(ctx,env){this.ctx=ctx;this.env=env;this.ws=null;}

  async fetch(request){
    const url=new URL(request.url);
    if(url.pathname.endsWith('/start') && request.method==='POST'){
      const body=await request.json().catch(()=>null);
      if(!body||body.continuous===true)return jsonResponse({status:'CONTINUOUS_MODE_FORBIDDEN_UNTIL_COST_ENDURANCE_PROOF'},409);
      const config=buildDurableCollectorProbeConfig({...body,websocket_header_capable:true,now_ts:Date.now()});
      if(config.probe_status!=='READY')return jsonResponse(config,409);
      let state=initialDurableProbeState(config);
      await this.ctx.storage.put(CONFIG_KEY,config);await this.ctx.storage.put(STATE_KEY,state);
      await this.connect(config,state);
      return jsonResponse({status:'PROBE_STARTED',venue:config.plan.venue,stop_ts:config.stop_ts,max_runtime_ms:V3_DO_PROBE_MAX_RUNTIME_MS,production_enabled:false});
    }
    if(url.pathname.endsWith('/status')){
      const [config,state]=await Promise.all([this.ctx.storage.get(CONFIG_KEY),this.ctx.storage.get(STATE_KEY)]);
      return jsonResponse({config:config||null,state:state||null,production_enabled:false});
    }
    if(url.pathname.endsWith('/stop') && request.method==='POST'){
      await this.stopProbe('MANUAL_STOP');
      return jsonResponse({status:'STOPPED',production_enabled:false});
    }
    return jsonResponse({status:'NOT_FOUND'},404);
  }

  async openSocket(config){
    const headers={Upgrade:'websocket'};
    if(config.plan.venue==='GATE')headers['X-Gate-Size-Decimal']='1';
    const response=await fetch(config.plan.url,{headers});
    if(!response.webSocket)throw new Error(`WEBSOCKET_UPGRADE_REJECTED:${response.status}`);
    const ws=response.webSocket;ws.accept();return ws;
  }

  async connect(config,state){
    if(Date.now()>=Number(config.stop_ts))return this.stopProbe('BOUND_REACHED_BEFORE_CONNECT');
    let ws;
    try{ws=await this.openSocket(config);}catch(error){
      state=durableProbeTransition(state,{type:'ERROR',now_ts:Date.now(),error:String(error?.message||error)});
      state=durableProbeTransition(state,{type:'DISCONNECTED',now_ts:Date.now(),error:String(error?.message||error)});
      await this.persistStateAndAlarm(state);return;
    }
    this.ws=ws;
    state=durableProbeTransition(state,{type:'CONNECTED',now_ts:Date.now()});
    await this.ctx.storage.put(STATE_KEY,state);
    await this.ctx.storage.setAlarm(Number(config.stop_ts));
    for(const frame of buildProbeSubscribeFrames(config))ws.send(JSON.stringify(frame));
    ws.addEventListener('message',(event)=>this.ctx.waitUntil(this.onMessage(event)));
    ws.addEventListener('error',(event)=>this.ctx.waitUntil(this.onSocketEnd('ERROR',event?.message||'WEBSOCKET_ERROR')));
    ws.addEventListener('close',(event)=>this.ctx.waitUntil(this.onSocketEnd('DISCONNECTED',`WS_CLOSE:${event?.code??'UNKNOWN'}`)));
  }

  async onMessage(event){
    const [config,state0]=await Promise.all([this.ctx.storage.get(CONFIG_KEY),this.ctx.storage.get(STATE_KEY)]);
    if(!config||!state0)return;
    const msg=safeJson(event?.data);if(!msg){const state=durableProbeTransition(state0,{type:'ERROR',now_ts:Date.now(),error:'JSON_PARSE_ERROR',parse_error:true});await this.ctx.storage.put(STATE_KEY,state);return;}
    const norm=normalizeDurableCollectorFrame({config,message:msg,received_ts:Date.now()});
    const exchangeTs=norm.events.reduce((m,e)=>Math.max(m,Number(e?.ts_exchange||0)),0)||null;
    const state=durableProbeTransition(state0,{type:'MESSAGE',now_ts:Date.now(),exchange_ts:exchangeTs,normalized_events:norm.normalized_count,dropped:norm.dropped_count,parse_errors:0,schema_errors:norm.status==='SOURCE_SCHEMA_UNVERIFIED'?1:0,identity_errors:norm.errors.filter(x=>String(x).startsWith('IDENTITY_')).length});
    await this.ctx.storage.put(STATE_KEY,state);
  }

  async onSocketEnd(type,error){
    const [config,state0]=await Promise.all([this.ctx.storage.get(CONFIG_KEY),this.ctx.storage.get(STATE_KEY)]);if(!config||!state0)return;
    let state=durableProbeTransition(state0,{type:type==='ERROR'?'ERROR':'DISCONNECTED',now_ts:Date.now(),error});
    if(type==='ERROR')state=durableProbeTransition(state,{type:'DISCONNECTED',now_ts:Date.now(),error});
    await this.persistStateAndAlarm(state);
  }

  async persistStateAndAlarm(state){await this.ctx.storage.put(STATE_KEY,state);if(state.next_action_ts!=null)await this.ctx.storage.setAlarm(Number(state.next_action_ts));}

  async alarm(){
    const [config,state0]=await Promise.all([this.ctx.storage.get(CONFIG_KEY),this.ctx.storage.get(STATE_KEY)]);if(!config||!state0)return;
    const now=Date.now();
    if(now>=Number(config.stop_ts)||state0.next_action==='STOP')return this.stopProbe('BOUND_REACHED');
    if(state0.next_action==='RECONNECT')return this.connect(config,state0);
    await this.ctx.storage.setAlarm(Number(config.stop_ts));
  }

  async stopProbe(reason){
    const state0=await this.ctx.storage.get(STATE_KEY);if(!state0)return;
    try{this.ws?.close(1000,String(reason||'STOP').slice(0,120));}catch{}
    const state=durableProbeTransition(state0,{type:'STOP',now_ts:Date.now()});state.stop_reason=reason||'STOP';
    await this.ctx.storage.put(STATE_KEY,state);await this.ctx.storage.deleteAlarm();this.ws=null;
  }
}

function constantTimeTextEqual(a,b){
  const enc=new TextEncoder(),x=enc.encode(String(a??'')),y=enc.encode(String(b??''));
  const n=Math.max(x.length,y.length);let diff=x.length^y.length;
  for(let i=0;i<n;i++)diff|=(x[i]??0)^(y[i]??0);
  return diff===0&&x.length>0;
}

export default {
  async fetch(request,env){
    const expected=String(env?.V3_PROBE_KEY||'');
    if(!expected)return jsonResponse({status:'PROBE_KEY_NOT_CONFIGURED',production_enabled:false},503);
    const supplied=request.headers.get('x-report2-v3-probe-key')||'';
    if(!constantTimeTextEqual(expected,supplied))return jsonResponse({status:'PROBE_AUTH_REQUIRED',production_enabled:false},403);
    if(!env?.LIQ_PROBE?.getByName)return jsonResponse({status:'DURABLE_OBJECT_BINDING_MISSING',production_enabled:false},503);
    const url=new URL(request.url);
    const m=url.pathname.match(/^\/v3-liquidation-probe\/(bybit|gate|binance)\/(start|status|stop)$/i);
    if(!m)return jsonResponse({status:'PROBE_ROUTE_NOT_FOUND',production_enabled:false},404);
    const venue=m[1].toUpperCase(),action=m[2].toLowerCase();
    const stub=env.LIQ_PROBE.getByName(`v3-liquidation-probe:${venue}`);
    const target=new URL(request.url);target.pathname=`/${action}`;
    const forwarded=new Request(target.toString(),request);
    return stub.fetch(forwarded);
  }
};
