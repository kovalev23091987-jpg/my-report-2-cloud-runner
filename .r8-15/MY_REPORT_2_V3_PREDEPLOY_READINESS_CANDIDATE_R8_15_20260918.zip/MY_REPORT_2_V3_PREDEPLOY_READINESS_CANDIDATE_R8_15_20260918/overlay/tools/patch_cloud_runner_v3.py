#!/usr/bin/env python3
import argparse, hashlib, pathlib, shutil, re

RUNNER_BLOB_SHA='064275879c4e23b841907b9b6a25e567e717bd2e'
WORKFLOW_BLOB_SHA='b1369dde068c609a715938408f2e23802f9661b8'
NEW_RUNNER_VERSION='my-report-2-github-cloud-runner-v4.12.0-v3-telegram-journal-gated-delivery'

def git_blob_sha(data: bytes):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def replace_once(text, old, new, label):
    n=text.count(old)
    if n!=1: raise RuntimeError(f'{label}_ANCHOR_COUNT_{n}')
    return text.replace(old,new,1)

def patch_runner_text(text):
    text=replace_once(text,
'''import { classifyZeroTelegram } from "./telegram-zero-reason.mjs";''',
'''import { classifyZeroTelegram } from "./telegram-zero-reason.mjs";
import { runV3EarlyPersistenceSidecar, V3_EARLY_SIDECAR_BUDGET } from "./src/v3-early-sidecar.mjs";
import { runV3RealizedLiquidationSidecar, V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET } from "./src/v3-realized-liquidation-sidecar.mjs";
import { runV3LiquidationIntelligenceSidecar, V3_LIQUIDATION_SIDECAR_BUDGET } from "./src/v3-liquidation-sidecar.mjs";
import { runV3PipelineHealthSidecar, V3_PIPELINE_HEALTH_SIDECAR_BUDGET } from "./src/v3-pipeline-health-sidecar.mjs";
import { runV3TelegramLifecycleSidecar, V3_TELEGRAM_LIFECYCLE_SIDECAR_BUDGET } from "./src/v3-telegram-lifecycle-sidecar.mjs";
import { runV3TelegramDeliverySidecar, V3_TELEGRAM_DELIVERY_SIDECAR_BUDGET } from "./src/v3-telegram-delivery-sidecar.mjs";''','V3_IMPORT')
    text=replace_once(text,
'''const RUNNER_VERSION = "my-report-2-github-cloud-runner-v4.7.3-telegram-watch70-tree-guard";''',
 f'''const RUNNER_VERSION = "{NEW_RUNNER_VERSION}";''','RUNNER_VERSION')
    text=replace_once(text,
'''const cron = await env.DATA_DB.prepare("SELECT run_id,scheduled_time,started_ts,completed_ts,status,universe_total,scanned,persistence_status,error_text FROM cron_runs WHERE scheduled_time = ?1 ORDER BY started_ts DESC LIMIT 1").bind(started).first();''',
'''const cron = await env.DATA_DB.prepare("SELECT run_id,scheduled_time,started_ts,completed_ts,status,universe_total,scanned,persistence_status,error_text,v3_discovery_shortlist_count,v3_live_shortlist_count,v3_live_deep_check_count,v3_live_zero_reason,v3_pipeline_health_status,v3_pipeline_health_reason,v3_live_lane,v3_maintenance_deferred FROM cron_runs WHERE scheduled_time = ?1 ORDER BY started_ts DESC LIMIT 1").bind(started).first();''','V3_CRON_TELEMETRY_SELECT')
    old='''  assertClosedCron(cron, scan);
  const telegramObserver = await observeNaturalTelegramDecision(env.DATA_DB);'''
    new='''  assertClosedCron(cron, scan);
  // V3 Telegram journal may persist state before network delivery is enabled.
  // Network delivery itself remains fail-closed until the dedicated env gate is on.
  const v3TelegramJournalEnabled = ["1","true","yes","on"].includes(String(process.env.REPORT2_V3_TELEGRAM_JOURNAL_ENABLED || "0").trim().toLowerCase());
  const v3TelegramNetworkRequested = ["1","true","yes","on"].includes(String(process.env.REPORT2_V3_TELEGRAM_NETWORK_ENABLED || "0").trim().toLowerCase());
  const v3LegacyTelegramOutputEnabled = ["1","true","yes","on"].includes(String(process.env.REPORT2_TELEGRAM_OUTPUT_ENABLED || "0").trim().toLowerCase());
  const v3TelegramNetworkEnabled = v3TelegramNetworkRequested && v3LegacyTelegramOutputEnabled;
  // V3 SHADOW sidecars share one conservative pre-action envelope. The envelope
  // includes Telegram's existing reserve, so data/health persistence can never
  // consume the final-notification budget.
  const v3SidecarsPreactionBudget = evaluateWithinRunReservation({
    reservation:d1RunReservation,
    currentUsage:env.DATA_DB.usageSnapshot(),
    extraRowsRead:V3_EARLY_SIDECAR_BUDGET.rows_read + V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.rows_read + V3_LIQUIDATION_SIDECAR_BUDGET.rows_read + V3_PIPELINE_HEALTH_SIDECAR_BUDGET.rows_read + V3_TELEGRAM_LIFECYCLE_SIDECAR_BUDGET.rows_read + (v3TelegramNetworkEnabled ? V3_TELEGRAM_DELIVERY_SIDECAR_BUDGET.rows_read : 0) + 64,
    extraRowsWritten:V3_EARLY_SIDECAR_BUDGET.rows_written + V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.rows_written + V3_LIQUIDATION_SIDECAR_BUDGET.rows_written + V3_PIPELINE_HEALTH_SIDECAR_BUDGET.rows_written + V3_TELEGRAM_LIFECYCLE_SIDECAR_BUDGET.rows_written + (v3TelegramNetworkEnabled ? V3_TELEGRAM_DELIVERY_SIDECAR_BUDGET.rows_written : 0) + 41,
  });
  const v3Blocked = (version) => ({version,mode:"SHADOW_ONLY",status:"BUDGET_BLOCKED_FAIL_CLOSED",persisted:0,reasons:v3SidecarsPreactionBudget.reasons||[],probability:null,validated_signal:false,trading_execution:false});
  let v3EarlySidecar;
  let v3RealizedLiquidationSidecar;
  let v3LiquidationSidecar;
  if (!v3SidecarsPreactionBudget.allowed) {
    v3EarlySidecar = v3Blocked("v3-early-sidecar-shadow-v1");
    v3RealizedLiquidationSidecar = v3Blocked("v3-realized-liquidation-sidecar-shadow-v1");
    v3LiquidationSidecar = v3Blocked("v3-liquidation-intelligence-sidecar-shadow-v1");
  } else {
    v3EarlySidecar = await runV3EarlyPersistenceSidecar(env.DATA_DB, {
      current_scan_ts:Number(scan.ts), source_run_id:String(cron.run_id || ""), now_ts:started,
    });
    v3RealizedLiquidationSidecar = await runV3RealizedLiquidationSidecar(env.DATA_DB, {
      current_scan_ts:Number(scan.ts), source_run_id:String(cron.run_id || ""), now_ts:started,
    });
    v3LiquidationSidecar = await runV3LiquidationIntelligenceSidecar(env.DATA_DB, {
      current_scan_ts:Number(scan.ts), source_run_id:String(cron.run_id || ""), now_ts:started,
    });
  }
  console.log("V3_EARLY_PERSISTENCE_SIDECAR", JSON.stringify(v3EarlySidecar));
  console.log("V3_REALIZED_LIQUIDATION_SIDECAR", JSON.stringify(v3RealizedLiquidationSidecar));
  console.log("V3_LIQUIDATION_INTELLIGENCE_SIDECAR", JSON.stringify(v3LiquidationSidecar));
  const telegramObserver = await observeNaturalTelegramDecision(env.DATA_DB);'''
    text=replace_once(text,old,new,'V3_SIDECAR_CALL')
    text=replace_once(text,
'''    enabled: envText("REPORT2_TELEGRAM_OUTPUT_ENABLED", { required: false }),''',
'''    // V3 network delivery supersedes legacy final-chain output to prevent duplicate ENTRY.
    // R8 ships with V3 network OFF, so legacy production behavior is unchanged initially.
    enabled: v3TelegramNetworkEnabled ? "0" : envText("REPORT2_TELEGRAM_OUTPUT_ENABLED", { required: false }),''','V3_LEGACY_TELEGRAM_SUPPRESSION')
    text=replace_once(text,
'''  const telegramZeroReason = classifyZeroTelegram({ preBudget:d1PreTelegramBudget, telegramObserver, telegramOutput });''',
'''  const telegramZeroReason = classifyZeroTelegram({ preBudget:d1PreTelegramBudget, telegramObserver, telegramOutput });
  const v3RealizedFeedStatus = String(v3RealizedLiquidationSidecar?.status || "UNKNOWN").toUpperCase();
  const v3ProjectedFeedStatus = String(v3LiquidationSidecar?.status || "UNKNOWN").toUpperCase();
  const v3CriticalFeedState = (v3RealizedFeedStatus.startsWith("CLOSED") && v3ProjectedFeedStatus.startsWith("CLOSED")) ? "OK" : "UNAVAILABLE";
  let v3PipelineHealthSidecar;
  if (!v3SidecarsPreactionBudget.allowed) {
    v3PipelineHealthSidecar = {version:"v3-pipeline-health-sidecar-shadow-v1",mode:"SHADOW_ONLY",status:"BUDGET_BLOCKED_FAIL_CLOSED",market_signal:false,reasons:v3SidecarsPreactionBudget.reasons||[]};
  } else {
    v3PipelineHealthSidecar = await runV3PipelineHealthSidecar(env.DATA_DB, {cron,scan,telegram_zero_reason:telegramZeroReason,critical_feed_state:v3CriticalFeedState,now_ts:Date.now()});
  }
  console.log("V3_PIPELINE_HEALTH_SIDECAR", JSON.stringify(v3PipelineHealthSidecar));
  let v3TelegramLifecycleSidecar;
  if (!v3SidecarsPreactionBudget.allowed) {
    v3TelegramLifecycleSidecar = {version:"v3-telegram-lifecycle-sidecar-shadow-v1",mode:"SHADOW_ONLY",status:"BUDGET_BLOCKED_FAIL_CLOSED",network_send:false,dispatch_enabled:v3TelegramJournalEnabled,reasons:v3SidecarsPreactionBudget.reasons||[]};
  } else {
    v3TelegramLifecycleSidecar = await runV3TelegramLifecycleSidecar(env.DATA_DB, {
      source_run_id:String(cron.run_id || ""), now_ts:Date.now(),
      d1_pretelegram_budget_closed:d1PreTelegramBudget.allowed, dispatch_enabled:v3TelegramJournalEnabled,
    });
  }
  console.log("V3_TELEGRAM_LIFECYCLE_SIDECAR", JSON.stringify(v3TelegramLifecycleSidecar));
  let v3TelegramDeliverySidecar;
  if (!v3SidecarsPreactionBudget.allowed || !d1PreTelegramBudget.allowed) {
    v3TelegramDeliverySidecar = {version:"v3-telegram-delivery-sidecar-shadow-v1",mode:"SHADOW_GATED_DELIVERY",status:"BUDGET_BLOCKED_FAIL_CLOSED",network_send:false,sent:0,reasons:[...(v3SidecarsPreactionBudget.reasons||[]),...(d1PreTelegramBudget.reasons||[])]};
  } else {
    v3TelegramDeliverySidecar = await runV3TelegramDeliverySidecar(env.DATA_DB, {
      enabled:v3TelegramNetworkEnabled,
      relay_url:envText("REPORT2_TELEGRAM_RELAY_URL", { required: false }),
      relay_key:envText("REPORT2_TELEGRAM_RELAY_KEY", { required: false }),
      now_ts:Date.now(), fetch_impl:nativeFetch,
    });
  }
  console.log("V3_TELEGRAM_DELIVERY_SIDECAR", JSON.stringify(v3TelegramDeliverySidecar));''','V3_PIPELINE_HEALTH_CALL')
    text=replace_once(text,
'''telegram_observer:telegramObserver, discovery_recall_kpi:discoveryRecallKpi, telegram_output:telegramOutput''',
'''telegram_observer:telegramObserver, v3_sidecars_preaction_budget:v3SidecarsPreactionBudget, v3_early_sidecar:v3EarlySidecar, v3_realized_liquidation_sidecar:v3RealizedLiquidationSidecar, v3_liquidation_sidecar:v3LiquidationSidecar, v3_critical_feed_state:v3CriticalFeedState, v3_pipeline_health_sidecar:v3PipelineHealthSidecar, v3_telegram_lifecycle_sidecar:v3TelegramLifecycleSidecar, v3_telegram_delivery_sidecar:v3TelegramDeliverySidecar, v3_telegram_journal_enabled:v3TelegramJournalEnabled, v3_telegram_network_enabled:v3TelegramNetworkEnabled, discovery_recall_kpi:discoveryRecallKpi, telegram_output:telegramOutput''','V3_FINAL_TELEMETRY')
    return text

def patch_workflow_text(text, worker_sha):
    sha=worker_sha.lower().strip()
    if len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha): raise RuntimeError('WORKER_SHA_INVALID')
    text,n=re.subn(r'REPORT2_EXPECTED_WORKER_SHA: "[0-9a-f]{64}"',f'REPORT2_EXPECTED_WORKER_SHA: "{sha}"',text,count=1)
    if n!=1: raise RuntimeError(f'WORKFLOW_WORKER_SHA_ANCHOR_COUNT_{n}')
    text=replace_once(text,
'''      telegram_report_test:
        description: "send one compact Telegram report test"
        required: false
        type: boolean
        default: false

permissions:''',
'''      telegram_report_test:
        description: "send one compact Telegram report test"
        required: false
        type: boolean
        default: false
      controlled_no_telegram:
        description: "controlled smoke with Telegram fully disabled"
        required: false
        type: boolean
        default: false

permissions:''','WORKFLOW_CONTROLLED_NO_TELEGRAM_INPUT')
    text=replace_once(text,
'''      REPORT2_TELEGRAM_OUTPUT_ENABLED: "1"''',
'''      REPORT2_TELEGRAM_OUTPUT_ENABLED: ${{ github.event_name == 'workflow_dispatch' && inputs.controlled_no_telegram == true && '0' || '1' }}
      REPORT2_V3_TELEGRAM_JOURNAL_ENABLED: "1"
      REPORT2_V3_TELEGRAM_NETWORK_ENABLED: "0"''','WORKFLOW_CONTROLLED_NO_TELEGRAM_ENV')
    # V3 source modules are part of the encrypted candidate payload itself.
    # The public cloud-runner repository intentionally has no root src/ tree, so
    # production workflow must NOT copy src/v3-* from the repository checkout.
    return text

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('repo')
    ap.add_argument('--worker-sha',required=True)
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--emit-dir')
    a=ap.parse_args()
    repo=pathlib.Path(a.repo).resolve()
    runner=repo/'runner/runner-main.mjs'; workflow=repo/'.github/workflows/report2.yml'
    rb=runner.read_bytes(); wb=workflow.read_bytes()
    rsha=git_blob_sha(rb); wsha=git_blob_sha(wb)
    if rsha!=RUNNER_BLOB_SHA: raise SystemExit(f'RUNNER_MAIN_GIT_BLOB_SHA_MISMATCH:{rsha}')
    if wsha!=WORKFLOW_BLOB_SHA: raise SystemExit(f'WORKFLOW_GIT_BLOB_SHA_MISMATCH:{wsha}')
    rt=patch_runner_text(rb.decode()); wt=patch_workflow_text(wb.decode(),a.worker_sha)
    if a.dry_run:
        print('V3_RUNNER_PATCH_GUARDS=PASS')
        print('V3_RUNNER_PATCH=READY')
        print('V3_WORKFLOW_PATCH=READY')
        print('PRODUCTION_CHANGED=NO')
        return
    if a.emit_dir:
        out=pathlib.Path(a.emit_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
        (out/'runner-main.mjs').write_text(rt)
        (out/'report2.yml').write_text(wt)
        print('V3_RUNNER_PATCH_GUARDS=PASS')
        print(f'V3_PATCH_EMIT_DIR={out}')
        print('PRODUCTION_CHANGED=NO')
        return
    shutil.copy2(runner,runner.with_suffix('.mjs.BACKUP-before-v3'))
    shutil.copy2(workflow,workflow.with_suffix('.yml.BACKUP-before-v3'))
    runner.write_text(rt); workflow.write_text(wt)
    print('V3_PATCH_APPLIED_LOCAL_ONLY')
    print('PRODUCTION_CHANGED=NO')

if __name__=='__main__': main()
