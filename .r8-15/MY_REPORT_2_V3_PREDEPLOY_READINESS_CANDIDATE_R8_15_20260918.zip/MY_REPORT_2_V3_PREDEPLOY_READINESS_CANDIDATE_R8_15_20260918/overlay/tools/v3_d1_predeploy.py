#!/usr/bin/env python3
"""MY_REPORT_2 V3 remote D1 predeploy migration gate.

Default mode is read-only check. --apply requires a successful Node24 readiness proof.
No Worker deploy, Telegram send, strategy change, or automatic Time Travel restore.
"""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, re, shlex, sqlite3, subprocess, sys, tempfile, time

CANDIDATE_WORKER_SHA = "72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c"
DB_BINDING = "DATA_DB"
MIGRATIONS = [
    ("20260917_v3_data_plane_shadow.sql", "ab518bc6fde8e3a61bb589ece9530acef4f5f0f49504b491acbb1ce8ab40e249"),
    ("20260917_v3_early_discovery_shadow.sql", "9dadc72e3b5905285b64fc93239d543fe21529dd4477339535970d2f7249889e"),
    ("20260917_v3_live_handoff_shadow.sql", "8e602f2bc846a7d321f94620d9152f52b0c078b05a34a08b76d21d62bc241dc2"),
    ("20260917_v3_live_handoff_wiring_shadow.sql", "1ef8b2487223b75cc189b9a60078e9c90d948e6994c9139270ae791d24dfc256"),
    ("20260917_v3_telegram_lifecycle_shadow.sql", "7a4e2659387cb39b829a6646f1f2793ac89cd50ba299df529d0a2fabfa62dbb0"),
    ("20260917_v3_cron_pipeline_telemetry_shadow.sql", "a74e24a34f86795930b20cf84995f6741b1abc37f8420296318c4ad551eb4bb0"),
]

GROUPS = {
 "20260917_v3_data_plane_shadow.sql": {
   "tables": ["v3_source_health_1m","v3_realized_liquidation_aggregate","v3_realized_liquidation_density_5m","v3_projected_cluster_lifecycle_shadow","v3_market_microstructure_1m"],
   "indexes": ["idx_v3_source_health_venue_ts","idx_v3_realized_liq_contract_ts","idx_v3_realized_density_contract_ts","idx_v3_projected_cluster_contract_seen","idx_v3_market_micro_contract_ts"],
 },
 "20260917_v3_early_discovery_shadow.sql": {
   "tables": ["v3_early_feature_snapshot","v3_early_candidate_wave","v3_early_outcome_journal"],
   "indexes": ["idx_v3_early_feature_ts","idx_v3_early_candidate_contract_seen","idx_v3_early_outcome_due"],
 },
 "20260917_v3_live_handoff_shadow.sql": {
   "tables": ["v3_discovery_deep_handoff_shadow"],
   "indexes": ["idx_v3_handoff_pending","idx_v3_handoff_contract","idx_v3_handoff_wave"],
 },
 "20260917_v3_live_handoff_wiring_shadow.sql": {
   "columns": {
      "deep_check_scheduler_state": ["v3_handoff_id","v3_handoff_logical_key","v3_scan_ts","v3_base_ticker","v3_discovery_rank","v3_detectors_json","v3_evidence_ids_json","v3_first_seen_state_json","v3_current_state_json","v3_direction","v3_wave_id","v3_dedup_reentry_key"],
      "deep_check_run_log": ["v3_handoff_id","v3_handoff_logical_key","v3_scan_ts","v3_base_ticker","v3_discovery_rank","v3_detectors_json","v3_evidence_ids_json","v3_first_seen_state_json","v3_current_state_json","v3_direction","v3_wave_id","v3_dedup_reentry_key"],
   },
   "indexes": ["idx_deep_check_scheduler_v3_handoff","idx_deep_check_run_log_v3_handoff"],
   "triggers": ["trg_v3_handoff_scheduler_insert_claim","trg_v3_handoff_scheduler_update_claim","trg_v3_handoff_scheduler_finalize"],
 },
 "20260917_v3_telegram_lifecycle_shadow.sql": {
   "tables": ["v3_user_lifecycle_shadow","v3_telegram_dispatch_shadow","v3_pipeline_health_shadow","v3_pipeline_health_event_shadow"],
   "indexes": ["idx_v3_dispatch_state_ts","idx_v3_dispatch_wave","idx_v3_pipeline_health_event_state"],
 },
 "20260917_v3_cron_pipeline_telemetry_shadow.sql": {
   "columns": {"cron_runs": ["v3_discovery_shortlist_count","v3_live_shortlist_count","v3_live_deep_check_count","v3_live_zero_reason","v3_pipeline_health_status","v3_pipeline_health_reason","v3_live_lane","v3_maintenance_deferred"]},
 },
}
BASE_TABLES = ["cron_runs","deep_check_scheduler_state","deep_check_run_log"]


def sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def migration_root() -> pathlib.Path:
    here = pathlib.Path(__file__).resolve().parent.parent
    return here / "migrations"


def verify_migration_bytes(root: pathlib.Path) -> None:
    for name, expected in MIGRATIONS:
        p = root / name
        if not p.is_file(): raise RuntimeError(f"MIGRATION_MISSING:{name}")
        got = sha256(p)
        if got != expected: raise RuntimeError(f"MIGRATION_SHA_MISMATCH:{name}:{got}")
        sql = p.read_text(encoding="utf-8")
        upper = sql.upper()
        for token in ["DROP TABLE", "DROP COLUMN", "DELETE FROM", "VACUUM", "REPLACE INTO"]:
            if token in upper: raise RuntimeError(f"NON_ADDITIVE_TOKEN:{name}:{token}")


def obj_names_sql(names):
    return ",".join("'" + n.replace("'","''") + "'" for n in names)


class LocalInspector:
    def __init__(self, con): self.con = con
    def objects(self, names):
        if not names: return set()
        q=f"SELECT name FROM sqlite_master WHERE name IN ({obj_names_sql(names)})"
        return {r[0] for r in self.con.execute(q)}
    def columns(self, table):
        try: return {r[1] for r in self.con.execute(f'PRAGMA table_info("{table}")')}
        except sqlite3.DatabaseError: return set()


class RemoteInspector:
    def __init__(self, repo: pathlib.Path):
        self.repo=repo
        local=repo/"node_modules/.bin/wrangler"
        self.prefix=[str(local)] if local.exists() else ["npx","--no-install","wrangler"]
    def _run(self, args, *, timeout=90):
        cmd=self.prefix+args
        p=subprocess.run(cmd,cwd=self.repo,text=True,capture_output=True,timeout=timeout)
        if p.returncode != 0:
            raise RuntimeError("WRANGLER_FAIL:"+" ".join(shlex.quote(x) for x in args)+"\n"+(p.stderr or p.stdout)[-3000:])
        return p.stdout.strip()
    @staticmethod
    def _json(text):
        text=text.strip()
        try: return json.loads(text)
        except Exception:
            # tolerate non-JSON prelude; choose last valid JSON array/object start
            starts=[i for i,c in enumerate(text) if c in '[{']
            for i in starts:
                try: return json.loads(text[i:])
                except Exception: pass
            raise RuntimeError("WRANGLER_JSON_PARSE_FAIL")
    def execute(self, sql):
        data=self._json(self._run(["d1","execute",DB_BINDING,"--remote","--json","--command",sql]))
        if isinstance(data,dict): data=[data]
        rows=[]
        for part in data or []:
            if not part.get("success",True): raise RuntimeError("D1_QUERY_NOT_SUCCESS")
            rows.extend(part.get("results") or [])
        return rows
    def objects(self,names):
        if not names:return set()
        rows=self.execute(f"SELECT name FROM sqlite_master WHERE name IN ({obj_names_sql(names)})")
        return {str(r.get('name')) for r in rows if r.get('name') is not None}
    def columns(self,table):
        rows=self.execute(f'PRAGMA table_info("{table}")')
        return {str(r.get('name')) for r in rows if r.get('name') is not None}
    def apply_file(self,path):
        self._run(["d1","execute",DB_BINDING,"--remote","--yes","--file",str(path)],timeout=180)
    def info(self): return self._json(self._run(["d1","info",DB_BINDING,"--json"]))
    def bookmark(self): return self._json(self._run(["d1","time-travel","info",DB_BINDING,"--json"]))


def group_status(inspector, name):
    spec=GROUPS[name]
    required=[]; present=[]
    for kind in ("tables","indexes","triggers"):
        vals=spec.get(kind,[])
        have=inspector.objects(vals)
        required.extend((kind,x) for x in vals)
        present.extend((kind,x) for x in vals if x in have)
    for table,cols in spec.get("columns",{}).items():
        have=inspector.columns(table)
        required.extend((f"column:{table}",x) for x in cols)
        present.extend((f"column:{table}",x) for x in cols if x in have)
    if not present:return "PENDING",0,len(required)
    if len(present)==len(required):return "APPLIED",len(present),len(required)
    return "PARTIAL_BLOCKED",len(present),len(required)


def statuses(inspector):
    return {name: group_status(inspector,name) for name,_ in MIGRATIONS}


def make_base(con):
    con.executescript('''
    CREATE TABLE cron_runs(run_id TEXT PRIMARY KEY, scheduled_time INTEGER, started_ts INTEGER, completed_ts INTEGER, status TEXT, universe_total INTEGER, scanned INTEGER, persistence_status TEXT, error_text TEXT);
    CREATE TABLE deep_check_scheduler_state(contract_code TEXT PRIMARY KEY,last_status TEXT,last_run_id TEXT,last_started_ts INTEGER,last_completed_ts INTEGER,last_error TEXT,updated_ts INTEGER);
    CREATE TABLE deep_check_run_log(run_id TEXT PRIMARY KEY,contract_code TEXT);
    ''')


def self_test(root):
    verify_migration_bytes(root)
    con=sqlite3.connect(":memory:"); make_base(con); ins=LocalInspector(con)
    pre=statuses(ins)
    assert all(v[0]=="PENDING" for v in pre.values()),pre
    for name,_ in MIGRATIONS:
        con.executescript((root/name).read_text())
        state=group_status(ins,name)
        assert state[0]=="APPLIED",(name,state)
    post=statuses(ins); assert all(v[0]=="APPLIED" for v in post.values()),post
    # prove partial state is blocked, not guessed/resumed
    con2=sqlite3.connect(":memory:"); make_base(con2)
    con2.execute("ALTER TABLE cron_runs ADD COLUMN v3_discovery_shortlist_count INTEGER")
    partial=group_status(LocalInspector(con2),"20260917_v3_cron_pipeline_telemetry_shadow.sql")
    assert partial[0]=="PARTIAL_BLOCKED",partial
    print("V3_D1_PREDEPLOY_SELF_TEST=PASS")


def require_node24_proof(path: pathlib.Path):
    if not path.is_file(): raise RuntimeError("NODE24_PROOF_FILE_MISSING")
    text=path.read_text(errors="replace")
    if "FINAL_RESULT=READY_FOR_CONTROLLED_INTEGRATION_NOT_DEPLOYED" not in text:
        raise RuntimeError("NODE24_PROOF_FINAL_RESULT_NOT_READY")
    marker=f"CANDIDATE_WORKER_SHA=PASS sha={CANDIDATE_WORKER_SHA}"
    if marker not in text: raise RuntimeError("NODE24_PROOF_CANDIDATE_SHA_MISMATCH")


def validate_repo(repo:pathlib.Path):
    if not repo.is_dir(): raise RuntimeError(f"REPO_NOT_FOUND:{repo}")
    config=repo/"wrangler.jsonc"
    if not config.is_file(): raise RuntimeError("WRANGLER_JSONC_MISSING")
    text=config.read_text(errors="replace")
    if not re.search(r'"binding"\s*:\s*"DATA_DB"',text): raise RuntimeError("DATA_DB_BINDING_MISSING")


def info_version(info):
    if isinstance(info,list) and info: info=info[0]
    if not isinstance(info,dict): return None
    return info.get("version") or (info.get("result") or {}).get("version")


def bookmark_value(data):
    if isinstance(data,list) and data:data=data[0]
    if not isinstance(data,dict):return None
    return data.get("bookmark") or (data.get("result") or {}).get("bookmark")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",default=str(pathlib.Path.home()/"my-report-2-hub"))
    ap.add_argument("--apply",action="store_true")
    ap.add_argument("--node24-proof")
    ap.add_argument("--self-test",action="store_true")
    args=ap.parse_args()
    root=migration_root()
    if args.self_test:
        self_test(root); return
    verify_migration_bytes(root)
    repo=pathlib.Path(args.repo).expanduser().resolve(); validate_repo(repo)
    remote=RemoteInspector(repo)
    # Base-schema identity is mandatory before either check or apply.
    base_present=remote.objects(BASE_TABLES)
    missing=[x for x in BASE_TABLES if x not in base_present]
    if missing: raise RuntimeError("BASE_SCHEMA_MISSING:"+",".join(missing))
    info=remote.info(); version=info_version(info)
    if version not in (None,"production"): raise RuntimeError(f"D1_BACKEND_NOT_PRODUCTION:{version}")
    before=statuses(remote)
    summary={k:v[0] for k,v in before.items()}
    if any(v[0]=="PARTIAL_BLOCKED" for v in before.values()):
        print(json.dumps({"status":"PARTIAL_BLOCKED","migrations":summary,"production_changed":False},indent=2));
        raise SystemExit(3)
    if not args.apply:
        print(json.dumps({"status":"CHECK_ONLY","migrations":summary,"production_changed":False,"remote_d1_changed":False},indent=2));return
    if not args.node24_proof: raise RuntimeError("NODE24_PROOF_REQUIRED_FOR_APPLY")
    require_node24_proof(pathlib.Path(args.node24_proof).expanduser().resolve())
    tt=remote.bookmark(); bookmark=bookmark_value(tt)
    if not bookmark: raise RuntimeError("TIME_TRAVEL_BOOKMARK_NOT_RESOLVED")
    safe=repo/f"V3_PREDEPLOY_D1_BOOKMARK_{int(time.time())}.txt"
    safe.write_text(bookmark+"\n"); os.chmod(safe,0o600)
    changed=[]
    for name,_ in MIGRATIONS:
        state=group_status(remote,name)[0]
        if state=="APPLIED": continue
        if state!="PENDING": raise RuntimeError(f"MIGRATION_NOT_CLEAN:{name}:{state}")
        remote.apply_file(root/name)
        after=group_status(remote,name)[0]
        if after!="APPLIED": raise RuntimeError(f"MIGRATION_READBACK_FAIL:{name}:{after}")
        changed.append(name)
    final=statuses(remote)
    if not all(v[0]=="APPLIED" for v in final.values()): raise RuntimeError("FINAL_SCHEMA_NOT_CLOSED")
    print(json.dumps({
      "status":"MIGRATIONS_APPLIED_READBACK_PASS" if changed else "ALREADY_APPLIED_READBACK_PASS",
      "changed_migrations":changed,
      "bookmark_file":str(safe),
      "rollback_command_template":f"npx --no-install wrangler d1 time-travel restore {DB_BINDING} --bookmark=<BOOKMARK_FROM_FILE>",
      "production_worker_changed":False,
      "remote_d1_changed":bool(changed),
      "automatic_restore_performed":False,
    },indent=2))

if __name__=="__main__":
    try: main()
    except Exception as e:
        print(f"V3_D1_PREDEPLOY_FAIL={type(e).__name__}:{e}",file=sys.stderr)
        print("PRODUCTION_WORKER_CHANGED=NO",file=sys.stderr)
        sys.exit(1)
