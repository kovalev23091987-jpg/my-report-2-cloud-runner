# STAGE 9A — R8 TELEGRAM DELIVERY GATING

Статус: LOCAL_CLEANROOM_PASS_NOT_DEPLOYED
Дата: 2026-09-18

Что добавлено:
- bounded V3 Telegram delivery sidecar;
- dispatch journal можно включить отдельно от network send;
- initial workflow: journal=ON, V3 network=OFF;
- revalidate-before-send;
- PENDING/SENDING/SENT/FAILED_RETRYABLE/FAILED_FINAL/EXPIRED_NOT_SENT semantics;
- confirmed relay receipt only => SENT;
- timeout/5xx/ambiguous != SENT;
- pipeline-health сообщения явно системные, не market signal;
- при будущем V3 network=ON legacy telegram-output автоматически suppress, чтобы не было duplicate ENTRY;
- controlled_no_telegram по-прежнему гасит весь network path.

Проверено:
- v3 telegram delivery focused tests 6/6 PASS;
- полный R8 Node clean-room 86/86 PASS;
- полный R8 static/schema clean-room 14/14 PASS;
- Worker SHA unchanged: 72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c.

Не проверено / OPEN:
- Node24 R8 exact runner emit в GitHub Actions;
- remote D1 journal rows;
- natural lifecycle proof;
- real V3 Telegram network delivery;
- production deploy/audit/closure.

Fail-closed:
- live network OFF by default;
- отсутствие natural qualifying event не имитируется;
- old Telegram remains active only while V3 network is OFF;
- strategy/35-30-20-15/live probability/auto trading не изменялись.
