# GitHub connector write limitation

Read access is available and production scheduled runs can be audited.
Write attempts were fail-closed:
- create new isolated readiness branch: HTTP 403 Resource not accessible by integration
- create a small file in an existing V3 branch: HTTP 403 Resource not accessible by integration

Therefore no repository branch, main commit, workflow or production payload was modified by this chat.
Node 24 readiness is packaged for local/Mac execution without deploy.
