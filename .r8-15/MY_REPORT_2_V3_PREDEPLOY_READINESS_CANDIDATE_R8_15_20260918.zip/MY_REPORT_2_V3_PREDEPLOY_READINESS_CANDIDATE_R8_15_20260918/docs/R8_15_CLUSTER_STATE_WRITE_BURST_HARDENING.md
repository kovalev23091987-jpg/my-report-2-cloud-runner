# R8.15 Cluster-State Write-Burst Hardening

Purpose: keep the existing 320-write run burst cap and 70,000/day limit while preventing projected liquidation lifecycle-summary persistence from consuming the V3 sidecar reserve during high-cluster market states.

Change: lifecycle summary rows per liquidation observation are capped from 80 to 32. Full projected cluster payload remains persisted in liquidation_shadow_observation JSON. Selection order is unchanged: explicit-major first, then nearest clusters. Raw evidence, source semantics, strategy, Decision Layer, Telegram and trading behavior are unchanged.

Observed trigger: R8.14 controlled production smoke reached 307 writes before V3 sidecars; batch:liquidation_cluster_state contributed 204 writes. The guarded promotion rolled back successfully.
