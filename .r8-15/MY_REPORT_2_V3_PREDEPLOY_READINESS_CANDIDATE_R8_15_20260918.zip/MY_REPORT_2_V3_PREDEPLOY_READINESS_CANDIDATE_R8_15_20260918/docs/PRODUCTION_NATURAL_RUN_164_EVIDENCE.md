# Natural production evidence — run #164

Date: 2026-09-17
GitHub Actions run id: 35268237732
Event: schedule
Head: 26bf598affe96e224a65df522c80d85779ed3c13
Node: 24.20.0
Result: success

Verified production behavior:
- HTX universe: 342/342 scanned.
- technically eligible: 104.
- discovery shortlist: 24.
- fast_move_watch_prepare: selected_contracts=[] and maintenance lane selected.
- bounded_deep_check_scheduler: live selected=0; maintenance execution lane.
- persistence: CLOSED.
- Telegram: NO_FINAL_DECISION_ROW; no final entry sent.
- D1 telemetry remained within configured daily safety budgets.

Interpretation:
This is another natural reproduction of the already-known P0: an eligible discovery shortlist can exist while no live candidate reaches Deep Check because maintenance occupies the bounded slot.
This document is evidence only. It does not mark V3 as deployed or CLOSED.
