# R8.15.1 — inherited static guard repair

R8.15 remote Node24 validation showed the business/runtime change itself was healthy, but the inherited `stage391-integrity-static.test.py` still asserted the historical lifecycle summary cap `80`.

R8.15 intentionally tightens that cap to `32` to preserve V3 sidecar write headroom while leaving full projected-cluster JSON unchanged in the observation row.

This repair changes only the inherited test expectation `80 -> 32`.
Runtime/business files are byte-identical to R8.15.
