# R8.12 Projected Provider Identity Wiring

Root cause: Worker already builds a separate cross-venue asset identity proof in public evidence, but the ByKaranteli projected-map adapter did not receive it and therefore hard-coded `asset_identity_verified=false`.

Fix: pass the existing proof into `collectCrossVenueLiquidationIntelligence`. Accept only when proof is verified and canonical_base exactly equals provider base. All independent provider gates remain unchanged: exact provider symbol registry, current timestamp/freshness, nonempty clusters, no truncation, price-anchor agreement.

Safety: SHADOW only; no strategy weights, probability, validated signal, Telegram network, or trading execution changes.
