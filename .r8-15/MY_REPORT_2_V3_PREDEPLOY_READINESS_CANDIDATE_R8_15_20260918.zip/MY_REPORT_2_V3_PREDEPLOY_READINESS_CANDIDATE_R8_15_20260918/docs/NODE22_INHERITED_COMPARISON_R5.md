# R5 Node 22 inherited comparison

The same inherited Node test set was run on:
1. V3 R5 candidate
2. untouched authoritative R9/TZ10.1

Both results:
- total: 125
- PASS: 113
- FAIL: 12
- candidate-unique failures: 0
- base-unique failures: 0

Therefore the 12 failures are classified as INHERITED_ENVIRONMENT_SENSITIVE_NODE22, not V3-specific regressions.
Final compatibility verdict remains OPEN until Node 24 full readiness passes.
