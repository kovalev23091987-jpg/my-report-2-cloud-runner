# R8.15.3 synthetic regression packaging repair

- Business/runtime code unchanged from R8.15.
- Cluster lifecycle summary cap remains 32.
- The synthetic liquidation persistence regression legitimately depends on the inherited migration `20260913_cross_venue_liquidation_shadow.sql`.
- R8.15.2 failed before assertions because that migration was absent from the overlay test fixture.
- R8.15.3 adds the exact authoritative migration to the readiness overlay only.
- Production remains unchanged; no migration is applied by this packaging repair.
