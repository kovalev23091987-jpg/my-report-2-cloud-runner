# V3 R7 — completeness hardening

Status: LOCAL_CLEANROOM_VERIFIED_NODE24_PENDING.

## Реализовано
- Runner-sidecar `v3-realized-liquidation-sidecar.mjs` читает только уже фактически сохранённые HTX `liquidation_events`.
- Coverage source помечается `PARTIAL_BOUNDED_HTX_REST`; это не continuous tape.
- Compact persistence ограничена окнами 1m/5m/15m/1h в пределах подтверждённого 2h REST lookback.
- Missing notional остаётся missing: complete total не фабрикуется.
- Raw high-frequency liquidation rows повторно не пишутся.
- Pipeline critical-feed state выводится из фактических статусов realized/projected sidecars; hardcoded OK удалён.
- Manual production smoke сможет использовать `controlled_no_telegram=true`, не меняя scheduled Telegram behavior.
- Telegram V3 network send остаётся OFF до natural lifecycle proof.

## Честно PARTIAL / OPEN
- Near-real-time collector: bounded probe only, 24/7 proof отсутствует.
- Market microstructure production writer: не доказан; Early Discovery умеет читать microstructure, но coverage считается PARTIAL/NO_ROWS.
- Projected provider identity eligibility: NOT_CLOSED до отдельной proof.
- Telegram delivery: persistence/revalidation/dedup tests есть, network delivery ещё не включён.

## Local clean-room proof
- V3 Node: 80/80 PASS (Node 22 preliminary).
- V3 Python/static/schema: 14/14 PASS on merged authoritative R9 tree.
- Candidate Worker SHA: 72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c.
- Production changed: NO.
- Remote D1 changed: NO.
