# R5 builder-totality proof

Worker SHA-256: 72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c
Totality test SHA-256: 5c62bfa606be127600fc5e19bc15cdb1eb5758d615ce430f59ffa584d559854f

Completed local run on these exact bytes:
- mutation cases: 9162
- result: PASS
- assertion: every one-field deletion/null/type/future mutation returned a validator-safe shadow-only envelope
- duration: ~40.2s

A later duplicate rerun in the constrained tool environment hit execution timeout before emitting the result. Because Worker and test hashes are unchanged, the completed PASS above remains the valid local proof; Node 24 proof is still mandatory and not inferred from this Node 22 run.
