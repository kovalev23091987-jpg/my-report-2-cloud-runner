# Node 24 isolated CI gate — run 35272472538

Status: FAIL_CLOSED_STALE_TEST_FIXED_RETRY_REQUIRED

Verified before failure:
- isolated branch base/main guard: PASS;
- Node: v24.20.0;
- package checksums: PASS;
- authoritative R9 ZIP SHA: PASS;
- base Worker SHA: PASS;
- candidate Worker SHA: `72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c`;
- Node24 syntax: PASS;
- V3 Node24 tests: PASS;
- V3 Python/static/schema tests: PASS;
- core Node24 regression: 124/125 PASS before stop;
- production changed: NO;
- remote D1 changed: NO.

Failure classification:
`tests/liquidation-persistence-budget.test.mjs` expected all 80 unchanged lifecycle rows to increment after only 60 seconds.
That assertion contradicted the authoritative R9 runtime itself. R9 already contains `REPORT2_D1_CLUSTER_WRITE_SHARD_V1`: unchanged cluster-state rows refresh only after >=5 minutes and only for one deterministic `rowid % 3` shard; lifecycle / explicit-major changes persist immediately.

Fix:
- runtime / production logic: UNCHANGED, exact R9 bytes;
- only the new regression test is aligned to existing R9 semantics;
- test now verifies initial 80-row cap, no redundant one-minute rewrites, immediate lifecycle-change persistence, deterministic 5-minute shard refresh, atomic rollback.

Evidence identity:
- authoritative R9 `src/liquidation-intelligence.mjs` SHA-256: `9d4fa1a16ed64ab1934914c33725253a17ec68f3abcaf04fb68f763ea11b6412`;
- aligned test SHA-256: `048f4e0f508074bb02ebb3906358b2d6d6194a79d73350462a3f78807240def1`.

Next: rerun isolated Node24 gate. CLOSED remains forbidden until the rerun and later production gates pass.
