# V3 R5 implementation checkpoint — Stage 2–7

Date: 2026-09-17
Status: PREDEPLOY_READINESS_ONLY / NOT_DEPLOYED
Production changed: NO
Remote D1 changed: NO
Strategy weights 35/30/20/15 changed: NO

## What R5 adds over R4
- self-normalized trajectory feature fusion across price / OI / funding / volume / orderflow / relative strength / liquidation / execution domains;
- market-microstructure SHADOW features with explicit coverage/freshness and UNKNOWN/PARTIAL states;
- first-seen sidecar enrichment without converting weak evidence into ENTRY or probability;
- bounded liquidation sidecar for projected-provider observations and cluster lifecycle;
- Pipeline Health sidecar backed by worker cron telemetry;
- cron telemetry is carried through the existing cron_runs write, so it does not add a Worker hot-path D1 query;
- combined runner-side pre-action budget reservation preserves Telegram reserve;
- projected-map identity requires explicit verified asset identity; ticker similarity alone cannot close the gate.

## Stage 2 — Data plane / collector
- free-first realized liquidation normalization and compact persistence;
- no raw high-frequency liquidation tape in D1;
- bounded Cloudflare Durable Object probe only; continuous mode prohibited until endurance/cost proof;
- Binance liquidation coverage remains PARTIAL_SNAPSHOT, Bybit/Gate have their own documented semantics, unsupported/uncertain routes fail closed.

## Stage 3 — First-seen / history
- persistent wave memory and required first-seen fields;
- 1h/4h/12h/24h outcome tasks;
- counterfactual journal fields for MFE/MAE/R, missed/prevented/late-entry outcomes;
- bounded sidecar envelope; missing data remains missing, never zero.

## Stage 4 — Early Discovery
- robust per-asset normalization (median/MAD/percentile-like diagnostics);
- trajectory windows include 5m/15m/1h/4h/12h/24h where factual history exists;
- multi-weak-signal accumulation across independent evidence domains;
- all new early scores remain SHADOW, not probability and not Final Decision weights.

## Stage 5 — Liquidation Intelligence V2
- REALIZED / REALIZED DENSITY / PROJECTED PROVIDER / MODELLED_PROXY separated;
- extended scan keeps important far zones instead of mechanically cutting 20/30/50%;
- cluster first/last seen, touch/sweep/invalidation/reaction lifecycle;
- swept cluster is not automatically treated as a future magnet;
- guaranteed_tp remains hard-disabled.

## Stage 6 — LIVE priority / handoff
- fresh LIVE candidate is separated from Fast-Move recheck cadence;
- maintenance cannot silently take the only live slot when a technically eligible live candidate exists;
- explicit zero reasons required;
- persistent CLAIMED -> COMPLETED handoff journal uses existing scheduler writes/triggers;
- restart/retry safe and no extra Worker D1 query;
- Worker D1 design peak remains 48/50.

## Stage 7 — Telegram / Pipeline Health
- НАБЛЮДАТЬ -> ЖДАТЬ -> ВХОД -> ИДЕЯ СНЯТА plus management states;
- dispatch record before network send;
- revalidate-before-send, dedup, retry, expiry, receipt-required SENT;
- Pipeline Health persists HEALTHY_NO_IDEA / DEGRADED / recovery separately from market signals.

## Local clean-room verification
Exact authoritative R9 ZIP -> empty directory -> R5 overlay:
- base Worker SHA guard: PASS;
- candidate Worker SHA: 72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c;
- syntax: PASS;
- V3 Node 22.16.0 preliminary: 68/68 PASS;
- V3 Python/static/schema: 14/14 files PASS;
- builder totality: 9162/9162 mutation cases PASS on exact candidate Worker/test bytes on Node 22;
- inherited Node22 comparison: candidate 113/125 PASS and untouched R9 113/125 PASS, exact same 12 failures, candidate-unique failures = 0;
- Worker D1 hot-path design peak: 48/50 PASS.

## Fresh natural R9 evidence
Scheduled run #164 / id 35268237732 ran on exact production main with Node 24.20.0, scanned HTX 342/342, had technically eligible=104 and discovery shortlist=24, but selected no LIVE Deep Check while the maintenance lane was used. This naturally reproduces the known P0 on the old production and is evidence for the V3 fix; it is NOT V3 production proof.

## Still OPEN
- candidate full Node 24 readiness;
- remote D1 migration/readback;
- bounded collector endurance/cost proof;
- controlled deploy;
- natural scheduled V3 proof for LIVE handoff / first_seen / liquidation / Telegram / health;
- production audit;
- rollback/recovery proof after V3;
- canonical Version 1 rotation.

CLOSED remains forbidden until V3 production acceptance is factually satisfied.
