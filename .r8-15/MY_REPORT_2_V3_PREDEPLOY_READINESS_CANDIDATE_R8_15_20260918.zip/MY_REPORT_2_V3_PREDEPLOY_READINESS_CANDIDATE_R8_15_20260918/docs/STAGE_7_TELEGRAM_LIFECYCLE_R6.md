# Stage 7 Telegram Lifecycle R6 — persistence-only wiring

Status: LOCAL_VERIFIED_NODE24_PENDING.

What changed:
- Added `v3-telegram-lifecycle-sidecar.mjs` and wired it into the cloud runner patcher.
- Sidecar consumes only COMPLETED Discovery→Deep Check handoffs.
- It derives/persists V3 user lifecycle state (`OBSERVE/WAIT/ENTRY/IDEA_REMOVED` internal enum mapping) but **dispatch is forcibly disabled** in R6 shadow phase.
- `network_send=false`; no V3 Telegram message can be sent by this sidecar.
- Existing production Telegram output remains separately disabled in controlled-run gates.
- Direction conflict, missing identity/migration and stale/insufficient data fail closed.
- New in-memory SQLite integration proves OBSERVE persistence and zero dispatch rows; direction conflict persists nothing.

Local proof:
- V3 Node: 75/75 PASS (Node 22 preliminary).
- V3 Python/static/schema: 14/14 PASS.
- Candidate Worker SHA remains `72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c`.
- Production changed: NO.
- Remote D1 changed: NO.

Next gate: isolated Node 24 R6 proof, then controlled migration/real-data proof before any production promotion.
