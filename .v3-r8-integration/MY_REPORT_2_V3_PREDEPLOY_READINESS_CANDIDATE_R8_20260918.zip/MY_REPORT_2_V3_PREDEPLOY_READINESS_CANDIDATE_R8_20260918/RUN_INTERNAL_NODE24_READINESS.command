#!/bin/bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
AUTH_ZIP="$ROOT/authoritative/MY_REPORT_2_AUTHORITATIVE_SOURCE_R9_TZ10_1_20260917.zip"
EXPECTED_AUTH_ZIP_SHA="2700be91744764626daabca385dae7a5802b2ee119d8718fe0a4988082160e39"
EXPECTED_BASE_WORKER_SHA="15c7d88537af7464b572387ded53326d99d7633c4cc2f5b0e4767af921569be1"
EXPECTED_CANDIDATE_WORKER_SHA="72f0cab80ac9c38c4b3a84116b40c16fb54d5944ce20e1da2b6c399a386bc36c"
OUT="${TMPDIR:-/tmp}/MY_REPORT_2_V3_R8_READINESS_$(date +%Y%m%d_%H%M%S)"
WORK="$OUT/candidate"
LOG="$OUT/READINESS_RESULT.txt"
mkdir -p "$OUT"

say(){ printf '%s\n' "$*" | tee -a "$LOG"; }
fail(){ say "FINAL_RESULT=FAIL"; say "FAIL_REASON=$*"; say "PRODUCTION_CHANGED=NO"; say "REMOTE_D1_CHANGED=NO"; exit 1; }
sha256(){ shasum -a 256 "$1" | awk '{print $1}'; }

node24(){
  node "$@"
}

say "MY_REPORT_2_V3_R8_NODE24_READINESS_BEGIN"
say "PACKAGE_ROOT=$ROOT"
say "OUT=$OUT"

[ -f "$ROOT/CHECKSUMS.sha256" ] || fail "CHECKSUMS_MISSING"
(
  cd "$ROOT"
  shasum -a 256 -c CHECKSUMS.sha256 >/dev/null
) || fail "PACKAGE_CHECKSUMS_FAIL"
say "PACKAGE_CHECKSUMS=PASS"

[ -f "$AUTH_ZIP" ] || fail "AUTHORITATIVE_ZIP_MISSING"
[ "$(sha256 "$AUTH_ZIP")" = "$EXPECTED_AUTH_ZIP_SHA" ] || fail "AUTHORITATIVE_ZIP_SHA_MISMATCH"
say "AUTHORITATIVE_ZIP_SHA=PASS"

if ! command -v node >/dev/null 2>&1; then
  fail "NODE24_UNAVAILABLE_INSTALL_NODE24"
fi
NODE24_VERSION="$(node -p 'process.versions.node' 2>/dev/null || true)"
case "$NODE24_VERSION" in 24.*) ;; *) fail "NODE24_UNAVAILABLE_CURRENT_NODE:$NODE24_VERSION";; esac
NODE24_MODE=native
say "NODE24=PASS version=$NODE24_VERSION mode=$NODE24_MODE"

mkdir -p "$WORK"
unzip -q "$AUTH_ZIP" -d "$WORK" || fail "AUTHORITATIVE_UNZIP_FAIL"
[ -f "$WORK/src/worker.js" ] || fail "AUTHORITATIVE_WORKER_MISSING"
[ "$(sha256 "$WORK/src/worker.js")" = "$EXPECTED_BASE_WORKER_SHA" ] || fail "BASE_WORKER_SHA_MISMATCH"
say "BASE_WORKER_SHA=PASS"

cp -R "$ROOT/overlay/." "$WORK/"
[ "$(sha256 "$WORK/src/worker.js")" = "$EXPECTED_CANDIDATE_WORKER_SHA" ] || fail "CANDIDATE_WORKER_SHA_MISMATCH"
say "CANDIDATE_WORKER_SHA=PASS sha=$EXPECTED_CANDIDATE_WORKER_SHA"

# Syntax gate: Worker + every V3 source/tool.
node24 --check "$WORK/src/worker.js" >/dev/null || fail "WORKER_SYNTAX_FAIL"
for f in "$WORK"/src/v3-*.mjs "$WORK"/tools/v3-*.mjs "$WORK"/cloudflare/*.mjs; do
  [ -f "$f" ] || continue
  node24 --check "$f" >/dev/null || fail "SYNTAX_FAIL:$f"
done
say "NODE24_SYNTAX=PASS"

# V3 Node regression as one suite.
V3_NODE_LOG="$OUT/V3_NODE24.log"
node24 --test "$WORK"/tests/v3-*.test.mjs >"$V3_NODE_LOG" 2>&1 || { tail -120 "$V3_NODE_LOG" | tee -a "$LOG"; fail "V3_NODE24_TESTS_FAIL"; }
say "V3_NODE24_TESTS=PASS"

# V3 Python/static/schema suites.
V3_PY_LOG="$OUT/V3_PYTHON.log"
: > "$V3_PY_LOG"
for f in "$WORK"/tests/v3-*.test.py; do
  [ -f "$f" ] || continue
  python3 "$f" >>"$V3_PY_LOG" 2>&1 || { tail -120 "$V3_PY_LOG" | tee -a "$LOG"; fail "V3_PYTHON_TEST_FAIL:$(basename "$f")"; }
done
say "V3_PYTHON_TESTS=PASS"

# Key inherited Node24 regression. opportunity-intelligence-runtime is deliberately
# included: its Node22 failure reproduced on untouched R9, so Node24 must resolve it.
INHERITED_NODE=(
  bounded-deep-check.test.mjs
  deep-check-journal.test.mjs
  fast-move-watch-engine.test.mjs
  fast-move-watch-failure-injection.test.mjs
  fast-move-watch-runtime.test.mjs
  full-evidence-contract.test.mjs
  full-evidence-shadow-model.test.mjs
  liquidation-intelligence.test.mjs
  liquidation-persistence-budget.test.mjs
  multi-wave-campaign-engine.test.mjs
  multi-wave-campaign-failure-injection.test.mjs
  multi-wave-campaign-runtime.test.mjs
  opportunity-intelligence-engine.test.mjs
  opportunity-intelligence-runtime.test.mjs
  final-decision-integration-adapter.test.mjs
  final-decision-integration-boundaries.test.mjs
  final-decision-integration-correlation-closure.test.mjs
  final-decision-integration-engine.test.mjs
  final-decision-integration-evidence.test.mjs
  final-decision-integration-failure-injection.test.mjs
  final-decision-integration-gate-metamorphic.test.mjs
  final-decision-integration-lifecycle.test.mjs
  final-decision-integration-runtime.test.mjs
  final-decision-integration-state-grid.test.mjs
  final-decision-integration-symmetry.test.mjs
  final-decision-integration-temporal.test.mjs
  final-decision-integration-validator-persistence.test.mjs
  final-decision-integration-veto-safety.test.mjs
  final-decision-shadow-outcome-contract.test.mjs
  final-decision-upstream-compat-runtime.test.mjs
  final-decision-upstream-freshness-contract.test.mjs
)
INHERITED_PATHS=()
for t in "${INHERITED_NODE[@]}"; do [ -f "$WORK/tests/$t" ] && INHERITED_PATHS+=("$WORK/tests/$t"); done
INHERITED_NODE_LOG="$OUT/INHERITED_NODE24.log"
node24 --test "${INHERITED_PATHS[@]}" >"$INHERITED_NODE_LOG" 2>&1 || { tail -160 "$INHERITED_NODE_LOG" | tee -a "$LOG"; fail "NODE24_CORE_REGRESSION_FAIL"; }
say "INHERITED_NODE24_CORE=PASS"

# Builder totality is mandatory for readiness, even if slower.
TOTALITY_LOG="$OUT/BUILDER_TOTALITY_NODE24.log"
node24 --test "$WORK/tests/final-decision-integration-builder-totality.test.mjs" >"$TOTALITY_LOG" 2>&1 || { tail -160 "$TOTALITY_LOG" | tee -a "$LOG"; fail "BUILDER_TOTALITY_NODE24_FAIL"; }
say "BUILDER_TOTALITY_NODE24=PASS"

# Key inherited D1/schema/capacity checks. Intentionally exclude isolation sentinels
# that pin the production Worker SHA or require audit artifacts absent from canonical R9.
INHERITED_PY=(
  fast-move-watch-concurrency.test.py
  fast-move-watch-d1.test.py
  fast-move-watch-hardening-d1.test.py
  fast-move-watch-runtime-sql.test.py
  final-decision-integration-d1.test.py
  full-evidence-d1-schema.test.py
  liquidation-d1-schema.test.py
  multi-wave-campaign-d1.test.py
  opportunity-integrity-concurrency.test.py
  opportunity-integrity-d1.test.py
  opportunity-intelligence-d1.test.py
  stage391-capacity-budget.test.py
  stage391-integrity-static.test.py
  stage392-capacity-budget.test.py
  stage392-d1-schema.test.py
  stage392-trigger-atomicity.test.py
  stage392-wave-lifecycle-backcompat.test.py
)
INHERITED_PY_LOG="$OUT/INHERITED_PYTHON.log"
: > "$INHERITED_PY_LOG"
for t in "${INHERITED_PY[@]}"; do
  [ -f "$WORK/tests/$t" ] || continue
  python3 "$WORK/tests/$t" >>"$INHERITED_PY_LOG" 2>&1 || { tail -160 "$INHERITED_PY_LOG" | tee -a "$LOG"; fail "INHERITED_PYTHON_FAIL:$t"; }
done
say "INHERITED_PYTHON_CORE=PASS"

# Optional exact current public-runner dry-run if an exact repo checkout is available.
REPO="${REPORT2_REPO:-}"
if [ -z "$REPO" ]; then
  for p in "$HOME/my-report-2-cloud-runner" "$HOME/Desktop/my-report-2-cloud-runner" "$HOME/Documents/my-report-2-cloud-runner"; do
    if [ -f "$p/runner/runner-main.mjs" ] && [ -f "$p/.github/workflows/report2.yml" ]; then REPO="$p"; break; fi
  done
fi
if [ -n "$REPO" ] && [ -d "$REPO" ]; then
  python3 "$WORK/tools/patch_cloud_runner_v3.py" "$REPO" --worker-sha "$EXPECTED_CANDIDATE_WORKER_SHA" --dry-run >>"$LOG" 2>&1 || fail "EXACT_RUNNER_PATCH_DRY_RUN_FAIL"
  say "EXACT_RUNNER_PATCH_DRY_RUN=PASS repo=$REPO"
else
  say "EXACT_RUNNER_PATCH_DRY_RUN=NOT_RUN_REPO_NOT_FOUND"
fi

say "V3_REALIZED_LIQUIDATION_COMPACT_PERSISTENCE=WIRED_SHADOW"
say "V3_MARKET_MICROSTRUCTURE_PRODUCTION_WRITER=NOT_PROVED_COVERAGE_PARTIAL"
say "V3_TELEGRAM_JOURNAL=PATCH_READY_ENABLED_IN_INITIAL_R8_WORKFLOW"
say "V3_TELEGRAM_NETWORK_SEND=DISABLED_PENDING_NATURAL_PROOF"
say "V3_TELEGRAM_DELIVERY_SIDECAR=LATENT_TESTED_FAIL_CLOSED"
say "V3_ENDURANCE_PROBE=NOT_RUN_COVERAGE_PARTIAL_REQUIRES_NETWORK_RUNTIME_PROOF"
say "REMOTE_D1_MIGRATIONS=NOT_RUN"
say "DEPLOY_PERFORMED=NO"
say "PRODUCTION_CHANGED=NO"
say "REMOTE_D1_CHANGED=NO"
say "FINAL_RESULT=READY_FOR_CONTROLLED_INTEGRATION_NOT_DEPLOYED"
say "RESULT_FILE=$LOG"
