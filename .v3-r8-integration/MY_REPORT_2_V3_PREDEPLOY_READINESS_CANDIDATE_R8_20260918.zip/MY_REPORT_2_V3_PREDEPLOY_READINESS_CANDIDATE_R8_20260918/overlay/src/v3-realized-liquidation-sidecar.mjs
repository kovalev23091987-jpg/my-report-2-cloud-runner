import {parseStage0CompactPayload} from './v3-early-discovery.mjs';
import {persistRealizedLiquidationCompact} from './v3-liquidation-persistence-runtime.mjs';
import {COVERAGE_CLASS, IDENTITY_STATUS} from './v3-liquidation-data-plane.mjs';

export const V3_REALIZED_LIQUIDATION_SIDECAR_VERSION='v3-realized-liquidation-sidecar-shadow-v1';
export const V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET=Object.freeze({
  rows_read:260,
  rows_written:40,
  requests_soft_cap:8,
  max_events:240,
  max_contracts:2,
  lookback_ms:2*60*60_000,
  windows:['1m','5m','15m','1h'],
});
function text(v){return v==null?'':String(v).trim();}
function finite(v){if(v==null||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null;}
function rows(x){return Array.isArray(x?.results)?x.results:[];}
function usageDelta(before,after){if(!before||!after)return null;return {rows_read:Math.max(0,Number(after.rows_read||0)-Number(before.rows_read||0)),rows_written:Math.max(0,Number(after.rows_written||0)-Number(before.rows_written||0)),requests:Math.max(0,Number(after.requests||0)-Number(before.requests||0)),unknown_ops:Math.max(0,Number(after.unknown_ops||0)-Number(before.unknown_ops||0))};}

export function normalizePersistedHtxLiquidationEvent(row,{received_ts=Date.now()}={}){
  const contract=text(row?.contract_code).normalize('NFC');
  const eventId=text(row?.event_id);
  const ts=finite(row?.ts);
  const rawSide=text(row?.side).toUpperCase();
  const side=rawSide==='LONG_LIQUIDATED'?'LONG':rawSide==='SHORT_LIQUIDATED'?'SHORT':'UNKNOWN';
  if(!contract||!eventId||ts===null)return null;
  return {
    venue:'HTX',
    contract,
    normalized_base:contract.endsWith('-USDT')?contract.slice(0,-5).toUpperCase():null,
    ts_exchange:ts,
    ts_received:finite(received_ts),
    side_raw:rawSide||null,
    liquidated_side_normalized:side,
    price_raw:finite(row?.price),
    price_semantics:'HTX_REST_LIQUIDATION_ORDER_PRICE',
    qty_raw:finite(row?.volume_contracts),
    qty_unit:'HTX_CONTRACTS',
    notional_usdt_normalized:finite(row?.notional_usdt),
    leverage_if_factual:null,
    source_event_id:eventId,
    aggregation_window:'HTX_REST_BOUNDED_120M_OBSERVATION',
    source_coverage_class:COVERAGE_CLASS.PARTIAL_SNAPSHOT,
    raw_source_ref:text(row?.source)||'HTX official public liquidation REST',
    identity_status:IDENTITY_STATUS.CLOSED,
    shadow_only:true,
  };
}

export function chooseRealizedContracts(events,{max_contracts=V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.max_contracts}={}){
  const groups=new Map();
  for(const e of Array.isArray(events)?events:[]){
    const c=text(e?.contract);const ts=finite(e?.ts_exchange);if(!c||ts===null)continue;
    const g=groups.get(c)||{contract:c,events:[],latest_ts:0};g.events.push(e);g.latest_ts=Math.max(g.latest_ts,ts);groups.set(c,g);
  }
  return [...groups.values()].sort((a,b)=>b.latest_ts-a.latest_ts||b.events.length-a.events.length||a.contract.localeCompare(b.contract)).slice(0,Math.max(0,Math.trunc(max_contracts)));
}

async function loadInputs(db,{current_scan_ts,now_ts}={}){
  const now=Math.trunc(finite(now_ts)??Date.now());
  const currentTs=Math.trunc(finite(current_scan_ts)??now);
  const start=now-V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.lookback_ms;
  const result=await db.batch([
    db.prepare(`SELECT source,event_id,contract_code,ts,side,price,volume_contracts,amount_base,notional_usdt
      FROM liquidation_events WHERE ts BETWEEN ?1 AND ?2 ORDER BY ts DESC LIMIT ${V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.max_events}`).bind(start,now+1000),
    db.prepare(`SELECT ts,payload_json FROM scan_runs WHERE ts BETWEEN ?1 AND ?2 AND stage0_coverage_pct>=99.9 AND errors=0 AND stale=0
      ORDER BY ABS(ts-?3) ASC LIMIT 1`).bind(currentTs-5*60_000,currentTs+5*60_000,currentTs),
  ]);
  const raw=rows(result?.[0]);
  const scan=rows(result?.[1])?.[0]||null;
  const parsed=scan?parseStage0CompactPayload(scan.payload_json,scan.ts):null;
  return {now,currentTs,raw,scan:parsed};
}

export async function runV3RealizedLiquidationSidecar(db,{current_scan_ts,source_run_id=null,now_ts=Date.now()}={}){
  const base={version:V3_REALIZED_LIQUIDATION_SIDECAR_VERSION,mode:'SHADOW_ONLY',source_run_id:text(source_run_id)||null,source:'HTX_PERSISTED_FACTUAL_LIQUIDATION_EVENTS',coverage:'PARTIAL_BOUNDED_HTX_REST',near_realtime:false,projected_map:false,modelled_proxy:false,future_heatmap:false,probability:null,validated_signal:false,trading_execution:false};
  if(!db?.prepare||!db?.batch)return {...base,status:'SOURCE_UNSUPPORTED',persisted:0};
  const before=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;
  let loaded;
  try{loaded=await loadInputs(db,{current_scan_ts,now_ts});}
  catch(error){const msg=String(error?.message||error);return {...base,status:/no such table/i.test(msg)?'MIGRATION_OR_SOURCE_TABLE_REQUIRED':'INPUT_LOAD_PARTIAL',persisted:0,error:msg};}
  const normalized=loaded.raw.map(r=>normalizePersistedHtxLiquidationEvent(r,{received_ts:loaded.now})).filter(Boolean);
  if(!normalized.length){const after=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;return {...base,status:'CLOSED_NO_REALIZED_EVENTS',events_loaded:0,contracts_selected:0,persisted:0,usage_delta:usageDelta(before,after)};}
  const selected=chooseRealizedContracts(normalized);
  const results=[];
  for(const g of selected){
    const reference=loaded.scan?.status==='CLOSED'?finite(loaded.scan.rows.get(g.contract)?.price):null;
    const write=await persistRealizedLiquidationCompact(db,{contract:g.contract,events:g.events,reference_price:reference,now_ts:loaded.now,windows:V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.windows,density_lookback_ms:V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.lookback_ms});
    results.push({contract:g.contract,event_rows:g.events.length,reference_price_closed:reference!==null,status:write.status,aggregate_rows:Number(write.aggregate_rows||0),density_rows:Number(write.density_rows||0),persisted:Number(write.persisted||0),raw_events_persisted:Number(write.raw_events_persisted||0)});
  }
  const after=typeof db.usageSnapshot==='function'?db.usageSnapshot():null;
  const delta=usageDelta(before,after);
  const persisted=results.reduce((n,x)=>n+x.persisted,0);
  if(delta&&(delta.rows_read>V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.rows_read||delta.rows_written>V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET.rows_written||delta.unknown_ops>0))return {...base,status:'BUDGET_ENVELOPE_EXCEEDED_FAIL_CLOSED',events_loaded:normalized.length,contracts_selected:selected.length,persisted,targets:results,usage_delta:delta};
  const partial=results.some(x=>x.status!=='CLOSED');
  return {...base,status:partial?'PARTIAL':'CLOSED',events_loaded:normalized.length,contracts_selected:selected.length,persisted,targets:results,raw_events_persisted:0,usage_delta:delta};
}

export default {V3_REALIZED_LIQUIDATION_SIDECAR_VERSION,V3_REALIZED_LIQUIDATION_SIDECAR_BUDGET,normalizePersistedHtxLiquidationEvent,chooseRealizedContracts,runV3RealizedLiquidationSidecar};
