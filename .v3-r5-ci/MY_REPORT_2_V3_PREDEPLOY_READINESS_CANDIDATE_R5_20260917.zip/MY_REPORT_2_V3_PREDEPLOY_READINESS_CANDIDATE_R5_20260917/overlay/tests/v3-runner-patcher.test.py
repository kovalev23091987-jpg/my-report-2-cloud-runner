import importlib.util, pathlib
P=pathlib.Path(__file__).resolve().parents[1]/'tools/patch_cloud_runner_v3.py'
spec=importlib.util.spec_from_file_location('p',P); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
fixture='''import { classifyZeroTelegram } from "./telegram-zero-reason.mjs";\n\nconst RUNNER_VERSION = "my-report-2-github-cloud-runner-v4.7.3-telegram-watch70-tree-guard";\n'''+'''const cron = await env.DATA_DB.prepare("SELECT run_id,scheduled_time,started_ts,completed_ts,status,universe_total,scanned,persistence_status,error_text FROM cron_runs WHERE scheduled_time = ?1 ORDER BY started_ts DESC LIMIT 1").bind(started).first();\n'''+'''  assertClosedCron(cron, scan);\n  const telegramObserver = await observeNaturalTelegramDecision(env.DATA_DB);\n'''+'''  const telegramZeroReason = classifyZeroTelegram({ preBudget:d1PreTelegramBudget, telegramObserver, telegramOutput });\n'''+'''telegram_observer:telegramObserver, discovery_recall_kpi:discoveryRecallKpi, telegram_output:telegramOutput'''
out=m.patch_runner_text(fixture)
for needle in ['runV3EarlyPersistenceSidecar','runV3LiquidationIntelligenceSidecar','runV3PipelineHealthSidecar','V3_EARLY_SIDECAR_BUDGET.rows_read + V3_LIQUIDATION_SIDECAR_BUDGET.rows_read + V3_PIPELINE_HEALTH_SIDECAR_BUDGET.rows_read + 64','BUDGET_BLOCKED_FAIL_CLOSED','v3_liquidation_sidecar:v3LiquidationSidecar','v3_pipeline_health_sidecar:v3PipelineHealthSidecar','v3_live_shortlist_count']:
    assert needle in out, needle
assert m.NEW_RUNNER_VERSION in out
wf='REPORT2_EXPECTED_WORKER_SHA: "'+'0'*64+'"\n          cp runner/telegram-output.mjs runtime/telegram-output.mjs\n'
sha='a'*64
wout=m.patch_workflow_text(wf,sha)
assert sha in wout
# V3 modules live inside the encrypted candidate payload. The public runner repo
# has no root src/ tree, so workflow patch must never add cp src/v3-* lines.
assert 'cp src/v3-' not in wout
assert wout.count('cp runner/telegram-output.mjs runtime/telegram-output.mjs') == 1
assert m.RUNNER_BLOB_SHA=='064275879c4e23b841907b9b6a25e567e717bd2e'
assert m.WORKFLOW_BLOB_SHA=='b1369dde068c609a715938408f2e23802f9661b8'
print('V3_RUNNER_PATCHER=PASS')

# Emit mode is tested against synthetic exact-byte fixtures by overriding the
# expected git-blob guards in-process.
import tempfile, sys
with tempfile.TemporaryDirectory() as td:
    repo=pathlib.Path(td)/'repo'; (repo/'runner').mkdir(parents=True); (repo/'.github/workflows').mkdir(parents=True)
    (repo/'runner/runner-main.mjs').write_text(fixture)
    (repo/'.github/workflows/report2.yml').write_text(wf)
    m.RUNNER_BLOB_SHA=m.git_blob_sha((repo/'runner/runner-main.mjs').read_bytes())
    m.WORKFLOW_BLOB_SHA=m.git_blob_sha((repo/'.github/workflows/report2.yml').read_bytes())
    outdir=pathlib.Path(td)/'emit'
    old_argv=sys.argv
    try:
        sys.argv=['patch_cloud_runner_v3.py',str(repo),'--worker-sha',sha,'--emit-dir',str(outdir)]
        m.main()
    finally:
        sys.argv=old_argv
    assert (outdir/'runner-main.mjs').is_file()
    assert (outdir/'report2.yml').is_file()
    assert 'cp src/v3-' not in (outdir/'report2.yml').read_text()
    assert sha in (outdir/'report2.yml').read_text()
print('V3_RUNNER_PATCHER_EMIT=PASS')
